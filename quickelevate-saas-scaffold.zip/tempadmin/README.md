# QuickElevate for macOS — SaaS Platform

Self-service portal for IT admins to configure and deploy temporary admin access for macOS devices managed via Microsoft Intune.

## Project Structure

```
quickelevate/
├── frontend/          # Next.js 14 — portal UI (landing, auth, onboarding, dashboard)
├── backend/           # Node.js/Express API — customer mgmt, pkg generation, billing
├── infra/             # Azure infrastructure
│   ├── azure-function/  # Multi-tenant approval handler
│   ├── pkg-builder/     # Server-side .pkg generation scripts
│   └── bicep/           # Azure resource definitions (IaC)
└── shared/            # Shared TypeScript types
```

## Tech Stack

| Layer        | Technology              |
|--------------|-------------------------|
| Frontend     | Next.js 14 (App Router) |
| Backend API  | Node.js + Express       |
| Database     | PostgreSQL via Prisma    |
| Auth         | Clerk                   |
| Billing      | Stripe                  |
| Storage      | Azure Blob Storage      |
| Hosting      | Azure App Service       |
| Frontend CDN | Azure Static Web Apps   |
| Email        | Resend                  |

## Getting Started

### 1. Install dependencies
```bash
cd frontend && npm install
cd ../backend && npm install
```

### 2. Set up environment variables
```bash
cp frontend/.env.example frontend/.env.local
cp backend/.env.example backend/.env
```

### 3. Set up database
```bash
cd backend
npx prisma migrate dev
npx prisma db seed
```

### 4. Run locally
```bash
# Terminal 1 — backend
cd backend && npm run dev

# Terminal 2 — frontend
cd frontend && npm run dev
```

Frontend: http://localhost:3000
Backend API: http://localhost:4000

## Deployment

See `infra/bicep/` for Azure infrastructure as code.
See `infra/azure-function/` for the multi-tenant approval handler.
