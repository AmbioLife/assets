import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

// ── Only allow designated admin Clerk user IDs ────────────────────────────────
const ADMIN_CLERK_IDS = (process.env.ADMIN_CLERK_IDS || '').split(',').filter(Boolean);

router.use((req: Request, res: Response, next: Function) => {
  const userId = req.auth?.userId;
  if (!userId || !ADMIN_CLERK_IDS.includes(userId)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  next();
});

// GET /api/admin/stats
router.get('/stats', async (_req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [
      totalCustomers,
      freeCustomers,
      paidCustomers,
      totalDevices,
      growthCount,
      businessCount,
      enterpriseCount,
      buildsToday,
      requestsToday,
    ] = await Promise.all([
      prisma.customer.count(),
      prisma.customer.count({ where: { plan: { in: ['FREE', 'TRIAL'] } } }),
      prisma.customer.count({ where: { plan: { in: ['GROWTH', 'BUSINESS', 'ENTERPRISE'] }, planStatus: 'active' } }),
      prisma.device.count(),
      prisma.customer.count({ where: { plan: 'GROWTH',     planStatus: 'active' } }),
      prisma.customer.count({ where: { plan: 'BUSINESS',   planStatus: 'active' } }),
      prisma.customer.count({ where: { plan: 'ENTERPRISE', planStatus: 'active' } }),
      prisma.pkgBuild.count({ where: { createdAt: { gte: today } } }),
      prisma.approvalRequest.count({ where: { requestedAt: { gte: today } } }),
    ]);

    // MRR estimate
    const mrr = (growthCount * 49) + (businessCount * 99) + (enterpriseCount * 249);

    return res.json({
      totalCustomers,
      freeCustomers,
      paidCustomers,
      totalDevices,
      growthCount,
      businessCount,
      enterpriseCount,
      buildsToday,
      requestsToday,
      mrrEstimate: mrr,
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// GET /api/admin/customers
router.get('/customers', async (req, res) => {
  try {
    const page  = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = Math.min(100, parseInt(req.query.limit as string) || 50);
    const skip  = (page - 1) * limit;

    const customers = await prisma.customer.findMany({
      skip,
      take:    limit,
      orderBy: { createdAt: 'desc' },
      include: {
        subscription: { select: { status: true, currentPeriodEnd: true } },
        _count:        { select: { devices: true, builds: true, requests: true } },
      },
    });

    const total = await prisma.customer.count();
    return res.json({ customers, total, page });
  } catch {
    return res.status(500).json({ error: 'Failed to fetch customers' });
  }
});

// GET /api/admin/customers/:id
router.get('/customers/:id', async (req, res) => {
  try {
    // Validate ID format
    if (!/^c[a-z0-9]{20,30}$/.test(req.params.id)) {
      return res.status(400).json({ error: 'Invalid customer ID' });
    }

    const customer = await prisma.customer.findUnique({
      where:   { id: req.params.id },
      include: {
        config: {
          select: {
            itAdminEmail:           true,
            onboardingComplete:     true,
            onboardingStep:         true,
            sessionDurationMinutes: true,
            cooldownMinutes:        true,
            approvalTimeoutMinutes: true,
            requireApproval:        true,
          },
        },
        subscription: true,
        builds:   { orderBy: { createdAt: 'desc' }, take: 10 },
        devices:  { orderBy: { lastSeen: 'desc' }, take: 20 },
      },
    });

    if (!customer) return res.status(404).json({ error: 'Not found' });

    // Never return apiKey from admin endpoint
    const { apiKey: _, ...safeCustomer } = customer as any;
    return res.json({ customer: safeCustomer });
  } catch {
    return res.status(500).json({ error: 'Failed to fetch customer' });
  }
});

// POST /api/admin/customers/:id/override-plan
router.post('/customers/:id/override-plan', async (req, res) => {
  try {
    if (!/^c[a-z0-9]{20,30}$/.test(req.params.id)) {
      return res.status(400).json({ error: 'Invalid customer ID' });
    }

    const { plan, deviceLimit } = req.body;
    const validPlans = ['FREE', 'GROWTH', 'BUSINESS', 'ENTERPRISE'];

    if (!validPlans.includes(plan)) {
      return res.status(400).json({ error: `Plan must be one of: ${validPlans.join(', ')}` });
    }

    const limit = parseInt(deviceLimit);
    if (isNaN(limit) || limit < 1 || limit > 10000) {
      return res.status(400).json({ error: 'deviceLimit must be a number between 1 and 10000' });
    }

    await prisma.customer.update({
      where: { id: req.params.id },
      data:  { plan, deviceLimit: limit },
    });

    return res.json({ ok: true });
  } catch {
    return res.status(500).json({ error: 'Failed to update plan' });
  }
});

export { router as adminRouter };

// POST /api/admin/devices/:id/quarantine — IT admin quarantines a suspicious device
router.post('/devices/:id/quarantine', async (req, res) => {
  try {
    if (!/^c[a-z0-9]{20,30}$/.test(req.params.id)) {
      return res.status(400).json({ error: 'Invalid device ID' });
    }
    const { reason } = req.body;
    await prisma.device.update({
      where: { id: req.params.id },
      data:  { flagged: true, flagReason: reason || 'Quarantined by administrator' },
    });
    return res.json({ ok: true });
  } catch {
    return res.status(500).json({ error: 'Failed to quarantine device' });
  }
});

// POST /api/admin/devices/:id/release — remove quarantine
router.post('/devices/:id/release', async (req, res) => {
  try {
    if (!/^c[a-z0-9]{20,30}$/.test(req.params.id)) {
      return res.status(400).json({ error: 'Invalid device ID' });
    }
    await prisma.device.update({
      where: { id: req.params.id },
      data:  { flagged: false, flagReason: null },
    });
    return res.json({ ok: true });
  } catch {
    return res.status(500).json({ error: 'Failed to release device' });
  }
});
