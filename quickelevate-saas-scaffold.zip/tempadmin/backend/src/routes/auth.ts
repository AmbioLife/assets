import { Router } from 'express';
const router = Router();
// Auth is handled entirely by Clerk on the frontend.
// This router is a placeholder for any custom auth endpoints if needed.
export { router as authRouter };
