import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';
import { verifySignature } from '../middleware/verifySignature';
import { checkMspDeviceFingerprint } from '../services/deviceFingerprint';
import { sendApprovalEmail, approvalResponsePage, alreadyProcessedPage, expiredPage } from '../services/emailService';
import logger from '../utils/logger';

const router  = Router();
const prisma  = new PrismaClient();

// ── POST /api/msp-approval/request ───────────────────────────────────────────
// Called by Mac with an MSP client API key.
// Identical flow to direct approval but uses MspClient, MspDevice, MspApprovalRequest.
router.post('/request', verifySignature, async (req: Request, res: Response) => {
  const mspClient = (req as any).mspClient;
  if (!mspClient?.mspAccount) return res.status(500).json({ error: 'MSP account context missing' });

  if (!mspClient) {
    return res.status(400).json({ error: 'This endpoint is for MSP client devices only' });
  }

  const { userName, deviceName, deviceSerial, reason, durationMinutes } = req.body;

  if (!userName || !deviceName || !deviceSerial || !reason || !durationMinutes) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const MAX_LEN = { userName: 64, deviceName: 64, deviceSerial: 32, reason: 500 };
  if (typeof userName     !== 'string' || userName.length     > MAX_LEN.userName)    return res.status(400).json({ error: 'userName too long'    });
  if (typeof deviceName   !== 'string' || deviceName.length   > MAX_LEN.deviceName)  return res.status(400).json({ error: 'deviceName too long'  });
  if (typeof deviceSerial !== 'string' || deviceSerial.length > MAX_LEN.deviceSerial)return res.status(400).json({ error: 'deviceSerial too long' });
  if (typeof reason       !== 'string' || reason.length       > MAX_LEN.reason)      return res.status(400).json({ error: 'reason too long'       });
  if (typeof durationMinutes !== 'number' || ![15, 30, 60, 120, 240].includes(durationMinutes)) {
    return res.status(400).json({ error: 'Invalid duration' });
  }

  const sanitize = (s: string) => s.replace(/<[^>]*>/g, '').trim();
  const safeUserName   = sanitize(userName);
  const safeDeviceName = sanitize(deviceName);
  const safeReason     = sanitize(reason);

  // ── Resolve which email to send to ──────────────────────────────────────────
  // Priority: client-specific email → MSP support email
  const mspAccount    = mspClient.mspAccount;
  const resolvedEmail = mspClient.itAdminEmail || mspAccount.mspSupportEmail;

  if (!resolvedEmail) {
    return res.status(400).json({
      error: 'No approval email configured. Set a client IT admin email or an MSP support email in your dashboard settings.',
    });
  }

  const routedToMspEmail = !mspClient.itAdminEmail && !!mspAccount.mspSupportEmail;

  // Device fingerprint check
  const fingerprint = await checkMspDeviceFingerprint(
    mspClient.id, deviceSerial, safeDeviceName,
    resolvedEmail, mspClient.clientName, req
  );

  if (!fingerprint.allowed) {
    return res.status(403).json({ error: 'This device has been quarantined. Please contact IT support.' });
  }


  // Create approval request
  const approveToken = crypto.randomBytes(32).toString('hex');
  const denyToken    = crypto.randomBytes(32).toString('hex');
  const expiresAt    = new Date(Date.now() + mspClient.approvalTimeoutMinutes * 60 * 1000);

  const request = await prisma.mspApprovalRequest.create({
    data: {
      mspClientId:    mspClient.id,
      userName:       safeUserName,
      deviceName:     safeDeviceName,
      deviceSerial,
      reason:         safeReason,
      durationMinutes,
      approveToken,
      denyToken,
      expiresAt,
    },
  });

  sendApprovalEmail({
    toEmail:        resolvedEmail,
    // When routing to MSP support email, prefix the company name so
    // the technician sees "Acme Corp — via QuickElevate MSP" in the email header
    companyName:    routedToMspEmail
      ? `${mspClient.clientName} (via ${mspAccount.customer?.companyName || 'MSP'})`
      : mspClient.clientName,
    userName:       safeUserName,
    deviceName:     safeDeviceName,
    reason:         safeReason,
    durationMinutes,
    requestId:      request.id,
    approveToken,
    denyToken,
    expiresAt,
  }).catch(err => logger.error(`Approval email failed for MSP request ${request.id}: ${err.message}`));

  logger.info(`MSP request ${request.id} | client=${mspClient.id} | user=${safeUserName}`);

  return res.json({
    requestId: request.id,
    expiresAt: expiresAt.toISOString(),
    ...(fingerprint.isSuspect && {
      securityWarning: 'Request submitted from an unrecognised network location. Your IT admin has been notified.',
    }),
  });
});

// ── GET /api/msp-approval/status/:requestId ───────────────────────────────────
router.get('/status/:requestId', verifySignature, async (req: Request, res: Response) => {
  const mspClient = (req as any).mspClient;
  if (!mspClient) return res.status(400).json({ error: 'MSP client key required' });

  if (!/^c[a-z0-9]{20,30}$/.test(req.params.requestId)) {
    return res.status(400).json({ error: 'Invalid request ID' });
  }

  const request = await prisma.mspApprovalRequest.findFirst({
    where: { id: req.params.requestId, mspClientId: mspClient.id },
  });

  if (!request) return res.status(404).json({ error: 'Request not found' });

  if (request.status === 'pending' && new Date() > request.expiresAt) {
    await prisma.mspApprovalRequest.update({
      where: { id: request.id },
      data:  { status: 'expired', resolvedAt: new Date() },
    });
    return res.json({ status: 'expired' });
  }

  return res.json({ status: request.status });
});

// ── GET /api/msp-approval/approve/:token ─────────────────────────────────────
router.get('/approve/:token', async (req: Request, res: Response) => {
  if (!/^[a-f0-9]{64}$/.test(req.params.token)) return res.status(400).send('<h1>Invalid</h1>');

  const request = await prisma.mspApprovalRequest.findUnique({ where: { approveToken: req.params.token } });
  if (!request)                     return res.status(404).send('<h1>Not found</h1>');
  if (request.status !== 'pending') return res.send(alreadyProcessedPage(request.status));
  if (new Date() > request.expiresAt) {
    await prisma.mspApprovalRequest.update({ where: { id: request.id }, data: { status: 'expired', resolvedAt: new Date() } });
    return res.send(expiredPage());
  }

  await prisma.mspApprovalRequest.update({ where: { id: request.id }, data: { status: 'approved', resolvedAt: new Date() } });
  return res.send(approvalResponsePage('approved', request.userName, request.deviceName));
});

// ── GET /api/msp-approval/deny/:token ────────────────────────────────────────
router.get('/deny/:token', async (req: Request, res: Response) => {
  if (!/^[a-f0-9]{64}$/.test(req.params.token)) return res.status(400).send('<h1>Invalid</h1>');

  const request = await prisma.mspApprovalRequest.findUnique({ where: { denyToken: req.params.token } });
  if (!request)                     return res.status(404).send('<h1>Not found</h1>');
  if (request.status !== 'pending') return res.send(alreadyProcessedPage(request.status));
  if (new Date() > request.expiresAt) {
    await prisma.mspApprovalRequest.update({ where: { id: request.id }, data: { status: 'expired', resolvedAt: new Date() } });
    return res.send(expiredPage());
  }

  await prisma.mspApprovalRequest.update({ where: { id: request.id }, data: { status: 'denied', resolvedAt: new Date() } });
  return res.send(approvalResponsePage('denied', request.userName, request.deviceName));
});

export { router as mspApprovalRouter };
