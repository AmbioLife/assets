import crypto from 'crypto';
import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { BlobServiceClient } from '@azure/storage-blob';
import { triggerGitHubBuild }  from '../services/githubBuild';
import { requireAuth }          from '../middleware/requireAuth';
import logger from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

const CALLBACK_SECRET        = process.env.QE_CALLBACK_SECRET!;
const AZURE_STORAGE_CONN_STR = process.env.AZURE_STORAGE_CONNECTION_STRING!;
const AZURE_BLOB_CONTAINER   = process.env.AZURE_BLOB_CONTAINER || 'pkg-builds';

// POST /api/build/trigger
router.post('/trigger', requireAuth, async (req: Request, res: Response) => {
  try {
    const customer = (req as any).customer;
    if (!customer.config?.onboardingComplete) {
      return res.status(400).json({ error: 'Complete onboarding before building' });
    }
    const inProgress = await prisma.pkgBuild.count({
      where: { customerId: customer.id, status: { in: ['PENDING', 'BUILDING'] } },
    });
    if (inProgress > 0) {
      return res.status(429).json({ error: 'A build is already in progress. Please wait.' });
    }
    const build = await prisma.pkgBuild.create({
      data: { customerId: customer.id, status: 'PENDING' },
    });
    triggerGitHubBuild(customer, build.id).catch(err => {
      logger.error(`GitHub dispatch failed for build ${build.id}: ${err.message}`);
      prisma.pkgBuild.update({
        where: { id: build.id },
        data: { status: 'FAILED', errorMessage: err.message },
      }).catch(() => {});
    });
    return res.json({ buildId: build.id, status: 'PENDING' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET /api/build/history
router.get('/history', requireAuth, async (req: Request, res: Response) => {
  try {
    const customer = (req as any).customer;
    const builds = await prisma.pkgBuild.findMany({
      where: { customerId: customer.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });
    return res.json({ builds });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET /api/build/:id/status
router.get('/:id/status', requireAuth, async (req: Request, res: Response) => {
  try {
    const customer = (req as any).customer;
    const build = await prisma.pkgBuild.findFirst({
      where: { id: req.params.id, customerId: customer.id },
    });
    if (!build) return res.status(404).json({ error: 'Build not found' });
    return res.json({ build });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET /api/build/:id/download
router.get('/:id/download', requireAuth, async (req: Request, res: Response) => {
  try {
    const customer = (req as any).customer;
    const build = await prisma.pkgBuild.findFirst({
      where: { id: req.params.id, customerId: customer.id, status: 'SUCCESS' },
    });
    if (!build?.blobUrl) return res.status(404).json({ error: 'Build not ready' });

    const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE_STORAGE_CONN_STR);
    const containerClient   = blobServiceClient.getContainerClient(AZURE_BLOB_CONTAINER);
    const blockBlobClient   = containerClient.getBlockBlobClient(build.blobUrl);

    const expiresOn = new Date();
    expiresOn.setHours(expiresOn.getHours() + 1);
    const sasUrl = await blockBlobClient.generateSasUrl({
      permissions: { read: true } as any,
      expiresOn,
    });
    return res.json({ downloadUrl: sasUrl, expiresAt: expiresOn.toISOString() });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/build/callback — called by GitHub Actions, protected by shared secret
router.post('/callback', async (req: Request, res: Response) => {
  const incoming = req.headers['x-callback-secret'] as string;
  // Use timing-safe comparison to prevent timing attacks
  if (!CALLBACK_SECRET || !incoming ||
      !crypto.timingSafeEqual(Buffer.from(incoming), Buffer.from(CALLBACK_SECRET))) {
    logger.warn(`Build callback rejected from ${req.ip}`);
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const { buildId, status, blobUrl, blobName, error } = req.body;
  if (!buildId || !status) return res.status(400).json({ error: 'buildId and status required' });
  // Validate buildId looks like a CUID (c + 24 alphanumeric chars) — prevents arbitrary DB updates
  if (!/^c[a-z0-9]{20,30}$/.test(buildId)) {
    return res.status(400).json({ error: 'Invalid buildId format' });
  }
  if (!['SUCCESS', 'FAILED'].includes(status)) {
    return res.status(400).json({ error: 'status must be SUCCESS or FAILED' });
  }

  try {
    if (status === 'SUCCESS') {
      await prisma.pkgBuild.update({
        where: { id: buildId },
        data: { status: 'SUCCESS', blobUrl: blobUrl || null, builtAt: new Date() },
      });
      logger.info(`Build ${buildId} SUCCESS. Blob: ${blobName}`);
    } else {
      await prisma.pkgBuild.update({
        where: { id: buildId },
        data: { status: 'FAILED', errorMessage: (error || 'Build failed').slice(0, 500) },
      });
      logger.error(`Build ${buildId} FAILED: ${error}`);
    }
    return res.json({ ok: true });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

export { router as buildRouter };
