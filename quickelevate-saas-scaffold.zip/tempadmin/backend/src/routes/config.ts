import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';
import { requireAuth } from '../middleware/requireAuth';

const router = Router();
const prisma = new PrismaClient();

// GET /api/config — get current customer config
router.get('/', requireAuth, async (req: Request, res: Response) => {
  const customer = (req as any).customer;
  // Only reveal the last 8 characters of the API key in GET — full key is only returned at onboarding completion
  const maskedKey = customer.apiKey
    ? 'qe_live_••••••••••••••••••••••••' + customer.apiKey.slice(-8)
    : null;
  return res.json({ config: customer.config || null, apiKey: maskedKey });
});

// PUT /api/config/step/1 — save IT admin email (step 1 of 2)
router.put('/step/1', requireAuth, async (req: Request, res: Response) => {
  const customer = (req as any).customer;
  const { itAdminEmail } = req.body;

  if (!itAdminEmail || !itAdminEmail.includes('@')) {
    return res.status(400).json({ error: 'Valid IT admin email is required' });
  }

  const config = await prisma.customerConfig.upsert({
    where:  { customerId: customer.id },
    update: { itAdminEmail, onboardingStep: Math.max(customer.config?.onboardingStep || 0, 2) },
    create: { customerId: customer.id, itAdminEmail, onboardingStep: 2 },
  });

  return res.json({ config });
});

// PUT /api/config/step/2 — save session behaviour (step 2 of 2)
router.put('/step/2', requireAuth, async (req: Request, res: Response) => {
  const customer = (req as any).customer;
  const {
    sessionDurationMinutes,
    cooldownMinutes,
    approvalTimeoutMinutes,
    requireApproval,
    excludedAccounts,
  } = req.body;

  const config = await prisma.customerConfig.upsert({
    where:  { customerId: customer.id },
    update: {
      sessionDurationMinutes: sessionDurationMinutes || 60,
      cooldownMinutes:        cooldownMinutes        || 60,
      approvalTimeoutMinutes: approvalTimeoutMinutes || 30,
      requireApproval:        requireApproval        ?? true,
      excludedAccounts:       excludedAccounts       || 'lapsadmin',
      onboardingStep:         Math.max(customer.config?.onboardingStep || 0, 3),
    },
    create: {
      customerId:             customer.id,
      itAdminEmail:           customer.config?.itAdminEmail || '',
      sessionDurationMinutes: sessionDurationMinutes || 60,
      cooldownMinutes:        cooldownMinutes        || 60,
      approvalTimeoutMinutes: approvalTimeoutMinutes || 30,
      requireApproval:        requireApproval        ?? true,
      excludedAccounts:       excludedAccounts       || 'lapsadmin',
      onboardingStep:         3,
    },
  });

  return res.json({ config });
});

// POST /api/config/complete — finalise onboarding, generate API key, trigger build
router.post('/complete', requireAuth, async (req: Request, res: Response) => {
  const customer = (req as any).customer;

  if (!customer.config?.itAdminEmail) {
    return res.status(400).json({ error: 'Complete step 1 before finalising' });
  }

  // Generate API key if not already set
  let apiKey = customer.apiKey;
  if (!apiKey) {
    apiKey = 'qe_live_' + crypto.randomBytes(32).toString('hex');
    await prisma.customer.update({
      where: { id: customer.id },
      data:  { apiKey },
    });
  }

  await prisma.customerConfig.update({
    where: { customerId: customer.id },
    data:  { onboardingComplete: true, onboardingStep: 3 },
  });

  return res.json({ ok: true, apiKey });
});

export { router as configRouter };
