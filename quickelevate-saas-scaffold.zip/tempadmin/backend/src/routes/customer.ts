import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

// GET /api/customer/me — get current customer profile
router.get('/me', async (req: Request, res: Response) => {
  try {
    const customer = await prisma.customer.findUnique({
      where: { clerkUserId: req.auth!.userId },
      include: {
        config: true,
        subscription: true,
        builds: {
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
        _count: { select: { devices: true } },
      },
    });

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    return res.json({ customer });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch customer' });
  }
});

// GET /api/customer/devices — list enrolled devices
router.get('/devices', async (req: Request, res: Response) => {
  try {
    const customer = await prisma.customer.findUnique({
      where: { clerkUserId: req.auth!.userId },
    });
    if (!customer) return res.status(404).json({ error: 'Not found' });

    const devices = await prisma.device.findMany({
      where: { customerId: customer.id },
      orderBy: { lastSeenAt: 'desc' },
    });

    return res.json({ devices, limit: customer.deviceLimit });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch devices' });
  }
});

// POST /api/customer/device/heartbeat — called by Mac script on each request
// Updates device record so we can track active devices for billing
router.post('/device/heartbeat', async (req: Request, res: Response) => {
  try {
    const { serialNumber, deviceName, userName, customerId } = req.body;

    if (!serialNumber || !customerId) {
      return res.status(400).json({ error: 'serialNumber and customerId required' });
    }

    const customer = await prisma.customer.findUnique({
      where: { id: customerId },
      include: { _count: { select: { devices: true } } },
    });
    if (!customer) return res.status(404).json({ error: 'Customer not found' });

    // Check device limit
    const existingDevice = await prisma.device.findUnique({
      where: { customerId_serialNumber: { customerId, serialNumber } },
    });

    if (!existingDevice && customer._count.devices >= customer.deviceLimit) {
      return res.status(403).json({
        error: 'Device limit reached',
        limit: customer.deviceLimit,
        plan: customer.plan,
      });
    }

    // Upsert device record
    await prisma.device.upsert({
      where: { customerId_serialNumber: { customerId, serialNumber } },
      create: { customerId, serialNumber, deviceName, userName },
      update: { deviceName, userName, lastSeenAt: new Date() },
    });

    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: 'Heartbeat failed' });
  }
});

export { router as customerRouter };
