import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import Stripe from 'stripe';
import { requireAuth } from '../middleware/requireAuth';

const router = Router();
const prisma = new PrismaClient();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// ── Paid plans only (Free plan needs no Stripe checkout) ──────────────────────
const STRIPE_PLANS = {
  GROWTH: {
    priceId:      process.env.STRIPE_GROWTH_PRICE_ID!,
    name:         'Growth',
    priceMonthly: 49,
    deviceLimit:  75,
    description:  'For teams growing past 25 devices',
  },
  BUSINESS: {
    priceId:      process.env.STRIPE_BUSINESS_PRICE_ID!,
    name:         'Business',
    priceMonthly: 99,
    deviceLimit:  200,
    description:  'For larger IT departments',
  },
  ENTERPRISE: {
    priceId:      process.env.STRIPE_ENTERPRISE_PRICE_ID!,
    name:         'Enterprise',
    priceMonthly: 249,
    deviceLimit:  500,
    description:  'For large organisations',
  },
};

// POST /api/billing/checkout
router.post('/checkout', requireAuth, async (req: Request, res: Response) => {
  const customer  = (req as any).customer;
  const { plan }  = req.body as { plan: keyof typeof STRIPE_PLANS };

  if (!STRIPE_PLANS[plan]) {
    return res.status(400).json({ error: 'Invalid plan. Must be GROWTH, BUSINESS, or ENTERPRISE.' });
  }

  const planConfig = STRIPE_PLANS[plan];

  const session = await stripe.checkout.sessions.create({
    mode:          'subscription',
    line_items:    [{ price: planConfig.priceId, quantity: 1 }],
    metadata:      { customerId: customer.id, plan },
    customer_email: customer.email,
    success_url:   `${process.env.FRONTEND_URL}/dashboard/billing?success=1`,
    cancel_url:    `${process.env.FRONTEND_URL}/dashboard/billing`,
    subscription_data: {
      metadata: { customerId: customer.id, plan },
    },
  });

  return res.json({ checkoutUrl: session.url });
});

// POST /api/billing/portal
router.post('/portal', requireAuth, async (req: Request, res: Response) => {
  const customer = (req as any).customer;

  const subscription = await prisma.subscription.findUnique({
    where: { customerId: customer.id },
  });

  if (!subscription?.stripeCustomerId) {
    return res.status(400).json({ error: 'No active subscription found.' });
  }

  const session = await stripe.billingPortal.sessions.create({
    customer:   subscription.stripeCustomerId,
    return_url: `${process.env.FRONTEND_URL}/dashboard/billing`,
  });

  return res.json({ portalUrl: session.url });
});

// GET /api/billing/status
router.get('/status', requireAuth, async (req: Request, res: Response) => {
  const customer = (req as any).customer;

  const [deviceCount, subscription] = await Promise.all([
    prisma.device.count({ where: { customerId: customer.id } }),
    prisma.subscription.findUnique({ where: { customerId: customer.id } }),
  ]);

  const isFree     = customer.plan === 'FREE' || customer.plan === 'TRIAL';
  const nearLimit  = deviceCount >= customer.deviceLimit * 0.8;
  const overLimit  = deviceCount > customer.deviceLimit;

  return res.json({
    plan:             isFree ? 'FREE' : customer.plan,
    planStatus:       customer.planStatus,
    isFree,
    deviceCount,
    deviceLimit:      customer.deviceLimit,
    devicesRemaining: Math.max(0, customer.deviceLimit - deviceCount),
    nearLimit,
    overLimit,
    subscription: subscription ? {
      status:            subscription.status,
      currentPeriodEnd:  subscription.currentPeriodEnd,
      cancelAtPeriodEnd: subscription.cancelAtPeriodEnd,
    } : null,
    // All plans including Free for the UI to render
    plans: [
      { key: 'FREE',       name: 'Free',       priceMonthly: 0,   deviceLimit: 25,  current: isFree },
      { key: 'GROWTH',     name: 'Growth',     priceMonthly: 49,  deviceLimit: 75,  current: customer.plan === 'GROWTH' },
      { key: 'BUSINESS',   name: 'Business',   priceMonthly: 99,  deviceLimit: 200, current: customer.plan === 'BUSINESS' },
      { key: 'ENTERPRISE', name: 'Enterprise', priceMonthly: 249, deviceLimit: 500, current: customer.plan === 'ENTERPRISE' },
    ],
  });
});

export { router as billingRouter };
