import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';
import Stripe from 'stripe';
import { requireAuth } from '../middleware/requireAuth';
import { triggerGitHubBuild } from '../services/githubBuild';
import logger from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// ── MSP flat-tier plan definitions ───────────────────────────────────────────
export const MSP_PLANS = {
  MSP_STARTER: {
    name:         'MSP Starter',
    priceMonthly: 79,
    deviceLimit:  200,
    description:  'Up to 200 devices across all clients',
    priceId:      process.env.STRIPE_MSP_STARTER_PRICE_ID!,
  },
  MSP_GROWTH: {
    name:         'MSP Growth',
    priceMonthly: 149,
    deviceLimit:  750,
    description:  'Up to 750 devices across all clients',
    priceId:      process.env.STRIPE_MSP_GROWTH_PRICE_ID!,
  },
  MSP_SCALE: {
    name:         'MSP Scale',
    priceMonthly: 249,
    deviceLimit:  999999,
    description:  'Unlimited devices',
    priceId:      process.env.STRIPE_MSP_SCALE_PRICE_ID!,
  },
};

// ── Middleware: verify caller is an MSP account ───────────────────────────────
async function requireMsp(req: Request, res: Response, next: Function) {
  const customer = (req as any).customer;
  if (!customer) return res.status(401).json({ error: 'Not authenticated' });
  if (customer.accountType !== 'MSP') {
    return res.status(403).json({ error: 'MSP account required. Upgrade on the billing page.' });
  }
  const mspAccount = await prisma.mspAccount.findUnique({
    where:  { customerId: customer.id },
    select: {
      id: true, customerId: true, mspPlan: true, status: true,
      mspSupportEmail: true, stripeCustomerId: true,
      stripeSubscriptionId: true, currentPeriodEnd: true,
      cancelAtPeriodEnd: true,
    },
  });
  if (!mspAccount) return res.status(404).json({ error: 'MSP account not found' });
  (req as any).mspAccount = mspAccount;
  next();
}

// ── POST /api/msp/upgrade — upgrade to MSP, begin Stripe checkout ─────────────
router.post('/upgrade', requireAuth, async (req: Request, res: Response) => {
  const customer = (req as any).customer;
  const { plan = 'MSP_STARTER' } = req.body;

  if (customer.accountType === 'MSP') {
    return res.status(400).json({ error: 'Already an MSP account' });
  }
  if (!MSP_PLANS[plan as keyof typeof MSP_PLANS]) {
    return res.status(400).json({ error: 'Invalid MSP plan. Must be MSP_STARTER, MSP_GROWTH, or MSP_SCALE.' });
  }

  const planConfig = MSP_PLANS[plan as keyof typeof MSP_PLANS];

  // Create Stripe checkout session for the flat MSP plan
  const session = await stripe.checkout.sessions.create({
    mode:           'subscription',
    line_items:     [{ price: planConfig.priceId, quantity: 1 }],
    metadata:       { customerId: customer.id, plan, isMsp: 'true' },
    customer_email: customer.email,
    success_url:    `${process.env.FRONTEND_URL}/msp/upgrade-success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url:     `${process.env.FRONTEND_URL}/dashboard/billing`,
    subscription_data: {
      metadata: { customerId: customer.id, plan, isMsp: 'true' },
    },
  });

  return res.json({ checkoutUrl: session.url });
});

// ── POST /api/msp/activate — called after Stripe checkout completes ───────────
// Stripe webhook handles this, but this endpoint allows immediate activation
// if the customer returns to the success URL before the webhook fires.
router.post('/activate', requireAuth, async (req: Request, res: Response) => {
  const customer = (req as any).customer;
  const { sessionId } = req.body;
  if (!sessionId) return res.status(400).json({ error: 'sessionId required' });

  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ['subscription'],
    });

    if (session.payment_status !== 'paid' && session.status !== 'complete') {
      return res.status(402).json({ error: 'Payment not completed' });
    }

    const plan = session.metadata?.plan as keyof typeof MSP_PLANS;
    if (!plan || !MSP_PLANS[plan]) return res.status(400).json({ error: 'Invalid plan in session' });

    const sub = session.subscription as Stripe.Subscription;

    await activateMspAccount(customer.id, plan, sub.id, session.customer as string);

    return res.json({ ok: true, plan });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ── Helper: activate or upgrade MSP account ───────────────────────────────────
async function activateMspAccount(
  customerId:          string,
  plan:                keyof typeof MSP_PLANS,
  stripeSubscriptionId: string,
  stripeCustomerId:    string,
) {
  const planConfig = MSP_PLANS[plan];

  await prisma.customer.update({
    where: { id: customerId },
    data:  { accountType: 'MSP', plan: 'MSP', planStatus: 'active', deviceLimit: planConfig.deviceLimit },
  });

  await prisma.mspAccount.upsert({
    where:  { customerId },
    create: { customerId, stripeCustomerId, stripeSubscriptionId, mspPlan: plan, status: 'active' },
    update: { stripeCustomerId, stripeSubscriptionId, mspPlan: plan, status: 'active' },
  });

  await prisma.subscription.upsert({
    where:  { customerId },
    create: { customerId, stripeCustomerId, stripeSubscriptionId, plan: 'MSP', status: 'active' },
    update: { stripeCustomerId, stripeSubscriptionId, plan: 'MSP', status: 'active' },
  });

  logger.info(`MSP account activated | customer=${customerId} | plan=${plan}`);
}

export { activateMspAccount };

// ── GET /api/msp/settings ────────────────────────────────────────────────────
router.get('/settings', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  return res.json({
    mspSupportEmail: mspAccount.mspSupportEmail || null,
    status:          mspAccount.status,
  });
});

// ── PUT /api/msp/settings — update MSP support email ─────────────────────────
router.put('/settings', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  const { mspSupportEmail } = req.body;

  if (mspSupportEmail && (!mspSupportEmail.includes('@') || mspSupportEmail.length > 100)) {
    return res.status(400).json({ error: 'Valid support email required' });
  }

  const updated = await prisma.mspAccount.update({
    where: { id: mspAccount.id },
    data:  { mspSupportEmail: mspSupportEmail ? mspSupportEmail.trim().toLowerCase() : null },
  });

  return res.json({ mspSupportEmail: updated.mspSupportEmail });
});

// ── GET /api/msp/dashboard ────────────────────────────────────────────────────
router.get('/dashboard', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;

  const clients = await prisma.mspClient.findMany({
    where:   { mspAccountId: mspAccount.id, active: true },
    orderBy: { createdAt: 'asc' },
    include: {
      _count:  { select: { devices: true, requests: true } },
      builds:  { orderBy: { createdAt: 'desc' }, take: 1 },
    },
  });

  const totalDevices = await prisma.mspDevice.count({
    where: { mspClient: { mspAccountId: mspAccount.id, active: true } },
  });

  const planConfig  = MSP_PLANS[mspAccount.mspPlan as keyof typeof MSP_PLANS] || MSP_PLANS.MSP_STARTER;
  const deviceLimit = planConfig.deviceLimit;
  const pctUsed     = deviceLimit < 999999 ? Math.round((totalDevices / deviceLimit) * 100) : 0;

  const yesterday      = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const recentRequests = await prisma.mspApprovalRequest.count({
    where: { mspClient: { mspAccountId: mspAccount.id }, requestedAt: { gte: yesterday } },
  });

  const safeClients = clients.map(({ ...c }) => c);

  return res.json({
    clients:          safeClients,
    totalClients:     clients.length,
    totalDevices,
    recentRequests,
    plan: {
      key:          mspAccount.mspPlan,
      name:         planConfig.name,
      priceMonthly: planConfig.priceMonthly,
      deviceLimit,
      pctUsed,
      nearLimit:    pctUsed >= 80,
      atLimit:      pctUsed >= 100,
    },
    mspAccount: {
      id:             mspAccount.id,
      status:         mspAccount.status,
      periodEnd:      mspAccount.currentPeriodEnd,
      mspSupportEmail: mspAccount.mspSupportEmail || null,
    },
  });
});

// ── POST /api/msp/clients — add a new client ──────────────────────────────────
router.post('/clients', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  const customer   = (req as any).customer;

  // Check device limit before adding
  const planConfig = MSP_PLANS[mspAccount.mspPlan as keyof typeof MSP_PLANS] || MSP_PLANS.MSP_STARTER;
  if (planConfig.deviceLimit < 999999) {
    const totalDevices = await prisma.mspDevice.count({
      where: { mspClient: { mspAccountId: mspAccount.id, active: true } },
    });
    if (totalDevices >= planConfig.deviceLimit) {
      return res.status(403).json({
        error: `Device limit reached for your ${planConfig.name} plan (${planConfig.deviceLimit} devices). Upgrade to add more clients.`,
        upgradeRequired: true,
      });
    }
  }

  const { clientName, itAdminEmail, companyNotes,
          sessionDurationMinutes, cooldownMinutes,
          approvalTimeoutMinutes, requireApproval, excludedAccounts } = req.body;

  if (!clientName) return res.status(400).json({ error: 'clientName is required' });
  if (typeof clientName !== 'string' || clientName.length > 100) return res.status(400).json({ error: 'clientName too long' });

  // itAdminEmail is optional — if not provided the MSP support email is used
  if (itAdminEmail && (!itAdminEmail.includes('@') || itAdminEmail.length > 100)) {
    return res.status(400).json({ error: 'Valid IT admin email required' });
  }

  // If no client-specific email and no MSP support email — require one of them
  if (!itAdminEmail && !mspAccount.mspSupportEmail) {
    return res.status(400).json({
      error: 'Either provide a client IT admin email or set your MSP support email in dashboard settings first.',
    });
  }

  const apiKey = 'qe_live_' + crypto.randomBytes(32).toString('hex');

  const client = await prisma.mspClient.create({
    data: {
      mspAccountId:           mspAccount.id,
      clientName:             clientName.trim(),
      itAdminEmail:           itAdminEmail ? itAdminEmail.trim().toLowerCase() : null,
      companyNotes:           companyNotes || null,
      apiKey,
      sessionDurationMinutes: sessionDurationMinutes || 60,
      cooldownMinutes:        cooldownMinutes        || 60,
      approvalTimeoutMinutes: approvalTimeoutMinutes || 30,
      requireApproval:        requireApproval        ?? true,
      excludedAccounts:       excludedAccounts       || 'lapsadmin',
    },
  });

  logger.info(`MSP ${mspAccount.id} added client: ${client.id} (${clientName})`);

  triggerMspClientBuild(client).catch(err =>
    logger.error(`Initial build failed for client ${client.id}: ${err.message}`)
  );

  const { apiKey: _, ...safe } = client;
  return res.status(201).json({ client: safe });
});

// ── GET /api/msp/clients ──────────────────────────────────────────────────────
router.get('/clients', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  const clients = await prisma.mspClient.findMany({
    where:   { mspAccountId: mspAccount.id },
    orderBy: { createdAt: 'asc' },
    include: {
      _count:  { select: { devices: true, requests: true } },
      builds:  { orderBy: { createdAt: 'desc' }, take: 1 },
    },
  });
  const safe = clients.map(({ apiKey: _, ...c }) => c);
  return res.json({ clients: safe });
});

// ── GET /api/msp/clients/:id ──────────────────────────────────────────────────
router.get('/clients/:id', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  if (!/^c[a-z0-9]{20,30}$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid client ID' });

  const client = await prisma.mspClient.findFirst({
    where:   { id: req.params.id, mspAccountId: mspAccount.id },
    include: {
      devices:  { orderBy: { lastSeen: 'desc' }, take: 50 },
      builds:   { orderBy: { createdAt: 'desc' }, take: 10 },
      requests: { orderBy: { requestedAt: 'desc' }, take: 20 },
    },
  });
  if (!client) return res.status(404).json({ error: 'Client not found' });
  const { apiKey: _, ...safe } = client;
  return res.json({ client: safe });
});

// ── PUT /api/msp/clients/:id ──────────────────────────────────────────────────
router.put('/clients/:id', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  if (!/^c[a-z0-9]{20,30}$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid client ID' });

  const client = await prisma.mspClient.findFirst({ where: { id: req.params.id, mspAccountId: mspAccount.id } });
  if (!client) return res.status(404).json({ error: 'Client not found' });

  const { clientName, itAdminEmail, companyNotes,
          sessionDurationMinutes, cooldownMinutes,
          approvalTimeoutMinutes, requireApproval, excludedAccounts } = req.body;

  const updated = await prisma.mspClient.update({
    where: { id: req.params.id },
    data:  {
      ...(clientName             && { clientName }),
      ...(itAdminEmail           && { itAdminEmail: itAdminEmail.trim().toLowerCase() }),
      ...(companyNotes !== undefined && { companyNotes }),
      ...(sessionDurationMinutes && { sessionDurationMinutes }),
      ...(cooldownMinutes        && { cooldownMinutes }),
      ...(approvalTimeoutMinutes && { approvalTimeoutMinutes }),
      ...(requireApproval !== undefined && { requireApproval }),
      ...(excludedAccounts       && { excludedAccounts }),
    },
  });
  const { apiKey: _, ...safe } = updated;
  return res.json({ client: safe, rebuildRequired: true });
});

// ── POST /api/msp/clients/:id/rebuild ────────────────────────────────────────
router.post('/clients/:id/rebuild', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  if (!/^c[a-z0-9]{20,30}$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid client ID' });

  const client = await prisma.mspClient.findFirst({ where: { id: req.params.id, mspAccountId: mspAccount.id } });
  if (!client) return res.status(404).json({ error: 'Client not found' });

  const inProgress = await prisma.mspBuild.count({
    where: { mspClientId: client.id, status: { in: ['PENDING', 'BUILDING'] } },
  });
  if (inProgress > 0) return res.status(429).json({ error: 'A build is already in progress for this client' });

  const build = await prisma.mspBuild.create({ data: { mspClientId: client.id, status: 'PENDING' } });

  triggerMspClientBuild(client, build.id).catch(err => {
    logger.error(`Build failed for MSP client ${client.id}: ${err.message}`);
    prisma.mspBuild.update({ where: { id: build.id }, data: { status: 'FAILED', errorMessage: err.message } }).catch(() => {});
  });

  return res.json({ buildId: build.id, status: 'PENDING' });
});

// ── DELETE /api/msp/clients/:id — soft delete ─────────────────────────────────
router.delete('/clients/:id', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  if (!/^c[a-z0-9]{20,30}$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid client ID' });

  const client = await prisma.mspClient.findFirst({ where: { id: req.params.id, mspAccountId: mspAccount.id } });
  if (!client) return res.status(404).json({ error: 'Client not found' });

  await prisma.mspClient.update({ where: { id: req.params.id }, data: { active: false } });
  return res.json({ ok: true });
});

// ── GET /api/msp/billing ──────────────────────────────────────────────────────
router.get('/billing', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;

  const totalDevices = await prisma.mspDevice.count({
    where: { mspClient: { mspAccountId: mspAccount.id, active: true } },
  });

  const currentPlan = MSP_PLANS[mspAccount.mspPlan as keyof typeof MSP_PLANS] || MSP_PLANS.MSP_STARTER;
  const devicesRemaining = currentPlan.deviceLimit < 999999
    ? Math.max(0, currentPlan.deviceLimit - totalDevices)
    : null;

  let stripeDetails = null;
  if (mspAccount.stripeSubscriptionId) {
    try {
      const sub = await stripe.subscriptions.retrieve(mspAccount.stripeSubscriptionId);
      stripeDetails = {
        status:            sub.status,
        currentPeriodEnd:  new Date(sub.current_period_end * 1000),
        cancelAtPeriodEnd: sub.cancel_at_period_end,
      };
    } catch {}
  }

  return res.json({
    currentPlan:      { key: mspAccount.mspPlan, ...currentPlan },
    totalDevices,
    devicesRemaining,
    allPlans:         Object.entries(MSP_PLANS).map(([key, p]) => ({
      key,
      name:         p.name,
      priceMonthly: p.priceMonthly,
      deviceLimit:  p.deviceLimit < 999999 ? p.deviceLimit : null,
      current:      mspAccount.mspPlan === key,
    })),
    subscription: stripeDetails,
  });
});

// ── POST /api/msp/billing/upgrade ─────────────────────────────────────────────
router.post('/billing/upgrade', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  const customer   = (req as any).customer;
  const { plan }   = req.body as { plan: keyof typeof MSP_PLANS };

  if (!MSP_PLANS[plan]) return res.status(400).json({ error: 'Invalid plan' });
  if (mspAccount.mspPlan === plan) return res.status(400).json({ error: 'Already on this plan' });

  const session = await stripe.checkout.sessions.create({
    mode:           'subscription',
    line_items:     [{ price: MSP_PLANS[plan].priceId, quantity: 1 }],
    metadata:       { customerId: customer.id, plan, isMsp: 'true' },
    customer_email: customer.email,
    success_url:    `${process.env.FRONTEND_URL}/msp/upgrade-success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url:     `${process.env.FRONTEND_URL}/msp/billing`,
    subscription_data: { metadata: { customerId: customer.id, plan, isMsp: 'true' } },
  });

  return res.json({ checkoutUrl: session.url });
});

// ── POST /api/msp/billing/portal ──────────────────────────────────────────────
router.post('/billing/portal', requireAuth, requireMsp, async (req: Request, res: Response) => {
  const mspAccount = (req as any).mspAccount;
  if (!mspAccount.stripeCustomerId) return res.status(400).json({ error: 'No billing account found' });

  const session = await stripe.billingPortal.sessions.create({
    customer:   mspAccount.stripeCustomerId,
    return_url: `${process.env.FRONTEND_URL}/msp/billing`,
  });
  return res.json({ portalUrl: session.url });
});

// ── POST /api/msp/build-callback ─────────────────────────────────────────────
router.post('/build-callback', async (req: Request, res: Response) => {
  const incoming = req.headers['x-callback-secret'] as string;
  const secret   = process.env.QE_CALLBACK_SECRET!;

  if (!secret || !incoming ||
      !crypto.timingSafeEqual(Buffer.from(incoming), Buffer.from(secret))) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { buildId, status, blobUrl, blobName, error } = req.body;
  if (!buildId || !status) return res.status(400).json({ error: 'buildId and status required' });
  if (!/^c[a-z0-9]{20,30}$/.test(buildId)) return res.status(400).json({ error: 'Invalid buildId' });
  if (!['SUCCESS', 'FAILED'].includes(status)) return res.status(400).json({ error: 'Invalid status' });

  try {
    if (status === 'SUCCESS') {
      await prisma.mspBuild.update({
        where: { id: buildId },
        data:  { status: 'SUCCESS', blobUrl: blobUrl || null, blobName: blobName || null, builtAt: new Date() },
      });
    } else {
      await prisma.mspBuild.update({
        where: { id: buildId },
        data:  { status: 'FAILED', errorMessage: (error || 'Build failed').slice(0, 500) },
      });
    }
    return res.json({ ok: true });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ── Helper: trigger GitHub build for an MSP client ────────────────────────────
async function triggerMspClientBuild(client: any, buildId?: string): Promise<void> {
  const BACKEND_URL = process.env.BACKEND_URL!;
  const QE_API_URL  = process.env.QE_API_URL || BACKEND_URL;

  if (!buildId) {
    const build = await prisma.mspBuild.create({ data: { mspClientId: client.id, status: 'PENDING' } });
    buildId = build.id;
  }

  const payload = {
    event_type: 'build-pkg',
    client_payload: {
      build_id:      buildId,
      build_type:    'msp_client',
      msp_client_id: client.id,
      callback_url:  `${BACKEND_URL}/api/msp/build-callback`,
      config: {
        QE_API_URL,
        QE_API_KEY:              client.apiKey,
        COMPANY_NAME:            client.clientName,
        SESSION_DURATION_MINUTES: String(client.sessionDurationMinutes),
        COOLDOWN_MINUTES:         String(client.cooldownMinutes),
        APPROVAL_TIMEOUT_MINUTES: String(client.approvalTimeoutMinutes),
        REQUIRE_APPROVAL:         String(client.requireApproval),
        EXCLUDED_ACCOUNTS:        client.excludedAccounts,
      },
    },
  };

  const res = await fetch(
    `https://api.github.com/repos/${process.env.GITHUB_REPO_OWNER}/${process.env.GITHUB_REPO_NAME}/dispatches`,
    {
      method:  'POST',
      headers: {
        Authorization:          `Bearer ${process.env.GITHUB_TOKEN}`,
        Accept:                 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'Content-Type':         'application/json',
      },
      body: JSON.stringify(payload),
    }
  );

  if (res.status !== 204) {
    const body = await res.text();
    throw new Error(`GitHub dispatch failed: HTTP ${res.status} — ${body}`);
  }

  await prisma.mspBuild.update({ where: { id: buildId }, data: { status: 'BUILDING' } });
  logger.info(`MSP client build triggered | client=${client.id} | build=${buildId}`);
}

export { router as mspRouter };
