import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';
import { verifySignature }        from '../middleware/verifySignature';
import { checkDeviceFingerprint } from '../services/deviceFingerprint';
import { sendApprovalEmail, approvalResponsePage, alreadyProcessedPage, expiredPage } from '../services/emailService';
import logger from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

const FREE_GRACE_PERIOD_DAYS = 7;

// ── POST /api/approval/request ────────────────────────────────────────────────
// Protected by:
//   1. HMAC-SHA256 request signature (Protection 2)
//   2. Device fingerprint binding    (Protection 1)
router.post('/request', verifySignature, async (req: Request, res: Response) => {
  // If this is an MSP client API key, forward to MSP approval handler
  if ((req as any).isMspClient) {
    const { mspApprovalRouter } = await import('./mspApproval');
    // Re-route to /request on the MSP approval router
    req.url = '/request';
    return mspApprovalRouter(req, res, () => {
      res.status(500).json({ error: 'MSP approval routing failed' });
    });
  }

  const customer = (req as any).customer;
  const config   = customer.config;

  if (!config?.itAdminEmail) {
    return res.status(400).json({ error: 'Customer setup not complete' });
  }

  const { userName, deviceName, deviceSerial, reason, durationMinutes } = req.body;

  // ── Input presence check ─────────────────────────────────────────────────
  if (!userName || !deviceName || !deviceSerial || !reason || !durationMinutes) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // ── Input validation ─────────────────────────────────────────────────────
  const MAX_LEN = { userName: 64, deviceName: 64, deviceSerial: 32, reason: 500 };
  if (typeof userName     !== 'string' || userName.length     > MAX_LEN.userName)    return res.status(400).json({ error: 'userName too long or invalid'     });
  if (typeof deviceName   !== 'string' || deviceName.length   > MAX_LEN.deviceName)  return res.status(400).json({ error: 'deviceName too long or invalid'   });
  if (typeof deviceSerial !== 'string' || deviceSerial.length > MAX_LEN.deviceSerial)return res.status(400).json({ error: 'deviceSerial too long or invalid'  });
  if (typeof reason       !== 'string' || reason.length       > MAX_LEN.reason)      return res.status(400).json({ error: 'reason too long or invalid'        });
  if (typeof durationMinutes !== 'number' || ![15, 30, 60, 120, 240].includes(durationMinutes)) {
    return res.status(400).json({ error: 'durationMinutes must be 15, 30, 60, or 120' });
  }

  // HTML-strip free-text fields (defence in depth for email rendering)
  const sanitize     = (s: string) => s.replace(/<[^>]*>/g, '').trim();
  const safeUserName   = sanitize(userName);
  const safeDeviceName = sanitize(deviceName);
  const safeReason     = sanitize(reason);

  // ── Protection 1: Device fingerprint check ────────────────────────────────
  const fingerprint = await checkDeviceFingerprint(
    customer.id,
    deviceSerial,
    safeDeviceName,
    config.itAdminEmail,
    customer.companyName,
    req,
  );

  if (!fingerprint.allowed) {
    logger.warn(`Quarantined device blocked | serial=${deviceSerial} | customer=${customer.id}`);
    return res.status(403).json({
      error: 'This device has been quarantined by your IT administrator. Please contact IT support.',
    });
  }

  // ── Device limit enforcement ──────────────────────────────────────────────
  const deviceCount = await prisma.device.count({ where: { customerId: customer.id } });

  if (deviceCount > customer.deviceLimit) {
    const isFree = customer.plan === 'FREE' || customer.plan === 'TRIAL';

    if (isFree) {
      if (!customer.overLimitSince) {
        await prisma.customer.update({
          where: { id: customer.id },
          data:  { overLimitSince: new Date() } as any,
        });
      }

      const gracePeriodEnds = new Date(customer.overLimitSince || new Date());
      gracePeriodEnds.setDate(gracePeriodEnds.getDate() + FREE_GRACE_PERIOD_DAYS);
      const daysLeft = Math.ceil((gracePeriodEnds.getTime() - Date.now()) / (1000 * 60 * 60 * 24));

      if (daysLeft <= 0) {
        return res.status(403).json({
          error:           'Free plan device limit exceeded. Please upgrade your plan.',
          upgradeRequired: true,
        });
      }
    } else {
      const planNames: Record<string, string> = {
        GROWTH:     'Growth (75 devices)',
        BUSINESS:   'Business (200 devices)',
        ENTERPRISE: 'Enterprise (500 devices)',
      };
      return res.status(403).json({
        error:           `Device limit reached for ${planNames[customer.plan] || customer.plan}. Contact your IT administrator.`,
        upgradeRequired: true,
      });
    }
  }

  // ── Create approval request ───────────────────────────────────────────────
  const approveToken = crypto.randomBytes(32).toString('hex');
  const denyToken    = crypto.randomBytes(32).toString('hex');
  const expiresAt    = new Date(Date.now() + config.approvalTimeoutMinutes * 60 * 1000);

  const request = await prisma.approvalRequest.create({
    data: {
      customerId:     customer.id,
      userName:       safeUserName,
      deviceName:     safeDeviceName,
      deviceSerial,
      reason:         safeReason,
      durationMinutes,
      approveToken,
      denyToken,
      expiresAt,
    },
  });

  // Send approval email (fire and forget — Mac does not wait)
  sendApprovalEmail({
    toEmail:         config.itAdminEmail,
    companyName:     customer.companyName,
    userName:        safeUserName,
    deviceName:      safeDeviceName,
    reason:          safeReason,
    durationMinutes,
    requestId:       request.id,
    approveToken,
    denyToken,
    expiresAt,
  }).catch(err => logger.error(`Approval email failed for ${request.id}: ${err.message}`));

  logger.info(`Request ${request.id} created | user=${safeUserName} | device=${deviceSerial} | suspect=${fingerprint.isSuspect}`);

  return res.json({
    requestId: request.id,
    expiresAt: expiresAt.toISOString(),
    // If flagged as suspect, warn the Mac so it can log it locally
    ...(fingerprint.isSuspect && {
      securityWarning: 'This request was submitted from an unrecognised network location. Your IT admin has been notified.',
    }),
  });
});

// ── GET /api/approval/status/:requestId ──────────────────────────────────────
// Also signed — prevents status polling without a valid key + fresh signature
router.get('/status/:requestId', verifySignature, async (req: Request, res: Response) => {
  // Forward MSP client status checks
  if ((req as any).isMspClient) {
    const { mspApprovalRouter } = await import('./mspApproval');
    req.url = `/status/${req.params.requestId}`;
    return mspApprovalRouter(req, res, () => {
      res.status(500).json({ error: 'MSP status routing failed' });
    });
  }
  const customer = (req as any).customer;

  // Validate requestId format
  if (!/^c[a-z0-9]{20,30}$/.test(req.params.requestId)) {
    return res.status(400).json({ error: 'Invalid request ID format' });
  }

  const request = await prisma.approvalRequest.findFirst({
    where: { id: req.params.requestId, customerId: customer.id },
  });

  if (!request) return res.status(404).json({ error: 'Request not found' });

  if (request.status === 'pending' && new Date() > request.expiresAt) {
    await prisma.approvalRequest.update({
      where: { id: request.id },
      data:  { status: 'expired', resolvedAt: new Date() },
    });
    return res.json({ status: 'expired' });
  }

  return res.json({ status: request.status });
});

// ── GET /api/approval/approve/:token ─────────────────────────────────────────
// IT admin clicks Approve — no signature needed, single-use token IS the auth
router.get('/approve/:token', async (req: Request, res: Response) => {
  if (!/^[a-f0-9]{64}$/.test(req.params.token)) return res.status(400).send('<h1>Invalid token</h1>');

  const request = await prisma.approvalRequest.findUnique({ where: { approveToken: req.params.token } });
  if (!request)                     return res.status(404).send('<h1>Not found</h1>');
  if (request.status !== 'pending') return res.send(alreadyProcessedPage(request.status));
  if (new Date() > request.expiresAt) {
    await prisma.approvalRequest.update({ where: { id: request.id }, data: { status: 'expired', resolvedAt: new Date() } });
    return res.send(expiredPage());
  }

  await prisma.approvalRequest.update({ where: { id: request.id }, data: { status: 'approved', resolvedAt: new Date() } });
  logger.info(`Request ${request.id} APPROVED for ${request.userName} on ${request.deviceName}`);
  return res.send(approvalResponsePage('approved', request.userName, request.deviceName));
});

// ── GET /api/approval/deny/:token ────────────────────────────────────────────
router.get('/deny/:token', async (req: Request, res: Response) => {
  if (!/^[a-f0-9]{64}$/.test(req.params.token)) return res.status(400).send('<h1>Invalid token</h1>');

  const request = await prisma.approvalRequest.findUnique({ where: { denyToken: req.params.token } });
  if (!request)                     return res.status(404).send('<h1>Not found</h1>');
  if (request.status !== 'pending') return res.send(alreadyProcessedPage(request.status));
  if (new Date() > request.expiresAt) {
    await prisma.approvalRequest.update({ where: { id: request.id }, data: { status: 'expired', resolvedAt: new Date() } });
    return res.send(expiredPage());
  }

  await prisma.approvalRequest.update({ where: { id: request.id }, data: { status: 'denied', resolvedAt: new Date() } });
  logger.info(`Request ${request.id} DENIED for ${request.userName} on ${request.deviceName}`);
  return res.send(approvalResponsePage('denied', request.userName, request.deviceName));
});

export { router as approvalRouter };
