import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import Stripe from 'stripe';

const router = Router();
const prisma = new PrismaClient();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// ── Plan definitions — single source of truth ─────────────────────────────────
export const PLANS = {
  FREE: {
    name:         'Free',
    priceMonthly: 0,
    deviceLimit:  25,
  },
  GROWTH: {
    name:         'Growth',
    priceMonthly: 49,
    deviceLimit:  75,
  },
  BUSINESS: {
    name:         'Business',
    priceMonthly: 99,
    deviceLimit:  200,
  },
  ENTERPRISE: {
    name:         'Enterprise',
    priceMonthly: 249,
    deviceLimit:  500,
  },
  // Legacy alias so existing records are not broken
  TRIAL: {
    name:         'Free',
    priceMonthly: 0,
    deviceLimit:  25,
  },
};

// ── POST /api/webhooks/stripe ─────────────────────────────────────────────────
router.post('/stripe', async (req: Request, res: Response) => {
  const sig = req.headers['stripe-signature']!;
  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    return res.status(400).json({ error: 'Invalid webhook signature' });
  }

  const data = event.data.object as any;

  switch (event.type) {

    case 'checkout.session.completed': {
      const customerId = data.metadata?.customerId;
      const plan       = data.metadata?.plan as keyof typeof PLANS;
      const isMsp      = data.metadata?.isMsp === 'true';
      if (!customerId || !plan) break;

      if (isMsp) {
        // MSP checkout — activate via MSP handler
        const { activateMspAccount } = await import('./msp');
        const { MSP_PLANS } = await import('./msp');
        const mspPlan = plan as keyof typeof MSP_PLANS;
        if (MSP_PLANS[mspPlan]) {
          await activateMspAccount(customerId, mspPlan, data.subscription, data.customer);
        }
        break;
      }

      if (!PLANS[plan]) break;
      const deviceLimit = PLANS[plan].deviceLimit;

      await prisma.subscription.upsert({
        where:  { customerId },
        create: { customerId, stripeCustomerId: data.customer, stripeSubscriptionId: data.subscription, plan, status: 'active' },
        update: { stripeCustomerId: data.customer, stripeSubscriptionId: data.subscription, plan, status: 'active' },
      });

      await prisma.customer.update({
        where: { id: customerId },
        data:  { plan, deviceLimit, planStatus: 'active' },
      });

      console.log(`Customer ${customerId} upgraded to ${plan} — device limit: ${deviceLimit}`);
      break;
    }

    case 'customer.subscription.updated': {
      const sub        = data as Stripe.Subscription;
      const customerId = sub.metadata?.customerId;
      if (!customerId) break;

      const priceId = sub.items?.data[0]?.price?.id;
      let newPlan: keyof typeof PLANS | null = null;
      if (priceId === process.env.STRIPE_GROWTH_PRICE_ID)       newPlan = 'GROWTH';
      if (priceId === process.env.STRIPE_BUSINESS_PRICE_ID)     newPlan = 'BUSINESS';
      if (priceId === process.env.STRIPE_ENTERPRISE_PRICE_ID)   newPlan = 'ENTERPRISE';
      // MSP plans
      const isMspPlan = [
        process.env.STRIPE_MSP_STARTER_PRICE_ID,
        process.env.STRIPE_MSP_GROWTH_PRICE_ID,
        process.env.STRIPE_MSP_SCALE_PRICE_ID,
      ].includes(priceId);
      if (isMspPlan) newPlan = 'MSP';

      const updateData: any = {
        status:             sub.status,
        currentPeriodStart: new Date(sub.current_period_start * 1000),
        currentPeriodEnd:   new Date(sub.current_period_end   * 1000),
        cancelAtPeriodEnd:  sub.cancel_at_period_end,
      };
      if (newPlan) updateData.plan = newPlan;

      await prisma.subscription.update({
        where: { stripeSubscriptionId: sub.id },
        data:  updateData,
      });

      if (newPlan) {
        await prisma.customer.update({
          where: { id: customerId },
          data: {
            plan:        newPlan,
            deviceLimit: PLANS[newPlan].deviceLimit,
            planStatus:  sub.status === 'active' ? 'active' : 'past_due',
          },
        });
      }
      break;
    }

    case 'customer.subscription.deleted': {
      const sub        = data as Stripe.Subscription;
      const customerId = sub.metadata?.customerId;
      if (!customerId) break;

      await prisma.subscription.update({
        where: { stripeSubscriptionId: sub.id },
        data:  { status: 'cancelled' },
      });

      // Revert to Free plan limits — they keep 25 devices free forever
      // Check if this was an MSP subscription
      const wasMsp = sub.metadata?.isMsp === 'true';
      if (wasMsp) {
        await prisma.customer.update({
          where: { id: customerId },
          data:  { plan: 'FREE', accountType: 'DIRECT', planStatus: 'active', deviceLimit: PLANS.FREE.deviceLimit },
        });
        await prisma.mspAccount.updateMany({
          where: { customerId },
          data:  { status: 'cancelled' },
        });
      } else {
        await prisma.customer.update({
          where: { id: customerId },
          data:  { plan: 'FREE', planStatus: 'active', deviceLimit: PLANS.FREE.deviceLimit },
        });
      }
      break;
    }

    case 'invoice.payment_failed': {
      const stripeCustomerId = data.customer;
      await prisma.customer.updateMany({
        where: { subscription: { stripeCustomerId } },
        data:  { planStatus: 'past_due' },
      });
      break;
    }
  }

  return res.json({ received: true });
});

// ── POST /api/webhooks/clerk ───────────────────────────────────────────────────
router.post('/clerk', async (req: Request, res: Response) => {
  try {
    const event = req.body;

    if (event.type === 'user.created') {
      const { id, email_addresses, first_name, last_name } = event.data;
      const email = email_addresses[0]?.email_address;

      await prisma.customer.create({
        data: {
          clerkUserId: id,
          email,
          companyName: `${first_name || ''} ${last_name || ''}`.trim() || email,
          plan:        'FREE',
          deviceLimit: PLANS.FREE.deviceLimit,   // 25 devices free forever
          planStatus:  'active',
        },
      });
    }

    if (event.type === 'user.deleted') {
      await prisma.customer.deleteMany({
        where: { clerkUserId: event.data.id },
      });
    }

    return res.json({ received: true });
  } catch (err: any) {
    console.error('Clerk webhook error:', err.message);
    return res.status(500).json({ error: 'Webhook handler failed' });
  }
});

export { router as webhookRouter };
