import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import crypto from 'crypto';

import { authRouter }     from './routes/auth';
import { approvalRouter } from './routes/approval';
import { customerRouter } from './routes/customer';
import { configRouter }   from './routes/config';
import { buildRouter }    from './routes/build';
import { billingRouter }  from './routes/billing';
import { webhookRouter }  from './routes/webhook';
import { adminRouter }    from './routes/admin';
import { mspRouter }      from './routes/msp';
import { mspApprovalRouter } from './routes/mspApproval';
import { errorHandler }   from './middleware/errorHandler';
import { requireAuth }    from './middleware/requireAuth';
import logger             from './utils/logger';

dotenv.config();

// ── Validate required env vars on startup ─────────────────────────────────────
const REQUIRED_ENV = [
  'DATABASE_URL', 'CLERK_SECRET_KEY', 'RESEND_API_KEY',
  'BACKEND_URL', 'GITHUB_TOKEN', 'QE_CALLBACK_SECRET',
  'AZURE_STORAGE_CONNECTION_STRING',
];
const missing = REQUIRED_ENV.filter(k => !process.env[k]);
if (missing.length > 0) {
  logger.error(`Missing required environment variables: ${missing.join(', ')}`);
  process.exit(1);
}

const app  = express();
const PORT = process.env.PORT || 4000;

// ── Security headers (helmet) ─────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:  ["'self'"],
      scriptSrc:   ["'self'"],
      styleSrc:    ["'self'", "'unsafe-inline'"],
      imgSrc:      ["'self'", 'data:'],
      connectSrc:  ["'self'"],
      frameSrc:    ["'none'"],
      objectSrc:   ["'none'"],
    },
  },
  hsts: {
    maxAge:            31536000,
    includeSubDomains: true,
    preload:           true,
  },
}));

// ── CORS — only allow your frontend ──────────────────────────────────────────
const ALLOWED_ORIGINS = [
  process.env.FRONTEND_URL || 'http://localhost:3000',
  'http://localhost:3000',
].filter(Boolean);

app.use(cors({
  origin: (origin, callback) => {
    // Allow no-origin requests (curl, Postman) only in dev
    if (!origin && process.env.NODE_ENV !== 'production') return callback(null, true);
    if (!origin || ALLOWED_ORIGINS.includes(origin)) return callback(null, true);
    callback(new Error(`CORS: origin ${origin} not allowed`));
  },
  credentials: true,
}));

// ── Stripe/Clerk webhooks need raw body — MUST come before json() ─────────────
app.use('/api/webhooks/stripe', express.raw({ type: 'application/json', limit: '100kb' }));
app.use('/api/webhooks/clerk',  express.raw({ type: 'application/json', limit: '100kb' }));

// ── Body parsing with size limits ─────────────────────────────────────────────
app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ extended: true, limit: '50kb' }));

// ── Request logging ───────────────────────────────────────────────────────────
app.use(morgan('combined', {
  stream: { write: (msg) => logger.info(msg.trim()) },
  // Don't log health checks
  skip: (req) => req.path === '/health',
}));

// ── Rate limiting ─────────────────────────────────────────────────────────────
// General API limit
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max:      100,
  message:  { error: 'Too many requests — please try again later.' },
  standardHeaders: true,
  legacyHeaders:   false,
});

// Tighter limit for auth routes (prevent brute force)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max:      20,
  message:  { error: 'Too many authentication attempts — please try again later.' },
  standardHeaders: true,
  legacyHeaders:   false,
});

// Per-API-key limit for Mac approval requests (100 requests per hour per key)
const approvalLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max:      100,
  keyGenerator: (req) => req.headers['x-api-key'] as string || req.ip || 'unknown',
  message:  { error: 'Too many approval requests from this device — please try again later.' },
  standardHeaders: true,
  legacyHeaders:   false,
  skip: (req) => req.path.startsWith('/approve/') || req.path.startsWith('/deny/'),
});

// Build callback — allow bursts from GitHub Actions
const callbackLimiter = rateLimit({
  windowMs: 60 * 1000,
  max:      30,
  message:  { error: 'Too many callback requests.' },
});

app.use('/api/', generalLimiter);
app.use('/api/auth', authLimiter);
app.use('/api/approval', approvalLimiter);
app.use('/api/build/callback', callbackLimiter);

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', version: '1.0.0' }));

// ── Public routes ─────────────────────────────────────────────────────────────
app.use('/api/auth',     authRouter);
app.use('/api/approval', approvalRouter);
app.use('/api/webhooks', webhookRouter);

// ── Protected routes ─────────────────────────────────────────────────────────
app.use('/api/customer', requireAuth, customerRouter);
app.use('/api/config',   requireAuth, configRouter);
app.use('/api/build',    buildRouter);   // callback is public; trigger/status/download use requireAuth inside
app.use('/api/billing',  requireAuth, billingRouter);

// ── Internal admin routes ─────────────────────────────────────────────────────
app.use('/api/admin',        requireAuth, adminRouter);
app.use('/api/msp',          requireAuth, mspRouter);
app.use('/api/msp-approval', mspApprovalRouter);

// ── 404 handler ───────────────────────────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ error: 'Not found' }));

// ── Error handler ─────────────────────────────────────────────────────────────
app.use(errorHandler);

app.listen(PORT, () => {
  logger.info(`QuickElevate API running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
});

export default app;
