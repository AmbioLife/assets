import { PrismaClient } from '@prisma/client';
import logger from '../utils/logger';

const prisma = new PrismaClient();

const GITHUB_TOKEN       = process.env.GITHUB_TOKEN!;
const GITHUB_REPO_OWNER  = process.env.GITHUB_REPO_OWNER!;
const GITHUB_REPO_NAME   = process.env.GITHUB_REPO_NAME!;
const BACKEND_URL        = process.env.BACKEND_URL!;
const QE_API_URL  = process.env.QE_API_URL || 'https://api.quickelevate.io';

export async function triggerGitHubBuild(customer: any, buildId: string): Promise<void> {
  if (!GITHUB_TOKEN || !GITHUB_REPO_OWNER || !GITHUB_REPO_NAME) {
    throw new Error('GitHub Actions not configured — set GITHUB_TOKEN, GITHUB_REPO_OWNER, GITHUB_REPO_NAME');
  }

  const config = customer.config;

  const payload = {
    event_type: 'build-pkg',
    client_payload: {
      build_id:     buildId,
      customer_id:  customer.id,
      callback_url: `${BACKEND_URL}/api/build/callback`,
      config: {
        QE_API_URL:          QE_API_URL,
        QE_API_KEY:          customer.apiKey,
        COMPANY_NAME:               customer.companyName,
        SESSION_DURATION_MINUTES:   String(config.sessionDurationMinutes  || 60),
        COOLDOWN_MINUTES:           String(config.cooldownMinutes          || 60),
        APPROVAL_TIMEOUT_MINUTES:   String(config.approvalTimeoutMinutes   || 30),
        REQUIRE_APPROVAL:           String(config.requireApproval          ?? true),
        EXCLUDED_ACCOUNTS:          config.excludedAccounts               || 'lapsadmin',
      },
    },
  };

  logger.info(`Triggering GitHub Actions build | customer=${customer.id} | build=${buildId}`);

  const res = await fetch(
    `https://api.github.com/repos/${GITHUB_REPO_OWNER}/${GITHUB_REPO_NAME}/dispatches`,
    {
      method:  'POST',
      headers: {
        Authorization:           `Bearer ${GITHUB_TOKEN}`,
        Accept:                  'application/vnd.github+json',
        'X-GitHub-Api-Version':  '2022-11-28',
        'Content-Type':          'application/json',
      },
      body: JSON.stringify(payload),
    }
  );

  if (res.status !== 204) {
    const body = await res.text();
    throw new Error(`GitHub dispatch failed: HTTP ${res.status} — ${body}`);
  }

  logger.info(`GitHub dispatch accepted for build ${buildId}`);

  await prisma.pkgBuild.update({
    where: { id: buildId },
    data:  { status: 'BUILDING' },
  });
}
