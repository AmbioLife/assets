import logger from '../utils/logger';

const RESEND_API_KEY = process.env.RESEND_API_KEY!;
const FROM_EMAIL    = process.env.FROM_EMAIL || 'QuickElevate <noreply@quickelevate.com>';
const BACKEND_URL   = process.env.BACKEND_URL!;

// HTML-escape all values that go into email templates
function esc(s: string): string {
  return String(s)
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;')
    .replace(/'/g,  '&#x27;');
}



interface ApprovalEmailParams {
  toEmail:        string;
  companyName:    string;
  userName:       string;
  deviceName:     string;
  reason:         string;
  durationMinutes: number;
  requestId:      string;
  approveToken:   string;
  denyToken:      string;
  expiresAt:      Date;
}

export async function sendApprovalEmail(p: ApprovalEmailParams): Promise<void> {
  const approveUrl = `${BACKEND_URL}/api/approval/approve/${p.approveToken}`;
  const denyUrl    = `${BACKEND_URL}/api/approval/deny/${p.denyToken}`;
  const expiryStr  = p.expiresAt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', timeZoneName: 'short' });
  const duration   = p.durationMinutes >= 60 ? `${p.durationMinutes / 60} hour${p.durationMinutes > 60 ? 's' : ''}` : `${p.durationMinutes} minutes`;

  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
  <div style="max-width:560px;margin:40px auto;padding:0 16px">

    <!-- Header -->
    <div style="background:#1e1b4b;border-radius:12px 12px 0 0;padding:28px 32px">
      <div style="display:flex;align-items:center;gap:12px">
        <span style="font-size:28px">🔐</span>
        <div>
          <div style="color:#fff;font-size:18px;font-weight:700">Admin Access Request</div>
          <div style="color:#a5b4fc;font-size:13px;margin-top:2px">${esc(p.companyName)}</div>
        </div>
      </div>
    </div>

    <!-- Body -->
    <div style="background:#fff;border:1px solid #e2e8f0;border-top:none;padding:32px;border-radius:0 0 12px 12px">
      <p style="margin:0 0 24px;font-size:15px;color:#374151">
        A user is requesting temporary local administrator access and needs your approval.
      </p>

      <!-- Details table -->
      <table style="width:100%;border-collapse:collapse;margin-bottom:28px;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0">
        <tr style="background:#f8fafc">
          <td style="padding:11px 16px;font-weight:600;font-size:13px;color:#475569;width:110px">User</td>
          <td style="padding:11px 16px;font-size:14px;color:#111827;font-weight:500">${esc(p.userName)}</td>
        </tr>
        <tr>
          <td style="padding:11px 16px;font-weight:600;font-size:13px;color:#475569">Device</td>
          <td style="padding:11px 16px;font-size:14px;color:#111827">${esc(p.deviceName)}</td>
        </tr>
        <tr style="background:#f8fafc">
          <td style="padding:11px 16px;font-weight:600;font-size:13px;color:#475569">Reason</td>
          <td style="padding:11px 16px;font-size:14px;color:#111827">${esc(p.reason)}</td>
        </tr>
        <tr>
          <td style="padding:11px 16px;font-weight:600;font-size:13px;color:#475569">Duration</td>
          <td style="padding:11px 16px;font-size:14px;color:#111827">${esc(duration)}</td>
        </tr>
        <tr style="background:#f8fafc">
          <td style="padding:11px 16px;font-weight:600;font-size:13px;color:#475569">Expires</td>
          <td style="padding:11px 16px;font-size:14px;color:#dc2626">Request expires at ${esc(expiryStr)}</td>
        </tr>
      </table>

      <!-- Buttons -->
      <div style="text-align:center;margin:32px 0 24px">
        <a href="${approveUrl}"
           style="display:inline-block;padding:14px 40px;background:#16a34a;color:#fff;text-decoration:none;border-radius:8px;font-size:15px;font-weight:700;margin-right:12px;letter-spacing:0.01em">
          ✓ Approve
        </a>
        <a href="${denyUrl}"
           style="display:inline-block;padding:14px 40px;background:#dc2626;color:#fff;text-decoration:none;border-radius:8px;font-size:15px;font-weight:700;letter-spacing:0.01em">
          ✕ Deny
        </a>
      </div>

      <p style="font-size:12px;color:#94a3b8;text-align:center;margin:0">
        Admin rights are automatically revoked after the session expires.<br>
        Request ID: <code style="font-family:monospace">${esc(p.requestId)}</code>
      </p>
    </div>

    <!-- Footer -->
    <p style="text-align:center;font-size:11px;color:#94a3b8;margin:16px 0">
      Powered by QuickElevate · <a href="https://quickelevate.com" style="color:#6366f1;text-decoration:none">quickelevate.com</a>
    </p>
  </div>
</body>
</html>`;

  const res = await fetch('https://api.resend.com/emails', {
    method:  'POST',
    headers: {
      'Authorization': `Bearer ${RESEND_API_KEY}`,
      'Content-Type':  'application/json',
    },
    body: JSON.stringify({
      from:    FROM_EMAIL,
      to:      [p.toEmail],
      subject: `[Admin Request] ${esc(p.userName)} on ${esc(p.deviceName)}`,
      html,
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Resend API error: HTTP ${res.status} — ${err}`);
  }

  logger.info(`Approval email sent to ${p.toEmail} for request ${esc(p.requestId)}`);
}

// ── HTML response pages served directly to the IT admin's browser ─────────────
export function approvalResponsePage(action: 'approved' | 'denied', userName: string, deviceName: string): string {
  const isApproved = action === 'approved';
  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Request ${isApproved ? 'Approved' : 'Denied'}</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh">
  <div style="background:#fff;border-radius:16px;padding:48px 40px;max-width:400px;width:90%;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
    <div style="font-size:56px;margin-bottom:16px">${isApproved ? '✅' : '❌'}</div>
    <h1 style="margin:0 0 8px;font-size:24px;color:${isApproved ? '#16a34a' : '#dc2626'}">
      Request ${isApproved ? 'Approved' : 'Denied'}
    </h1>
    <p style="color:#64748b;font-size:15px;margin:0 0 24px">
      ${isApproved
        ? `Admin access for <strong>${userName}</strong> on <strong>${deviceName}</strong> has been approved. Their Mac will detect this within 30 seconds.`
        : `Admin access for <strong>${userName}</strong> on <strong>${deviceName}</strong> has been denied. They have been notified.`
      }
    </p>
    <p style="color:#94a3b8;font-size:13px;margin:0">You can close this tab.</p>
  </div>
</body>
</html>`;
}

export function alreadyProcessedPage(status: string): string {
  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Already Processed</title></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh">
  <div style="background:#fff;border-radius:16px;padding:48px 40px;max-width:400px;width:90%;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
    <div style="font-size:56px;margin-bottom:16px">ℹ️</div>
    <h1 style="margin:0 0 8px;font-size:24px;color:#3b82f6">Already Processed</h1>
    <p style="color:#64748b;font-size:15px;margin:0 0 24px">This request has already been <strong>${status}</strong>.</p>
    <p style="color:#94a3b8;font-size:13px;margin:0">You can close this tab.</p>
  </div>
</body>
</html>`;
}

export function expiredPage(): string {
  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Request Expired</title></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh">
  <div style="background:#fff;border-radius:16px;padding:48px 40px;max-width:400px;width:90%;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
    <div style="font-size:56px;margin-bottom:16px">⏱️</div>
    <h1 style="margin:0 0 8px;font-size:24px;color:#f59e0b">Request Expired</h1>
    <p style="color:#64748b;font-size:15px;margin:0 0 24px">This approval request has expired. The user will need to submit a new request.</p>
    <p style="color:#94a3b8;font-size:13px;margin:0">You can close this tab.</p>
  </div>
</body>
</html>`;
}

// ── Security alert email — sent to IT admin when a device is seen from a new subnet ──
interface SecurityAlertParams {
  toEmail:      string;
  companyName:  string;
  serialNumber: string;
  deviceName:   string;
  knownIp:      string;
  newIp:        string;
  knownSubnets: string[];
  newSubnet:    string;
}

export async function sendSecurityAlertEmail(p: SecurityAlertParams): Promise<void> {
  const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
  <div style="max-width:560px;margin:40px auto;padding:0 16px">
    <div style="background:#7f1d1d;border-radius:12px 12px 0 0;padding:24px 32px">
      <div style="display:flex;align-items:center;gap:12px">
        <span style="font-size:28px">⚠️</span>
        <div>
          <div style="color:#fff;font-size:18px;font-weight:700">Security Alert — New Network Location</div>
          <div style="color:#fca5a5;font-size:13px;margin-top:2px">${esc(p.companyName)}</div>
        </div>
      </div>
    </div>
    <div style="background:#fff;border:1px solid #e2e8f0;border-top:none;padding:32px;border-radius:0 0 12px 12px">
      <p style="margin:0 0 20px;font-size:15px;color:#374151">
        A Mac that has the QuickElevate installer submitted an admin request from an
        <strong>unrecognised network location</strong>. This may be normal (VPN, new office, working from home)
        — but you should verify.
      </p>
      <table style="width:100%;border-collapse:collapse;margin-bottom:24px;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0">
        <tr style="background:#f8fafc">
          <td style="padding:10px 16px;font-weight:600;font-size:13px;color:#475569;width:130px">Device</td>
          <td style="padding:10px 16px;font-size:14px;color:#111827">${esc(p.deviceName)}</td>
        </tr>
        <tr>
          <td style="padding:10px 16px;font-weight:600;font-size:13px;color:#475569">Serial</td>
          <td style="padding:10px 16px;font-size:14px;font-family:monospace;color:#111827">${esc(p.serialNumber)}</td>
        </tr>
        <tr style="background:#f8fafc">
          <td style="padding:10px 16px;font-weight:600;font-size:13px;color:#475569">Last known IP</td>
          <td style="padding:10px 16px;font-size:14px;font-family:monospace;color:#111827">${esc(p.knownIp)}</td>
        </tr>
        <tr>
          <td style="padding:10px 16px;font-weight:600;font-size:13px;color:#475569">New IP</td>
          <td style="padding:10px 16px;font-size:14px;font-family:monospace;color:#dc2626;font-weight:600">${esc(p.newIp)}</td>
        </tr>
        <tr style="background:#f8fafc">
          <td style="padding:10px 16px;font-weight:600;font-size:13px;color:#475569">Known subnets</td>
          <td style="padding:10px 16px;font-size:13px;font-family:monospace;color:#475569">${esc(p.knownSubnets.join(', '))}.x</td>
        </tr>
      </table>
      <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:16px;margin-bottom:24px">
        <p style="margin:0;font-size:13px;color:#991b1b;font-weight:600">If you do not recognise this activity:</p>
        <p style="margin:6px 0 0;font-size:13px;color:#991b1b">Log in to your QuickElevate dashboard and quarantine this device immediately. Do not approve any pending requests from this device until you have verified it.</p>
      </div>
      <p style="font-size:12px;color:#94a3b8;margin:0">
        This alert was sent because the request IP subnet did not match any previously known location for this device.<br>
        Serial: <code style="font-family:monospace">${esc(p.serialNumber)}</code>
      </p>
    </div>
    <p style="text-align:center;font-size:11px;color:#94a3b8;margin:16px 0">
      Powered by QuickElevate · <a href="https://quickelevate.com" style="color:#6366f1;text-decoration:none">quickelevate.com</a>
    </p>
  </div>
</body>
</html>`;

  const res = await fetch('https://api.resend.com/emails', {
    method:  'POST',
    headers: {
      'Authorization': `Bearer ${RESEND_API_KEY}`,
      'Content-Type':  'application/json',
    },
    body: JSON.stringify({
      from:    FROM_EMAIL,
      to:      [p.toEmail],
      subject: `[Security Alert] ${p.deviceName} seen from new network location`,
      html,
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Resend API error: HTTP ${res.status} — ${err}`);
  }
}
