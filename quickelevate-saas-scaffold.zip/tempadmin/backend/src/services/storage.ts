import { BlobServiceClient, generateBlobSASQueryParameters, BlobSASPermissions, StorageSharedKeyCredential } from '@azure/storage-blob';
import fs from 'fs';
import logger from '../utils/logger';

const connectionString = process.env.AZURE_STORAGE_CONNECTION_STRING!;
const containerName    = process.env.AZURE_STORAGE_CONTAINER || 'pkg-builds';

function getBlobClient() {
  return BlobServiceClient.fromConnectionString(connectionString);
}

export async function uploadPkg(localPath: string, blobName: string): Promise<string> {
  const blobServiceClient = getBlobClient();
  const containerClient   = blobServiceClient.getContainerClient(containerName);

  await containerClient.createIfNotExists({ access: 'private' });

  const blockBlobClient = containerClient.getBlockBlobClient(blobName);
  const fileStream      = fs.createReadStream(localPath);
  const fileSize        = fs.statSync(localPath).size;

  await blockBlobClient.uploadStream(fileStream, fileSize, undefined, {
    blobHTTPHeaders: { blobContentType: 'application/octet-stream' },
  });

  logger.info(`Uploaded pkg to blob: ${blobName}`);
  return blockBlobClient.url;
}

export async function generateDownloadUrl(blobUrl: string): Promise<string> {
  // Extract blob name from URL
  const url      = new URL(blobUrl);
  const blobName = url.pathname.replace(`/${containerName}/`, '');

  const blobServiceClient = getBlobClient();
  const containerClient   = blobServiceClient.getContainerClient(containerName);
  const blockBlobClient   = containerClient.getBlockBlobClient(blobName);

  // Generate SAS URL valid for 15 minutes
  const expiresOn = new Date(Date.now() + 15 * 60 * 1000);

  const sasUrl = await blockBlobClient.generateSasUrl({
    permissions: BlobSASPermissions.parse('r'),
    expiresOn,
    contentDisposition: 'attachment; filename="RequestAdminAccess.pkg"',
  });

  return sasUrl;
}

export async function deletePkg(blobName: string): Promise<void> {
  const blobServiceClient = getBlobClient();
  const containerClient   = blobServiceClient.getContainerClient(containerName);
  await containerClient.deleteBlob(blobName);
}
