import { PrismaClient } from '@prisma/client';
import logger from '../utils/logger';
import { sendSecurityAlertEmail } from './emailService';

const prisma = new PrismaClient();

/**
 * Extracts the /24 subnet from an IP address.
 * e.g. "192.168.1.45" → "192.168.1"
 * For IPv6 or unknown formats, returns the full IP.
 */
function getSubnet(ip: string): string {
  const parts = ip.replace(/^::ffff:/, '').split('.');
  if (parts.length === 4) {
    return parts.slice(0, 3).join('.');
  }
  return ip; // IPv6 — use full address as identifier
}

/**
 * Normalise the request IP — handles X-Forwarded-For from Azure's load balancer.
 */
function extractIp(req: any): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    // X-Forwarded-For can be comma-separated — take the first (real client IP)
    return (forwarded as string).split(',')[0].trim();
  }
  return req.ip || 'unknown';
}

export interface FingerprintResult {
  allowed:   boolean;
  isNew:     boolean;       // true if this device has never been seen before
  isSuspect: boolean;       // true if IP is from an unknown subnet
  device:    any;
}

/**
 * Protection 1: Device fingerprint binding.
 *
 * On first contact: record IP and subnet. Allow.
 * On subsequent contacts from same /24 subnet: update lastSeen. Allow.
 * On contact from new subnet: flag device, alert IT admin. Allow (don't hard-block
 *   legitimate VPN / office network changes, but make them visible).
 * On contact from flagged/quarantined device: reject.
 */
export async function checkDeviceFingerprint(
  customerId:   string,
  serialNumber: string,
  deviceName:   string,
  itAdminEmail: string,
  companyName:  string,
  req:          any,
): Promise<FingerprintResult> {
  const requestIp = extractIp(req);
  const subnet    = getSubnet(requestIp);

  // Look up existing device record
  const existing = await prisma.device.findUnique({
    where: { customerId_serialNumber: { customerId, serialNumber } },
  });

  // ── New device — never seen before ───────────────────────────────────────
  if (!existing) {
    await prisma.device.create({
      data: {
        customerId,
        serialNumber,
        deviceName,
        firstSeenIp:  requestIp,
        lastSeenIp:   requestIp,
        knownSubnets: [subnet],
        requestCount: 1,
        lastSeen:     new Date(),
      },
    });

    logger.info(`New device registered | serial=${serialNumber} | ip=${requestIp} | customer=${customerId}`);
    return { allowed: true, isNew: true, isSuspect: false, device: null };
  }

  // ── Quarantined device — hard reject ────────────────────────────────────
  if (existing.flagged) {
    logger.warn(`Quarantined device rejected | serial=${serialNumber} | reason=${existing.flagReason}`);
    return {
      allowed:   false,
      isNew:     false,
      isSuspect: true,
      device:    existing,
    };
  }

  // ── Known device — check subnet ───────────────────────────────────────────
  const knownSubnets  = existing.knownSubnets || [];
  const isKnownSubnet = knownSubnets.includes(subnet);
  let   isSuspect     = false;

  if (!isKnownSubnet) {
    isSuspect = true;

    // Add subnet to known list (max 10 — prevents unbounded growth)
    const updatedSubnets = [...knownSubnets, subnet].slice(-10);

    await prisma.device.update({
      where: { id: existing.id },
      data:  {
        lastSeenIp:   requestIp,
        knownSubnets: updatedSubnets,
        lastSeen:     new Date(),
        deviceName,
        requestCount: { increment: 1 },
      },
    });

    logger.warn(
      `Device seen from new subnet | serial=${serialNumber} | ` +
      `known=${knownSubnets.join(',')} | new=${subnet} | customer=${customerId}`
    );

    // Alert IT admin — fire and forget
    sendSecurityAlertEmail({
      toEmail:      itAdminEmail,
      companyName,
      serialNumber,
      deviceName:   existing.deviceName,
      knownIp:      existing.lastSeenIp || 'unknown',
      newIp:        requestIp,
      knownSubnets: knownSubnets,
      newSubnet:    subnet,
    }).catch(err => {
      logger.error(`Failed to send security alert email: ${err.message}`);
    });

  } else {
    // Normal request from known subnet — just update bookkeeping
    await prisma.device.update({
      where: { id: existing.id },
      data:  {
        lastSeenIp:   requestIp,
        lastSeen:     new Date(),
        deviceName,
        requestCount: { increment: 1 },
      },
    });
  }

  return { allowed: true, isNew: false, isSuspect, device: existing };
}

/**
 * Fingerprint check for MSP client devices — same logic as direct customers
 * but uses MspDevice table instead of Device.
 */
export async function checkMspDeviceFingerprint(
  mspClientId:  string,
  serialNumber: string,
  deviceName:   string,
  itAdminEmail: string,
  clientName:   string,
  req:          any,
): Promise<FingerprintResult> {
  const requestIp = extractIp(req);
  const subnet    = getSubnet(requestIp);

  const existing = await prisma.mspDevice.findUnique({
    where: { mspClientId_serialNumber: { mspClientId, serialNumber } },
  });

  if (!existing) {
    await prisma.mspDevice.create({
      data: {
        mspClientId,
        serialNumber,
        deviceName,
        firstSeenIp:  requestIp,
        lastSeenIp:   requestIp,
        knownSubnets: [subnet],
        requestCount: 1,
        lastSeen:     new Date(),
      },
    });
    logger.info(`New MSP device registered | serial=${serialNumber} | client=${mspClientId}`);
    return { allowed: true, isNew: true, isSuspect: false, device: null };
  }

  if (existing.flagged) {
    return { allowed: false, isNew: false, isSuspect: true, device: existing };
  }

  const knownSubnets  = existing.knownSubnets || [];
  const isKnownSubnet = knownSubnets.includes(subnet);
  let   isSuspect     = false;

  if (!isKnownSubnet) {
    isSuspect = true;
    const updatedSubnets = [...knownSubnets, subnet].slice(-10);

    await prisma.mspDevice.update({
      where: { id: existing.id },
      data:  {
        lastSeenIp:   requestIp,
        knownSubnets: updatedSubnets,
        lastSeen:     new Date(),
        deviceName,
        requestCount: { increment: 1 },
      },
    });

    sendSecurityAlertEmail({
      toEmail:      itAdminEmail,
      companyName:  clientName,
      serialNumber,
      deviceName:   existing.deviceName,
      knownIp:      existing.lastSeenIp || 'unknown',
      newIp:        requestIp,
      knownSubnets: knownSubnets,
      newSubnet:    subnet,
    }).catch(err => logger.error(`MSP security alert failed: ${err.message}`));

  } else {
    await prisma.mspDevice.update({
      where: { id: existing.id },
      data:  {
        lastSeenIp:   requestIp,
        lastSeen:     new Date(),
        deviceName,
        requestCount: { increment: 1 },
      },
    });
  }

  return { allowed: true, isNew: false, isSuspect, device: existing };
}
