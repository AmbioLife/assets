import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { PrismaClient } from '@prisma/client';
import logger from '../utils/logger';

const prisma = new PrismaClient();

// Replay window: reject requests older than 60 seconds
const TIMESTAMP_WINDOW_SECONDS = 60;

/**
 * HMAC-SHA256 request signing middleware.
 *
 * The Mac signs every request as:
 *   signature = HMAC-SHA256(apiKey, "METHOD:PATH:body_sha256:timestamp")
 *
 * Headers required:
 *   X-API-Key:   qe_live_...
 *   X-Timestamp: unix epoch seconds (e.g. 1710000000)
 *   X-Signature: hex-encoded HMAC
 *
 * Rejects if:
 *   - Timestamp is outside ±60 second window (replay prevention)
 *   - Signature does not match (tampering / stolen key)
 */
export async function verifySignature(req: Request, res: Response, next: NextFunction) {
  const apiKey    = req.headers['x-api-key']    as string;
  const timestamp = req.headers['x-timestamp']  as string;
  const signature = req.headers['x-signature']  as string;

  // ── Check all three headers are present ──────────────────────────────────
  if (!apiKey || !timestamp || !signature) {
    return res.status(401).json({
      error:   'Missing authentication headers',
      required: ['X-API-Key', 'X-Timestamp', 'X-Signature'],
    });
  }

  // ── Validate timestamp format ─────────────────────────────────────────────
  const ts = parseInt(timestamp, 10);
  if (isNaN(ts) || timestamp.length > 12) {
    return res.status(401).json({ error: 'Invalid X-Timestamp format' });
  }

  // ── Replay window check ───────────────────────────────────────────────────
  const nowSeconds = Math.floor(Date.now() / 1000);
  const drift      = Math.abs(nowSeconds - ts);
  if (drift > TIMESTAMP_WINDOW_SECONDS) {
    logger.warn(`Replay attempt rejected | drift=${drift}s | ip=${req.ip}`);
    return res.status(401).json({
      error: `Request timestamp expired (${drift}s ago). Ensure your Mac's clock is accurate.`,
    });
  }

  // ── Look up by API key — check direct customers first, then MSP clients ────
  let customer: any = null;
  let mspClient: any = null;

  customer = await prisma.customer.findUnique({
    where:   { apiKey },
    include: { config: true },
  });

  if (!customer) {
    // Check if this is an MSP client API key
    mspClient = await prisma.mspClient.findUnique({
      where:   { apiKey },
      include: {
        mspAccount: {
          select: {
            id: true, mspSupportEmail: true, status: true,
            customer: { select: { id: true, companyName: true, email: true } },
          },
        },
      },
    });
  }

  if (!customer && !mspClient) {
    // Constant-time delay to prevent API key enumeration
    await new Promise(r => setTimeout(r, 100 + Math.random() * 100));
    return res.status(401).json({ error: 'Invalid API key' });
  }

  if (customer?.planStatus === 'suspended') {
    return res.status(403).json({ error: 'Account suspended. Please contact support.' });
  }

  if (mspClient && !mspClient.active) {
    return res.status(403).json({ error: 'This client account has been deactivated.' });
  }

  // ── Recompute the expected signature ─────────────────────────────────────
  // Message format: "METHOD:PATH:BODY_SHA256:TIMESTAMP"
  const body        = req.body ? JSON.stringify(req.body) : '';
  const bodySha256  = crypto.createHash('sha256').update(body).digest('hex');
  const message     = `${req.method}:${req.path}:${bodySha256}:${timestamp}`;
  const expected    = crypto
    .createHmac('sha256', apiKey)
    .update(message)
    .digest('hex');

  // ── Timing-safe comparison ────────────────────────────────────────────────
  let signaturesMatch = false;
  try {
    signaturesMatch = crypto.timingSafeEqual(
      Buffer.from(signature.toLowerCase(),  'hex'),
      Buffer.from(expected.toLowerCase(),   'hex'),
    );
  } catch {
    // Buffer lengths differ — invalid hex or wrong length
    signaturesMatch = false;
  }

  if (!signaturesMatch) {
    logger.warn(`Invalid signature | customer=${customer.id} | ip=${req.ip} | path=${req.path}`);
    return res.status(401).json({ error: 'Invalid request signature' });
  }

  // ── Attach identity to request and continue ──────────────────────────────
  if (mspClient) {
    (req as any).mspClient  = mspClient;
    (req as any).isMspClient = true;
    (req as any).customer   = null;
  } else {
    (req as any).customer   = customer;
    (req as any).isMspClient = false;
  }
  next();
}
