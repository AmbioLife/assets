# QuickElevate SaaS — Deployment Guide

## Prerequisites
- Azure CLI installed and logged in (`az login`)
- Node.js 20+
- PostgreSQL client (for initial DB setup)
- Stripe account
- Clerk account (auth)
- Resend account (email)

---

## Step 1 — Create Azure Resources

```bash
# Create resource group
az group create --name QuickElevate --location canadacentral

# Deploy all infrastructure via Bicep
az deployment group create \
  --resource-group QuickElevate \
  --template-file infra/bicep/main.bicep \
  --parameters environment=prod dbAdminPassword=YOUR_SECURE_PASSWORD
```

Save the outputs — you'll need `backendUrl`, `frontendUrl`, `functionUrl`.

---

## Step 2 — Set up Database

```bash
cd backend
npm install
npx prisma migrate deploy
npx prisma db seed
```

---

## Step 3 — Configure Backend App Service

In Azure Portal → QuickElevate prod API → Environment variables, add:

```
DATABASE_URL           postgresql://quickelevate:PASS@quickelevate-prod-db.postgres.database.azure.com:5432/quickelevate?sslmode=require
JWT_SECRET             <generate: openssl rand -hex 64>
ENCRYPTION_KEY         <generate: openssl rand -hex 32>
CLERK_SECRET_KEY       sk_live_...
CLERK_WEBHOOK_SECRET   whsec_...
STRIPE_SECRET_KEY      sk_live_...
STRIPE_WEBHOOK_SECRET  whsec_...
STRIPE_PRICE_STARTER   price_...
STRIPE_PRICE_BUSINESS  price_...
AZURE_STORAGE_CONNECTION_STRING  DefaultEndpointsProtocol=https;...
AZURE_FUNCTION_BASE_URL  https://quickelevate-prod-approvals.azurewebsites.net/api/approve
RESEND_API_KEY         re_...
EMAIL_FROM             noreply@quickelevate.com
FRONTEND_URL           https://quickelevate-prod-frontend.azurestaticapps.net
PKG_BUILDER_SCRIPT     /app/infra/pkg-builder/build_customer_pkg.sh
```

---

## Step 4 — Deploy Backend

```bash
cd backend
npm run build
zip -r ../deploy/backend.zip dist package.json
az webapp deployment source config-zip \
  --resource-group QuickElevate \
  --name quickelevate-prod-api \
  --src ../deploy/backend.zip
```

---

## Step 5 — Deploy Azure Function

```bash
cd infra/azure-function
zip -r ../../deploy/function.zip . 
az functionapp deployment source config-zip \
  --resource-group QuickElevate \
  --name quickelevate-prod-approvals \
  --src ../../deploy/function.zip
```

---

## Step 6 — Deploy Frontend

Connect your GitHub repo to Azure Static Web Apps.
The `staticwebapp.config.json` handles routing.

Or deploy manually:
```bash
cd frontend
npm run build
# Push to GitHub — Azure Static Web Apps CI/CD auto-deploys
```

---

## Step 7 — Configure Clerk

1. Create a Clerk application at clerk.com
2. Set allowed redirect URLs to your frontend URL
3. Set webhook endpoint: `https://quickelevate-prod-api.azurewebsites.net/api/webhooks/clerk`
4. Enable events: `user.created`, `user.deleted`

---

## Step 8 — Configure Stripe

1. Create products and prices in Stripe dashboard:
   - Starter: $49/month recurring
   - Business: $149/month recurring
   - Enterprise: Custom (contact sales)
2. Set webhook endpoint: `https://quickelevate-prod-api.azurewebsites.net/api/webhooks/stripe`
3. Enable events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.payment_failed`

---

## Step 9 — Add Custom Domain (optional)

```bash
az webapp custom-hostname-add \
  --resource-group QuickElevate \
  --webapp-name quickelevate-prod-api \
  --hostname api.quickelevate.com
```

---

## Environment URLs

| Service     | URL |
|-------------|-----|
| Frontend    | https://quickelevate-prod-frontend.azurestaticapps.net |
| Backend API | https://quickelevate-prod-api.azurewebsites.net |
| Function    | https://quickelevate-prod-approvals.azurewebsites.net |

---

## Ongoing Maintenance

- **Stripe webhook**: Test with `stripe listen --forward-to localhost:4000/api/webhooks/stripe`
- **DB migrations**: `npx prisma migrate deploy` after schema changes
- **Logs**: Azure Portal → App Service → Log stream

---

## Security checklist

Run through this before going live:

- [ ] `ADMIN_CLERK_IDS` is set to your personal Clerk user ID in Azure App Service env vars
- [ ] `QE_CALLBACK_SECRET` is a 64-char random hex string (`openssl rand -hex 32`)
- [ ] All env vars are set in Azure App Service — none are committed to git
- [ ] `.gitignore` includes `.env` and `.env.local`
- [ ] PostgreSQL firewall rules only allow your App Service IP (not 0.0.0.0/0)
- [ ] Azure Blob Storage container access level is Private
- [ ] GitHub build repo is Private
- [ ] GitHub PAT has minimum required scopes (Contents: read, Actions: write only)
- [ ] Stripe is in live mode (sk_live_ not sk_test_)
- [ ] Resend domain DNS records are verified
