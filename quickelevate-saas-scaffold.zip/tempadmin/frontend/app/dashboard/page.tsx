'use client';
import { useEffect, useState } from 'react';
import { Package, Settings, CreditCard, Download, Shield, Clock, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import Link from 'next/link';
import toast from 'react-hot-toast';

type BuildStatus = 'PENDING' | 'BUILDING' | 'SUCCESS' | 'FAILED';

interface Build {
  id: string;
  version: string;
  status: BuildStatus;
  createdAt: string;
  builtAt?: string;
}

interface Customer {
  companyName: string;
  email: string;
  plan: string;
  planStatus: string;
  trialEndsAt?: string;
  deviceLimit: number;
  config?: { onboardingComplete: boolean; itAdminEmail: string; onboardingStep: number; };
  builds: Build[];
  _count: { devices: number };
}

const STATUS_COLORS: Record<BuildStatus, string> = {
  PENDING:  '#EAB308',
  BUILDING: '#3B82F6',
  SUCCESS:  '#22C55E',
  FAILED:   '#EF4444',
};

export default function DashboardPage() {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [building, setBuilding] = useState(false);
  const [activeBuildId, setActiveBuildId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchCustomer = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/customer/me`, { credentials: 'include' });
      const data = await res.json();
      setCustomer(data.customer);
    } catch { toast.error('Failed to load dashboard'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchCustomer(); }, []);

  // Poll build status
  useEffect(() => {
    if (!activeBuildId) return;
    const interval = setInterval(async () => {
      const res  = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/build/${activeBuildId}/status`, { credentials: 'include' });
      const data = await res.json();
      if (data.build.status === 'SUCCESS') {
        setActiveBuildId(null); setBuilding(false);
        toast.success('Your .pkg is ready to download!');
        fetchCustomer();
      } else if (data.build.status === 'FAILED') {
        setActiveBuildId(null); setBuilding(false);
        toast.error('Build failed — please try again or contact support.');
        fetchCustomer();
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [activeBuildId]);

  const triggerBuild = async () => {
    setBuilding(true);
    try {
      const res  = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/build/trigger`, { method: 'POST', credentials: 'include' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setActiveBuildId(data.buildId);
      toast.success('Building your .pkg — this takes about 30 seconds');
    } catch (e: any) {
      setBuilding(false);
      toast.error(e.message || 'Build failed');
    }
  };

  const downloadPkg = async (buildId: string) => {
    try {
      const res  = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/build/${buildId}/download`, { credentials: 'include' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      window.open(data.downloadUrl, '_blank');
    } catch { toast.error('Download failed — please try again'); }
  };

  if (loading) return (
    <div style={{ minHeight: '100vh', background: '#0A0A0F', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Loader2 size={32} color="#3B82F6" style={{ animation: 'spin 1s linear infinite' }} />
    </div>
  );

  const isTrialing   = customer?.plan === 'TRIAL';
  const trialDaysLeft = customer?.trialEndsAt
    ? Math.max(0, Math.ceil((new Date(customer.trialEndsAt).getTime() - Date.now()) / 86400000))
    : 0;
  const latestBuild  = customer?.builds[0];
  const canDownload  = latestBuild?.status === 'SUCCESS';

  return (
    <div style={{ minHeight: '100vh', background: '#0A0A0F', color: '#E8E8F0', fontFamily: "'DM Sans', system-ui, sans-serif" }}>

      {/* Header */}
      <div style={{ borderBottom: '1px solid #1E1E2E', padding: '0 5vw', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 28, height: 28, borderRadius: 7, background: 'linear-gradient(135deg, #3B82F6, #1D4ED8)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Shield size={14} color="white" />
          </div>
          <span style={{ fontWeight: 700 }}>QuickElevate</span>
        </div>
        <div style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
          <Link href="/dashboard/settings" style={{ color: '#8888A8', fontSize: 14, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 6 }}><Settings size={15} /> Settings</Link>
          <Link href="/dashboard/billing"  style={{ color: '#8888A8', fontSize: 14, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 6 }}><CreditCard size={15} /> Billing</Link>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '40px 5vw' }}>

        {/* Welcome */}
        <div style={{ marginBottom: 36 }}>
          <h1 style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 4 }}>
            {customer?.companyName || 'Your Dashboard'}
          </h1>
          <p style={{ color: '#8888A8', fontSize: 15 }}>{customer?.email}</p>
        </div>

        {/* Trial banner */}
        {isTrialing && trialDaysLeft > 0 && (
          <div style={{ background: '#0F1E3A', border: '1px solid #1E3A5F', borderRadius: 10, padding: '14px 20px', marginBottom: 28, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Clock size={16} color="#3B82F6" />
              <span style={{ fontSize: 14, color: '#93C5FD' }}><strong>{trialDaysLeft} days</strong> left in your free trial</span>
            </div>
            <Link href="/pricing" style={{ background: '#2563EB', color: 'white', padding: '7px 16px', borderRadius: 6, fontSize: 13, fontWeight: 700, textDecoration: 'none' }}>
              Upgrade now
            </Link>
          </div>
        )}

        {/* Onboarding incomplete banner */}
        {!customer?.config?.onboardingComplete && (
          <div style={{ background: '#1A110A', border: '1px solid #4A2A1A', borderRadius: 10, padding: '14px 20px', marginBottom: 28, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <AlertCircle size={16} color="#F97316" />
              <span style={{ fontSize: 14, color: '#FDBA74' }}>Complete your setup to generate your first .pkg</span>
            </div>
            <Link href={`/onboarding/company`} style={{ background: '#EA580C', color: 'white', padding: '7px 16px', borderRadius: 6, fontSize: 13, fontWeight: 700, textDecoration: 'none' }}>
              Continue setup →
            </Link>
          </div>
        )}

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16, marginBottom: 32 }}>
          {[
            { label: 'Plan',          value: customer?.plan || '—',                       icon: Shield,    color: '#3B82F6' },
            { label: 'Active Devices',value: `${customer?._count.devices || 0} / ${customer?.deviceLimit || 5}`, icon: Package, color: '#8B5CF6' },
            { label: 'Builds',        value: customer?.builds.length || 0,                icon: Package,   color: '#22C55E' },
            { label: 'Status',        value: customer?.planStatus || '—',                 icon: CheckCircle, color: '#EAB308' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} style={{ background: '#0F0F1A', border: '1px solid #1E1E32', borderRadius: 12, padding: '20px 24px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                <Icon size={16} color={color} />
                <span style={{ fontSize: 12, color: '#555570', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</span>
              </div>
              <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.02em' }}>{value}</div>
            </div>
          ))}
        </div>

        {/* Generate / Download pkg */}
        <div style={{ background: '#0F0F1A', border: '1px solid #1E1E32', borderRadius: 14, padding: 32, marginBottom: 28 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24, flexWrap: 'wrap', gap: 16 }}>
            <div>
              <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 4 }}>Your .pkg Installer</h2>
              <p style={{ color: '#8888A8', fontSize: 14 }}>Upload this to Intune as a Line-of-business app and deploy to your Mac fleet.</p>
            </div>
            <div style={{ display: 'flex', gap: 12 }}>
              {canDownload && (
                <button onClick={() => downloadPkg(latestBuild!.id)}
                  style={{ background: '#16A34A', color: 'white', padding: '10px 20px', borderRadius: 8, fontWeight: 700, fontSize: 14, cursor: 'pointer', border: 'none', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <Download size={16} /> Download .pkg
                </button>
              )}
              <button onClick={triggerBuild} disabled={building || !customer?.config?.onboardingComplete}
                style={{ background: building ? '#1E1E32' : '#2563EB', color: building ? '#555570' : 'white', padding: '10px 20px', borderRadius: 8, fontWeight: 700, fontSize: 14, cursor: building ? 'wait' : 'pointer', border: 'none', display: 'flex', alignItems: 'center', gap: 8, opacity: !customer?.config?.onboardingComplete ? 0.5 : 1 }}>
                {building ? <><Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> Building...</> : <><Package size={16} /> {canDownload ? 'Rebuild' : 'Build .pkg'}</>}
              </button>
            </div>
          </div>

          {/* Build history */}
          {customer?.builds && customer.builds.length > 0 ? (
            <div>
              <div style={{ fontSize: 12, color: '#555570', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 12 }}>Build History</div>
              {customer.builds.slice(0, 5).map(build => (
                <div key={build.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #13131F' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: STATUS_COLORS[build.status] }} />
                    <span style={{ fontSize: 13, fontFamily: 'monospace', color: '#C0C0D8' }}>v{build.version}</span>
                    <span style={{ fontSize: 12, color: '#555570' }}>{new Date(build.createdAt).toLocaleString()}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ fontSize: 12, color: STATUS_COLORS[build.status], fontWeight: 600 }}>{build.status}</span>
                    {build.status === 'SUCCESS' && (
                      <button onClick={() => downloadPkg(build.id)}
                        style={{ background: 'none', border: '1px solid #2A2A3E', color: '#8888A8', padding: '4px 10px', borderRadius: 6, fontSize: 12, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
                        <Download size={12} /> Download
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '24px 0', color: '#555570', fontSize: 14 }}>
              No builds yet — click "Build .pkg" to generate your installer.
            </div>
          )}
        </div>

        {/* Quick links */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
          {[
            { label: 'Edit Configuration', icon: Settings,    href: '/dashboard/settings', desc: 'Change email, duration, cooldown' },
            { label: 'Billing & Plan',      icon: CreditCard,  href: '/dashboard/billing',  desc: 'Manage subscription and invoices' },
          ].map(({ label, icon: Icon, href, desc }) => (
            <Link key={href} href={href} style={{ background: '#0F0F1A', border: '1px solid #1E1E32', borderRadius: 12, padding: '20px', textDecoration: 'none', display: 'block' }}>
              <Icon size={20} color="#3B82F6" style={{ marginBottom: 10 }} />
              <div style={{ fontWeight: 700, fontSize: 15, color: '#E8E8F0', marginBottom: 4 }}>{label}</div>
              <div style={{ fontSize: 13, color: '#555570' }}>{desc}</div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
