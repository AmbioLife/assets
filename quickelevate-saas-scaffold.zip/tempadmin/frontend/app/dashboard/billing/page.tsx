'use client';
import { useState, useEffect } from 'react';

const PLANS = [
  {
    key:         'FREE',
    name:        'Free',
    price:       0,
    devices:     25,
    description: 'Perfect for small teams — forever free',
    badge:       null,
    features:    [
      '25 Mac devices — forever free',
      'Unlimited approval requests',
      'Email approvals',
      'Community support',
    ],
  },
  {
    key:         'GROWTH',
    name:        'Growth',
    price:       49,
    devices:     75,
    description: 'For teams growing past 25 devices',
    badge:       null,
    features:    [
      '75 Mac devices',
      'Everything in Free',
      'Email support',
      'Usage analytics',
    ],
  },
  {
    key:         'BUSINESS',
    name:        'Business',
    price:       99,
    devices:     200,
    description: 'For larger IT departments',
    badge:       'Most popular',
    features:    [
      '200 Mac devices',
      'Everything in Growth',
      'Priority support',
      'Custom session policies',
    ],
  },
  {
    key:         'ENTERPRISE',
    name:        'Enterprise',
    price:       249,
    devices:     500,
    description: 'For large organisations',
    badge:       null,
    features:    [
      '500 Mac devices',
      'Everything in Business',
      'Priority support + SLA',
      'Volume discounts available',
    ],
  },
];

interface BillingStatus {
  plan:             string;
  planStatus:       string;
  isFree:           boolean;
  deviceCount:      number;
  deviceLimit:      number;
  devicesRemaining: number;
  nearLimit:        boolean;
  overLimit:        boolean;
  subscription:     { status: string; currentPeriodEnd: string; cancelAtPeriodEnd: boolean } | null;
}

export default function BillingPage() {
  const [status,    setStatus]    = useState<BillingStatus | null>(null);
  const [loading,   setLoading]   = useState(true);
  const [upgrading, setUpgrading] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/billing/status')
      .then(r => r.json())
      .then(d => { setStatus(d); setLoading(false); });
  }, []);

  async function handleUpgrade(planKey: string) {
    if (planKey === 'FREE') return;
    setUpgrading(planKey);
    try {
      const res  = await fetch('/api/billing/checkout', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ plan: planKey }),
      });
      const data = await res.json();
      if (data.checkoutUrl) window.location.href = data.checkoutUrl;
    } catch {
      alert('Failed to start checkout. Please try again.');
    } finally {
      setUpgrading(null);
    }
  }

  async function handleManage() {
    const res  = await fetch('/api/billing/portal', { method: 'POST' });
    const data = await res.json();
    if (data.portalUrl) window.location.href = data.portalUrl;
  }

  if (loading) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  const pctUsed   = status ? Math.round((status.deviceCount / status.deviceLimit) * 100) : 0;
  const currentPlanKey = status?.isFree ? 'FREE' : status?.plan || 'FREE';

  return (
    <div className="min-h-screen bg-slate-950 p-8">
      <div className="max-w-5xl mx-auto">

        {/* Header */}
        <div className="mb-10">
          <h1 className="text-2xl font-bold text-white">Billing & Plan</h1>
          <p className="text-slate-400 text-sm mt-1">Manage your subscription and device usage.</p>
        </div>

        {/* Current usage card */}
        {status && (
          <div className={`border rounded-xl p-6 mb-10 ${
            status.overLimit
              ? 'bg-red-950 border-red-800'
              : status.nearLimit
              ? 'bg-amber-950 border-amber-800'
              : 'bg-slate-900 border-slate-700'
          }`}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-1">Current plan</p>
                <div className="flex items-center gap-3">
                  <span className="text-white font-bold text-xl">
                    {status.isFree ? 'Free' : status.plan.charAt(0) + status.plan.slice(1).toLowerCase()}
                  </span>
                  {status.isFree && (
                    <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-green-900 text-green-300">
                      Free forever
                    </span>
                  )}
                  {!status.isFree && (
                    <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                      status.planStatus === 'active'   ? 'bg-green-900 text-green-300' :
                      status.planStatus === 'past_due' ? 'bg-amber-900 text-amber-300' :
                      'bg-slate-700 text-slate-400'
                    }`}>
                      {status.planStatus === 'active' ? 'Active' :
                       status.planStatus === 'past_due' ? 'Payment due' : status.planStatus}
                    </span>
                  )}
                </div>
              </div>
              {status.subscription && (
                <button onClick={handleManage}
                  className="text-sm text-indigo-400 hover:text-indigo-300 border border-indigo-800 hover:border-indigo-600 px-3 py-1.5 rounded-lg transition-all">
                  Manage subscription
                </button>
              )}
            </div>

            {/* Device usage bar */}
            <div>
              <div className="flex justify-between text-xs mb-2">
                <span className="text-slate-400">Device usage</span>
                <span className={`font-semibold ${
                  status.overLimit ? 'text-red-400' : status.nearLimit ? 'text-amber-400' : 'text-slate-300'
                }`}>
                  {status.deviceCount} / {status.deviceLimit} devices
                </span>
              </div>
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <div className={`h-full rounded-full transition-all ${
                  status.overLimit ? 'bg-red-500' : status.nearLimit ? 'bg-amber-500' : 'bg-green-500'
                }`} style={{ width: `${Math.min(pctUsed, 100)}%` }} />
              </div>

              {status.overLimit && status.isFree && (
                <p className="text-red-300 text-xs mt-2 font-medium">
                  You have exceeded the 25-device free limit. You have a 7-day grace period — upgrade now to avoid interruption.
                </p>
              )}
              {status.overLimit && !status.isFree && (
                <p className="text-red-300 text-xs mt-2 font-medium">
                  Device limit reached. New Macs cannot submit requests until you upgrade.
                </p>
              )}
              {status.nearLimit && !status.overLimit && (
                <p className="text-amber-300 text-xs mt-2">
                  Approaching your device limit — {status.devicesRemaining} slots remaining.
                </p>
              )}
              {!status.nearLimit && !status.overLimit && (
                <p className="text-slate-500 text-xs mt-2">
                  {status.devicesRemaining} device slots remaining on your plan.
                </p>
              )}
            </div>
          </div>
        )}

        {/* Plan cards */}
        <div className="grid grid-cols-4 gap-4">
          {PLANS.map(plan => {
            const isCurrent = currentPlanKey === plan.key;
            const isUpgrade = !isCurrent && plan.price > 0;

            return (
              <div key={plan.key}
                className={`relative bg-slate-900 rounded-xl flex flex-col transition-all ${
                  plan.badge
                    ? 'border-2 border-indigo-500'
                    : plan.key === 'FREE'
                    ? 'border border-green-800'
                    : 'border border-slate-700'
                }`}>

                {plan.badge && (
                  <div className="absolute -top-3 left-0 right-0 flex justify-center">
                    <span className="bg-indigo-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
                      {plan.badge}
                    </span>
                  </div>
                )}

                <div className={`p-5 flex-1 ${plan.badge ? 'pt-7' : ''}`}>
                  <p className={`text-xs font-semibold uppercase tracking-wider mb-2 ${
                    plan.key === 'FREE' ? 'text-green-400' : 'text-slate-400'
                  }`}>{plan.name}</p>

                  <div className="flex items-baseline gap-1 mb-1">
                    {plan.price === 0 ? (
                      <span className="text-white font-bold text-2xl">Free</span>
                    ) : (
                      <>
                        <span className="text-white font-bold text-2xl">${plan.price}</span>
                        <span className="text-slate-400 text-sm">/mo</span>
                      </>
                    )}
                  </div>
                  <p className="text-slate-400 text-xs mb-4">{plan.description}</p>

                  <div className={`rounded-lg px-3 py-2 mb-4 ${
                    plan.key === 'FREE'     ? 'bg-green-950 border border-green-900' :
                    plan.badge             ? 'bg-indigo-950 border border-indigo-900' :
                    'bg-slate-800'
                  }`}>
                    <span className={`text-sm font-semibold ${
                      plan.key === 'FREE' ? 'text-green-300' :
                      plan.badge         ? 'text-indigo-300' : 'text-white'
                    }`}>
                      {plan.devices} Mac devices
                    </span>
                    {plan.price > 0 && (
                      <span className="text-slate-400 text-xs block">
                        ${(plan.price / plan.devices * 100).toFixed(0)}¢ per device/month
                      </span>
                    )}
                  </div>

                  <ul className="flex flex-col gap-2">
                    {plan.features.map(f => (
                      <li key={f} className="flex items-start gap-2">
                        <span className={`text-xs mt-0.5 shrink-0 ${
                          plan.key === 'FREE' ? 'text-green-400' : 'text-green-400'
                        }`}>✓</span>
                        <span className="text-slate-300 text-xs">{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-5 pt-0">
                  {isCurrent ? (
                    <div className="w-full py-2 text-center text-xs font-semibold text-slate-500 border border-slate-700 rounded-lg">
                      Current plan
                    </div>
                  ) : plan.key === 'FREE' ? (
                    <div className="w-full py-2 text-center text-xs text-slate-600 rounded-lg">
                      Your current free tier
                    </div>
                  ) : (
                    <button
                      onClick={() => handleUpgrade(plan.key)}
                      disabled={!!upgrading}
                      className={`w-full py-2 rounded-lg text-xs font-semibold transition-all disabled:opacity-40 ${
                        plan.badge
                          ? 'bg-indigo-600 hover:bg-indigo-500 text-white'
                          : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-600'
                      }`}>
                      {upgrading === plan.key ? 'Redirecting…' : `Upgrade to ${plan.name}`}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <p className="text-slate-500 text-xs text-center mt-6">
          Free plan is free forever — no credit card required. Paid plans can be cancelled anytime.
          Device count is based on unique Mac serial numbers.
        </p>

        {/* MSP Partner callout */}
        <div className="mt-8 bg-slate-900 border border-indigo-800 rounded-xl p-6">
          <span className="bg-indigo-900 text-indigo-300 text-xs font-semibold px-2 py-0.5 rounded-full inline-block mb-3">MSP Partner</span>
          <h3 className="text-white font-bold text-lg mb-1">Managing Mac devices for multiple clients?</h3>
          <p className="text-slate-400 text-sm mb-5">
            One QuickElevate account, unlimited clients. Each client gets their own .pkg, their own IT admin email, and their own completely separate approval flow. Flat monthly pricing — no per-device billing.
          </p>
          <div className="grid grid-cols-3 gap-3 mb-5">
            {[
              { name: 'MSP Starter', price: '$79', devices: '200 devices' },
              { name: 'MSP Growth',  price: '$149', devices: '750 devices' },
              { name: 'MSP Scale',   price: '$249', devices: 'Unlimited' },
            ].map(p => (
              <div key={p.name} className="bg-slate-800 rounded-lg p-3 text-center">
                <p className="text-slate-400 text-xs mb-1">{p.name}</p>
                <p className="text-white font-bold text-lg">{p.price}<span className="text-slate-400 text-xs font-normal">/mo</span></p>
                <p className="text-slate-400 text-xs">{p.devices}</p>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-3 mb-5">
            {['Unlimited client accounts', 'MSP dashboard', 'Per-client .pkg builds', 'Per-client IT admin email', 'Flat monthly rate — no surprises'].map(f => (
              <span key={f} className="text-xs text-slate-300 flex items-center gap-1">
                <span className="text-green-400">✓</span> {f}
              </span>
            ))}
          </div>
          <button
            onClick={async () => {
              const res  = await fetch('/api/msp/upgrade', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ plan: 'MSP_STARTER' }),
              });
              const data = await res.json();
              if (data.checkoutUrl) window.location.href = data.checkoutUrl;
            }}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-sm transition-all">
            Start with MSP Starter — $79/month →
          </button>
        </div>
      </div>
    </div>
  );
}
