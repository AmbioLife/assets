'use client';
import { useState, useEffect } from 'react';

export default function SettingsPage() {
  const [form, setForm]   = useState({
    itAdminEmail:           '',
    sessionDurationMinutes: 60,
    cooldownMinutes:        60,
    approvalTimeoutMinutes: 30,
    requireApproval:        true,
    excludedAccounts:       'lapsadmin',
  });
  const [loading,  setLoading]  = useState(true);
  const [saving,   setSaving]   = useState(false);
  const [building, setBuilding] = useState(false);
  const [saved,    setSaved]    = useState(false);
  const [error,    setError]    = useState('');

  useEffect(() => {
    fetch('/api/config').then(r => r.json()).then(data => {
      if (data.config) {
        setForm({
          itAdminEmail:           data.config.itAdminEmail           || '',
          sessionDurationMinutes: data.config.sessionDurationMinutes || 60,
          cooldownMinutes:        data.config.cooldownMinutes        || 60,
          approvalTimeoutMinutes: data.config.approvalTimeoutMinutes || 30,
          requireApproval:        data.config.requireApproval        ?? true,
          excludedAccounts:       data.config.excludedAccounts       || 'lapsadmin',
        });
      }
      setLoading(false);
    });
  }, []);

  function set(key: string, value: any) { setForm(f => ({ ...f, [key]: value })); }

  async function saveAndRebuild() {
    setError(''); setSaving(true);
    try {
      await fetch('/api/config/step/1', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itAdminEmail: form.itAdminEmail }),
      });
      await fetch('/api/config/step/2', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionDurationMinutes: form.sessionDurationMinutes,
          cooldownMinutes:        form.cooldownMinutes,
          approvalTimeoutMinutes: form.approvalTimeoutMinutes,
          requireApproval:        form.requireApproval,
          excludedAccounts:       form.excludedAccounts,
        }),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);

      // Trigger a new build with updated config
      setBuilding(true);
      await fetch('/api/build/trigger', { method: 'POST' });
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false); setBuilding(false);
    }
  }

  if (loading) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 p-8">
      <div className="max-w-xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white">Settings</h1>
          <p className="text-slate-400 text-sm mt-1">Changes trigger an automatic .pkg rebuild. Download the new file and redeploy via MDM.</p>
        </div>

        <div className="flex flex-col gap-5">

          {/* IT Admin Email */}
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <label className="block text-white font-semibold text-sm mb-1">IT Admin Email</label>
            <p className="text-slate-400 text-xs mb-3">Approval request emails are sent to this address.</p>
            <input
              type="email"
              value={form.itAdminEmail}
              onChange={e => set('itAdminEmail', e.target.value)}
              placeholder="it-admin@yourcompany.com"
              className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Require approval */}
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white font-semibold text-sm">Require IT approval</p>
                <p className="text-slate-400 text-xs mt-0.5">If off, access is granted instantly.</p>
              </div>
              <button
                onClick={() => set('requireApproval', !form.requireApproval)}
                className={`w-12 h-6 rounded-full transition-colors relative ${form.requireApproval ? 'bg-indigo-600' : 'bg-slate-600'}`}>
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.requireApproval ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>
          </div>

          {/* Session duration */}
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <label className="block text-white font-semibold text-sm mb-3">Session duration</label>
            <select value={form.sessionDurationMinutes} onChange={e => set('sessionDurationMinutes', Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option value={15}>15 minutes</option>
              <option value={30}>30 minutes</option>
              <option value={60}>1 hour</option>
              <option value={120}>2 hours</option>
              <option value={240}>4 hours</option>
            </select>
          </div>

          {/* Cooldown */}
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <label className="block text-white font-semibold text-sm mb-3">Cooldown period</label>
            <select value={form.cooldownMinutes} onChange={e => set('cooldownMinutes', Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option value={0}>No cooldown</option>
              <option value={30}>30 minutes</option>
              <option value={60}>1 hour</option>
              <option value={120}>2 hours</option>
              <option value={480}>8 hours</option>
              <option value={1440}>24 hours</option>
            </select>
          </div>

          {/* Approval timeout */}
          {form.requireApproval && (
            <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
              <label className="block text-white font-semibold text-sm mb-3">Approval timeout</label>
              <select value={form.approvalTimeoutMinutes} onChange={e => set('approvalTimeoutMinutes', Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value={15}>15 minutes</option>
                <option value={30}>30 minutes</option>
                <option value={60}>1 hour</option>
                <option value={120}>2 hours</option>
              </select>
            </div>
          )}

          {/* Excluded accounts */}
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <label className="block text-white font-semibold text-sm mb-1">Excluded accounts</label>
            <p className="text-slate-400 text-xs mb-3">Comma-separated usernames blocked from requesting access.</p>
            <input
              type="text"
              value={form.excludedAccounts}
              onChange={e => set('excludedAccounts', e.target.value)}
              placeholder="lapsadmin, mdmadmin"
              className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {error && <p className="text-red-400 text-sm mt-4">{error}</p>}
        {saved && <p className="text-green-400 text-sm mt-4">✓ Saved — new build triggered.</p>}

        <button
          onClick={saveAndRebuild}
          disabled={saving || building}
          className="w-full mt-6 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold rounded-lg transition-all">
          {saving ? 'Saving…' : building ? 'Triggering rebuild…' : 'Save & Rebuild .pkg'}
        </button>
      </div>
    </div>
  );
}
