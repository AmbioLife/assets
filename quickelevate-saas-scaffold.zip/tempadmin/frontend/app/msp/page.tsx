'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

interface MspClient {
  id:           string;
  clientName:   string;
  itAdminEmail: string;
  active:       boolean;
  _count:       { devices: number; requests: number };
  builds:       { status: string; createdAt: string }[];
}

interface Dashboard {
  clients:       MspClient[];
  totalClients:  number;
  totalDevices:  number;
  recentRequests: number;
  billing: {
    pricePerDevice:   number;
    freeDevices:      number;
    billableDevices:  number;
    estimatedMonthly: number;
  };
}

export default function MspDashboardPage() {
  const router  = useRouter();
  const [data,    setData]    = useState<Dashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState('');

  useEffect(() => {
    fetch('/api/msp/dashboard')
      .then(r => { if (r.status === 403) router.push('/dashboard'); return r.json(); })
      .then(d => { setData(d); setLoading(false); })
      .catch(() => { setError('Failed to load MSP dashboard'); setLoading(false); });
  }, []);

  if (loading) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (error) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <p className="text-red-400">{error}</p>
    </div>
  );

  const b = data?.billing;

  return (
    <div className="min-h-screen bg-slate-950 p-8">
      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white">MSP Partner Dashboard</h1>
            <p className="text-slate-400 text-sm mt-1">Manage all your client accounts from one place.</p>
          </div>
          <Link href="/msp/clients/new"
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-sm transition-all">
            + Add Client
          </Link>
        </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total clients',   value: data?.totalClients  || 0,  unit: '' },
            { label: 'Managed devices', value: data?.totalDevices  || 0,  unit: '' },
            { label: 'Requests today',  value: data?.recentRequests|| 0,  unit: '' },
            { label: 'Monthly estimate',value: `$${b?.estimatedMonthly?.toFixed(2) || '0.00'}`, unit: '' },
          ].map(stat => (
            <div key={stat.label} className="bg-slate-900 border border-slate-700 rounded-xl p-5">
              <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">{stat.label}</p>
              <p className="text-white font-bold text-2xl">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Billing summary */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-1">MSP Partner Plan</p>
              {data?.mspAccount?.mspSupportEmail && (
                <p className="text-green-400 text-xs mb-1 font-medium">
                  ✓ Support email: {data.mspAccount.mspSupportEmail}
                </p>
              )}
              {!data?.mspAccount?.mspSupportEmail && (
                <p className="text-amber-400 text-xs mb-1">
                  ⚠ No MSP support email set —{' '}
                  <a href="/msp/settings" className="underline">configure it</a>{' '}
                  so clients without a dedicated IT email can route here.
                </p>
              )}
              <p className="text-white text-sm">
                <span className="text-green-400 font-semibold">First {b?.freeDevices} devices free</span>
                {' · '}
                <span className="text-slate-300">${b?.pricePerDevice}/device/month after that</span>
                {b && b.billableDevices > 0 && (
                  <span className="text-slate-400 ml-2">({b.billableDevices} billable × ${b.pricePerDevice} = ${b.estimatedMonthly?.toFixed(2)}/month)</span>
                )}
              </p>
            </div>
            <Link href="/msp/billing"
              className="text-sm text-indigo-400 hover:text-indigo-300 border border-indigo-800 px-3 py-1.5 rounded-lg transition-all">
              Billing details
            </Link>
          </div>
        </div>

        {/* Client list */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-700 flex items-center justify-between">
            <p className="text-white font-semibold text-sm">Client accounts</p>
            <p className="text-slate-400 text-xs">{data?.totalClients || 0} total</p>
          </div>

          {!data?.clients.length ? (
            <div className="p-12 text-center">
              <p className="text-slate-400 text-sm mb-4">No clients yet.</p>
              <Link href="/msp/clients/new"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg">
                Add your first client
              </Link>
            </div>
          ) : (
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  {['Client name','IT admin email','Devices','Requests','Last build','Actions'].map(h => (
                    <th key={h} className="text-left px-6 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.clients.map((client, i) => {
                  const lastBuild = client.builds[0];
                  const buildColor = lastBuild?.status === 'SUCCESS' ? 'text-green-400'
                    : lastBuild?.status === 'FAILED' ? 'text-red-400'
                    : lastBuild?.status === 'BUILDING' ? 'text-amber-400'
                    : 'text-slate-500';

                  return (
                    <tr key={client.id} className={`border-b border-slate-800 hover:bg-slate-800/40 transition-colors ${!client.active ? 'opacity-40' : ''}`}>
                      <td className="px-6 py-4">
                        <p className="text-white font-medium text-sm">{client.clientName}</p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-slate-300 text-sm">{client.itAdminEmail}</p>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-white font-semibold text-sm">{client._count.devices}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-slate-300 text-sm">{client._count.requests}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-xs font-medium ${buildColor}`}>
                          {lastBuild?.status || 'No build'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <Link href={`/msp/clients/${client.id}`}
                            className="text-indigo-400 hover:text-indigo-300 text-xs font-medium">
                            Manage
                          </Link>
                          <RebuildButton clientId={client.id} />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

function RebuildButton({ clientId }: { clientId: string }) {
  const [building, setBuilding] = useState(false);
  const [done,     setDone]     = useState(false);

  async function rebuild() {
    setBuilding(true);
    await fetch(`/api/msp/clients/${clientId}/rebuild`, { method: 'POST' });
    setBuilding(false);
    setDone(true);
    setTimeout(() => setDone(false), 5000);
  }

  return (
    <button onClick={rebuild} disabled={building}
      className="text-slate-400 hover:text-white text-xs font-medium disabled:opacity-40 transition-colors">
      {building ? 'Building…' : done ? '✓ Queued' : 'Rebuild .pkg'}
    </button>
  );
}
