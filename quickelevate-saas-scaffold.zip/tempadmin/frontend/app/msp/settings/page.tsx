'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function MspSettingsPage() {
  const router  = useRouter();
  const [email,   setEmail]   = useState('');
  const [saved,   setSaved]   = useState(false);
  const [saving,  setSaving]  = useState(false);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState('');

  useEffect(() => {
    fetch('/api/msp/settings')
      .then(r => r.json())
      .then(d => { setEmail(d.mspSupportEmail || ''); setLoading(false); });
  }, []);

  async function save() {
    setError(''); setSaving(true);
    try {
      const res = await fetch('/api/msp/settings', {
        method:  'PUT',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ mspSupportEmail: email }),
      });
      if (!res.ok) throw new Error((await res.json()).error || 'Save failed');
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 p-8">
      <div className="max-w-xl mx-auto">
        <div className="mb-8">
          <button onClick={() => router.back()} className="text-slate-400 hover:text-white text-sm mb-4 block">← Back</button>
          <h1 className="text-2xl font-bold text-white">MSP Settings</h1>
        </div>

        <div className="bg-slate-900 border border-slate-700 rounded-xl p-6">
          <h2 className="text-white font-semibold text-base mb-1">MSP support email</h2>
          <p className="text-slate-400 text-sm mb-5">
            When a client has no specific IT admin email configured, all their approval
            requests route to this address. Your technicians approve and deny requests
            directly from this inbox — no dashboard login needed.
          </p>

          <div className="mb-4">
            <label className="block text-slate-300 text-xs font-semibold mb-1.5">
              Support email address
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && save()}
              placeholder="support@yourcompany.com"
              className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <p className="text-slate-500 text-xs mt-1.5">
              Can be a shared mailbox, helpdesk alias, or any distribution list your team monitors.
            </p>
          </div>

          {error  && <p className="text-red-400 text-sm mb-3">{error}</p>}
          {saved  && <p className="text-green-400 text-sm mb-3">✓ Saved</p>}

          <button onClick={save} disabled={saving}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold rounded-lg text-sm transition-all">
            {saving ? 'Saving…' : 'Save'}
          </button>
        </div>

        {/* How it works */}
        <div className="mt-6 bg-slate-900 border border-slate-700 rounded-xl p-5">
          <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-4">How email routing works</p>
          <div className="flex flex-col gap-3">
            {[
              { label: 'Client has its own IT admin email', route: '→ Sent to that email only' },
              { label: 'Client has no IT admin email set', route: '→ Sent to your MSP support email' },
              { label: 'Neither is configured',            route: '→ Blocked — must configure one' },
            ].map(({ label, route }) => (
              <div key={label} className="flex items-start justify-between gap-4">
                <span className="text-slate-300 text-xs">{label}</span>
                <span className="text-indigo-400 text-xs font-medium shrink-0">{route}</span>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-700">
            <p className="text-slate-400 text-xs font-semibold mb-2">Email subject format</p>
            <p className="text-slate-500 text-xs font-mono bg-slate-800 rounded px-3 py-2">
              [Admin Request] John on MacBook Pro — Acme Corp
            </p>
            <p className="text-slate-500 text-xs mt-1.5">
              The client company name is always in the subject so your technician knows which client at a glance, without opening the email.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
