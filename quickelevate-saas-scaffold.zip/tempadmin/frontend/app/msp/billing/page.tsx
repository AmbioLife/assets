'use client';
import { useState, useEffect } from 'react';

const PLAN_LABELS: Record<string, string> = {
  MSP_STARTER: 'MSP Starter',
  MSP_GROWTH:  'MSP Growth',
  MSP_SCALE:   'MSP Scale',
};

export default function MspBillingPage() {
  const [data,      setData]      = useState<any>(null);
  const [loading,   setLoading]   = useState(true);
  const [upgrading, setUpgrading] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/msp/billing').then(r => r.json()).then(d => { setData(d); setLoading(false); });
  }, []);

  async function handleUpgrade(planKey: string) {
    setUpgrading(planKey);
    try {
      const res  = await fetch('/api/msp/billing/upgrade', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ plan: planKey }),
      });
      const json = await res.json();
      if (json.checkoutUrl) window.location.href = json.checkoutUrl;
    } catch {
      alert('Failed to start upgrade. Please try again.');
    } finally {
      setUpgrading(null);
    }
  }

  async function openPortal() {
    const res  = await fetch('/api/msp/billing/portal', { method: 'POST' });
    const json = await res.json();
    if (json.portalUrl) window.location.href = json.portalUrl;
  }

  if (loading) return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  const current = data?.currentPlan;

  return (
    <div className="min-h-screen bg-slate-950 p-8">
      <div className="max-w-3xl mx-auto">

        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white">MSP Partner Billing</h1>
          <p className="text-slate-400 text-sm mt-1">Flat monthly rate — no per-device surprises.</p>
        </div>

        {/* Current plan + usage */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 mb-8">
          <div className="flex items-start justify-between mb-5">
            <div>
              <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-1">Current plan</p>
              <div className="flex items-center gap-3">
                <span className="text-white font-bold text-xl">{current?.name || 'MSP Starter'}</span>
                <span className="text-green-400 text-xs font-semibold bg-green-900 px-2 py-0.5 rounded-full">
                  ${current?.priceMonthly || 79}/month
                </span>
              </div>
            </div>
            <button onClick={openPortal}
              className="text-sm text-indigo-400 hover:text-indigo-300 border border-indigo-800 px-3 py-1.5 rounded-lg transition-all">
              Manage billing
            </button>
          </div>

          {/* Device usage */}
          <div>
            <div className="flex justify-between text-xs mb-2">
              <span className="text-slate-400">Total devices across all clients</span>
              <span className="text-slate-300 font-semibold">
                {data?.totalDevices || 0}
                {current?.deviceLimit ? ` / ${current.deviceLimit}` : ' / Unlimited'}
              </span>
            </div>
            {current?.deviceLimit && (
              <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    (data?.totalDevices / current.deviceLimit) >= 0.9 ? 'bg-amber-500' : 'bg-green-500'
                  }`}
                  style={{ width: `${Math.min(100, Math.round((data?.totalDevices / current.deviceLimit) * 100))}%` }}
                />
              </div>
            )}
            {data?.devicesRemaining !== null && data?.devicesRemaining <= 50 && (
              <p className="text-amber-400 text-xs mt-2">
                {data.devicesRemaining} device slots remaining — consider upgrading before you onboard more clients.
              </p>
            )}
          </div>
        </div>

        {/* Plan comparison */}
        <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-4">All MSP plans</p>
        <div className="grid grid-cols-3 gap-4 mb-8">
          {(data?.allPlans || []).map((plan: any) => (
            <div key={plan.key}
              className={`bg-slate-900 rounded-xl p-5 border transition-all ${
                plan.current ? 'border-indigo-500 border-2' : 'border-slate-700'
              }`}>
              {plan.current && (
                <span className="text-xs bg-indigo-600 text-white px-2 py-0.5 rounded-full font-semibold block text-center mb-3">
                  Current plan
                </span>
              )}
              <p className="text-white font-bold text-base mb-1">{plan.name}</p>
              <div className="flex items-baseline gap-1 mb-3">
                <span className="text-white font-bold text-2xl">${plan.priceMonthly}</span>
                <span className="text-slate-400 text-sm">/month</span>
              </div>
              <p className="text-slate-400 text-xs mb-4">
                {plan.deviceLimit ? `Up to ${plan.deviceLimit.toLocaleString()} devices` : 'Unlimited devices'}
              </p>
              {!plan.current && (
                <button
                  onClick={() => handleUpgrade(plan.key)}
                  disabled={!!upgrading}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-semibold rounded-lg transition-all">
                  {upgrading === plan.key ? 'Redirecting…' : `Upgrade to ${plan.name.replace('MSP ', '')}`}
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Why flat pricing */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
          <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-3">Why flat pricing?</p>
          <div className="flex flex-col gap-2.5">
            {[
              'Predictable monthly cost — easy to budget and get approved',
              'No surprises when you onboard a new client mid-month',
              'One line item on your credit card regardless of how many devices you manage',
              'Upgrade when you need more capacity — downgrade when you don\'t',
            ].map(item => (
              <div key={item} className="flex items-start gap-2">
                <span className="text-green-400 text-xs shrink-0 mt-0.5">✓</span>
                <span className="text-slate-300 text-xs">{item}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
