'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AddMspClientPage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error,  setError]  = useState('');
  const [form, setForm] = useState({
    clientName:             '',
    itAdminEmail:           '',  // optional if MSP support email is set
    companyNotes:           '',
    sessionDurationMinutes: 60,
    cooldownMinutes:        60,
    approvalTimeoutMinutes: 30,
    requireApproval:        true,
    excludedAccounts:       'lapsadmin',
  });

  function set(k: string, v: any) { setForm(f => ({ ...f, [k]: v })); }

  async function handleSubmit() {
    setError('');
    if (!form.clientName.trim())        { setError('Client name is required');           return; }
    if (form.itAdminEmail && !form.itAdminEmail.includes('@')) { setError('Enter a valid email address or leave blank to use your MSP support email'); return; }
    setSaving(true);
    try {
      const res = await fetch('/api/msp/clients', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error((await res.json()).error || 'Failed to add client');
      router.push('/msp');
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 p-8">
      <div className="max-w-xl mx-auto">
        <div className="mb-8">
          <button onClick={() => router.back()} className="text-slate-400 hover:text-white text-sm mb-4 block">← Back</button>
          <h1 className="text-2xl font-bold text-white">Add new client</h1>
          <p className="text-slate-400 text-sm mt-1">A custom .pkg installer will be built automatically after adding.</p>
        </div>

        <div className="flex flex-col gap-5">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <p className="text-white font-semibold text-sm mb-4">Client details</p>
            <div className="flex flex-col gap-4">
              <div>
                <label className="block text-slate-300 text-xs font-semibold mb-1.5">Client company name</label>
                <input type="text" value={form.clientName} onChange={e => set('clientName', e.target.value)}
                  placeholder="Acme Corp"
                  className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div>
                <label className="block text-slate-300 text-xs font-semibold mb-1.5">
                  IT admin email <span className="text-slate-500 font-normal">(optional)</span>
                </label>
                <input type="email" value={form.itAdminEmail} onChange={e => set('itAdminEmail', e.target.value)}
                  placeholder="it@acmecorp.com"
                  className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                <p className="text-slate-500 text-xs mt-1.5">
                  Leave blank to route all this client&#39;s requests to your MSP support email.
                  Set a client-specific email if this client&#39;s own IT team handles approvals.
                </p>
              </div>
              <div>
                <label className="block text-slate-300 text-xs font-semibold mb-1.5">Notes (optional)</label>
                <input type="text" value={form.companyNotes} onChange={e => set('companyNotes', e.target.value)}
                  placeholder="e.g. Toronto office, Finance team"
                  className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <p className="text-white font-semibold text-sm mb-4">Session settings</p>
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-300 text-sm">Require IT approval</p>
                  <p className="text-slate-500 text-xs">If off, access granted instantly</p>
                </div>
                <button onClick={() => set('requireApproval', !form.requireApproval)}
                  className={`w-11 h-6 rounded-full relative transition-colors ${form.requireApproval ? 'bg-indigo-600' : 'bg-slate-600'}`}>
                  <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.requireApproval ? 'translate-x-5' : 'translate-x-0.5'}`} />
                </button>
              </div>
              <div>
                <label className="block text-slate-300 text-xs font-semibold mb-1.5">Session duration</label>
                <select value={form.sessionDurationMinutes} onChange={e => set('sessionDurationMinutes', Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value={15}>15 minutes</option>
                  <option value={30}>30 minutes</option>
                  <option value={60}>1 hour</option>
                  <option value={120}>2 hours</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-300 text-xs font-semibold mb-1.5">Cooldown between requests</label>
                <select value={form.cooldownMinutes} onChange={e => set('cooldownMinutes', Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value={0}>No cooldown</option>
                  <option value={30}>30 minutes</option>
                  <option value={60}>1 hour</option>
                  <option value={120}>2 hours</option>
                  <option value={480}>8 hours</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {error && <p className="text-red-400 text-sm mt-4">{error}</p>}

        <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 mt-5">
          <p className="text-slate-400 text-xs">
            Adding this client will immediately trigger a .pkg build. Once complete, download it from the client detail page and deploy via MDM. This client counts toward your monthly device billing.
          </p>
        </div>

        <button onClick={handleSubmit} disabled={saving || !form.clientName}
          className="w-full mt-5 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold rounded-lg transition-all">
          {saving ? 'Adding client…' : 'Add client & build .pkg'}
        </button>
      </div>
    </div>
  );
}
