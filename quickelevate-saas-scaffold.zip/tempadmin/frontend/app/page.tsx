'use client';
import Link from 'next/link';
import { Shield, Clock, CheckCircle, Bell, Lock, ArrowRight, Users, Building2 } from 'lucide-react';

const features = [
  { icon: Shield,    title: 'IT-approved access',   desc: 'Every request requires IT approval. One-click Approve or Deny directly from any email client — no dashboard login needed.' },
  { icon: Clock,     title: 'Auto-revocation',       desc: 'Admin rights expire automatically at the end of the session. No manual cleanup, no forgotten elevated accounts.' },
  { icon: Bell,      title: 'Email approvals',       desc: 'Approval requests arrive as clean HTML emails with Approve and Deny buttons. Works with any email client, any device.' },
  { icon: Lock,      title: 'Request signing',       desc: 'Every Mac request is HMAC-signed with a timestamp. A stolen API key alone cannot produce a valid request.' },
  { icon: Shield,    title: 'Device fingerprinting', desc: 'Devices are tracked by IP subnet. Requests from unknown networks trigger an instant security alert to your IT admin.' },
  { icon: Clock,     title: 'MDM native',            desc: 'Deploys as a standard .pkg via Intune, Jamf, or any MDM. No agents, no profiles, no third-party tools.' },
];

const directPlans = [
  {
    name:     'Free',
    price:    0,
    devices:  25,
    badge:    null,
    features: ['25 Mac devices — forever free', 'Unlimited approval requests', 'Email approvals', 'Community support'],
  },
  {
    name:     'Growth',
    price:    49,
    devices:  75,
    badge:    null,
    features: ['75 Mac devices', 'Everything in Free', 'Email support', 'Usage analytics'],
  },
  {
    name:     'Business',
    price:    99,
    devices:  200,
    badge:    'Most popular',
    features: ['200 Mac devices', 'Everything in Growth', 'Priority support', 'Custom session policies'],
  },
  {
    name:     'Enterprise',
    price:    249,
    devices:  500,
    badge:    null,
    features: ['500 Mac devices', 'Everything in Business', 'Priority support + SLA', 'Volume discounts'],
  },
];

const mspPlans = [
  {
    name:     'MSP Starter',
    price:    79,
    devices:  200,
    badge:    null,
    features: ['200 devices across all clients', 'Unlimited client accounts', 'MSP dashboard', 'Per-client .pkg builds', 'Per-client IT admin email', 'Email support'],
  },
  {
    name:     'MSP Growth',
    price:    149,
    devices:  750,
    badge:    'Most popular',
    features: ['750 devices across all clients', 'Everything in MSP Starter', 'Priority support', 'Bulk rebuild all clients'],
  },
  {
    name:     'MSP Scale',
    price:    249,
    devices:  null,
    badge:    null,
    features: ['Unlimited devices', 'Everything in MSP Growth', 'Priority support + SLA', 'Volume discounts available'],
  },
];

const faqs = [
  {
    q: 'How does setup work?',
    a: 'Enter your IT admin email address, configure session settings, download the .pkg, and deploy via MDM. No Azure AD, no SharePoint, no API keys. Free forever for up to 25 devices.',
  },
  {
    q: 'How does the approval actually work?',
    a: 'When a user opens the Request Admin Access app, your IT admin immediately receives an email with Approve and Deny buttons. One click grants or denies access — the Mac responds within 30 seconds. The IT admin never needs to log in to the dashboard.',
  },
  {
    q: 'What happens when a session expires?',
    a: 'A LaunchDaemon fires at exactly the right time and removes the user from the admin group automatically. No manual cleanup required.',
  },
  {
    q: 'Can we customise session duration?',
    a: 'Yes — users choose from 15, 30, or 60 minutes when making a request. You set the default and can configure a cooldown period between requests.',
  },
  {
    q: 'What is the MSP plan and how is it different?',
    a: 'The MSP plan is for IT companies managing Macs on behalf of multiple client companies. One QuickElevate login gives you a dashboard showing all your clients. Each client gets their own .pkg with their own IT admin email — completely isolated from your other clients. Flat monthly pricing, no per-device billing.',
  },
  {
    q: 'Can an MSP use the free plan for their clients?',
    a: 'You can manage a single client on the free plan. For multiple clients the MSP plan gives you one dashboard, one login, and the ability to add and manage clients in seconds rather than juggling separate accounts.',
  },
  {
    q: 'Is the .pkg signed?',
    a: 'Enterprise and MSP Scale customers receive packages signed with our Apple Developer ID. Other tiers are unsigned — Intune, Jamf, and most MDMs accept unsigned .pkg files natively.',
  },
];

export default function LandingPage() {
  return (
    <div style={{ background: '#0A0A0F', color: '#E8E8F0', fontFamily: "'DM Sans', system-ui, sans-serif", minHeight: '100vh' }}>

      {/* NAV */}
      <nav style={{ borderBottom: '1px solid #1E1E2E', padding: '0 5vw', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64, position: 'sticky', top: 0, zIndex: 100, background: 'rgba(10,10,15,0.92)', backdropFilter: 'blur(12px)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Lock size={16} color="white" />
          </div>
          <span style={{ fontWeight: 700, fontSize: 17, letterSpacing: '-0.02em' }}>QuickElevate</span>
          <span style={{ fontSize: 12, color: '#3B82F6', background: '#1D3A6E22', border: '1px solid #1D4ED8', borderRadius: 4, padding: '2px 7px', fontWeight: 600 }}>for macOS</span>
        </div>
        <div style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
          <a href="#features" style={{ color: '#A0A0B8', fontSize: 14, textDecoration: 'none' }}>Features</a>
          <a href="#pricing"  style={{ color: '#A0A0B8', fontSize: 14, textDecoration: 'none' }}>Pricing</a>
          <a href="#msp"      style={{ color: '#A0A0B8', fontSize: 14, textDecoration: 'none' }}>For MSPs</a>
          <a href="#faq"      style={{ color: '#A0A0B8', fontSize: 14, textDecoration: 'none' }}>FAQ</a>
          <Link href="/auth/login"  style={{ color: '#A0A0B8', fontSize: 14, textDecoration: 'none' }}>Sign in</Link>
          <Link href="/auth/signup" style={{ background: '#2563EB', color: 'white', padding: '8px 18px', borderRadius: 8, fontSize: 14, fontWeight: 600, textDecoration: 'none' }}>
            Get started free
          </Link>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ padding: '100px 5vw 80px', maxWidth: 1200, margin: '0 auto', textAlign: 'center' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: '#0F1A2E', border: '1px solid #1E3A5F', borderRadius: 100, padding: '6px 16px', marginBottom: 32 }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#22C55E' }} />
          <span style={{ fontSize: 13, color: '#6BB8FF' }}>Free forever for up to 25 devices — no credit card required</span>
        </div>

        <h1 style={{ fontSize: 'clamp(38px, 6vw, 68px)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-0.04em', marginBottom: 24 }}>
          Temporary admin access<br />
          <span style={{ background: 'linear-gradient(135deg, #3B82F6, #8B5CF6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            for Mac devices
          </span>
        </h1>

        <p style={{ fontSize: 20, color: '#8888A8', maxWidth: 580, margin: '0 auto 16px', lineHeight: 1.6 }}>
          Users request admin access. IT approves with one click from their inbox.
          Access revokes automatically when time is up.
        </p>
        <p style={{ fontSize: 15, color: '#555570', marginBottom: 40 }}>
          Deploy via Intune, Jamf, or any MDM — no agents, no Azure setup, no SharePoint.
        </p>

        <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
          <Link href="/auth/signup" style={{ background: '#2563EB', color: 'white', padding: '14px 28px', borderRadius: 10, fontWeight: 700, fontSize: 16, textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 8 }}>
            Start free — 25 devices forever <ArrowRight size={18} />
          </Link>
          <a href="#msp" style={{ background: '#13131F', color: '#C0C0D8', padding: '14px 28px', borderRadius: 10, fontWeight: 600, fontSize: 16, textDecoration: 'none', border: '1px solid #2A2A3E', display: 'inline-flex', alignItems: 'center', gap: 8 }}>
            <Users size={17} /> MSP pricing
          </a>
        </div>

        {/* Email preview */}
        <div style={{ marginTop: 72, background: '#0F0F1A', border: '1px solid #1E1E32', borderRadius: 16, overflow: 'hidden', maxWidth: 620, margin: '72px auto 0', textAlign: 'left' }}>
          <div style={{ background: '#13131F', padding: '12px 20px', borderBottom: '1px solid #1E1E32', display: 'flex', gap: 8, alignItems: 'center' }}>
            {['#FF5F57','#FEBC2E','#28C840'].map(c => <div key={c} style={{ width: 12, height: 12, borderRadius: '50%', background: c }} />)}
            <span style={{ marginLeft: 8, fontSize: 12, color: '#555570' }}>📧 [Admin Request] John on MacBook Pro</span>
          </div>
          <div style={{ padding: 28 }}>
            <div style={{ background: '#1A1A2E', padding: '14px 18px', borderRadius: 8, marginBottom: 18 }}>
              <div style={{ fontSize: 15, fontWeight: 700, color: 'white', marginBottom: 2 }}>🔐 Admin Access Request</div>
              <div style={{ fontSize: 12, color: '#555570' }}>Acme Corp · IT approval required</div>
            </div>
            {[['User','John Smith'],['Device','MacBook Pro (M3)'],['Reason','Install Xcode command line tools'],['Duration','30 minutes']].map(([k,v]) => (
              <div key={k} style={{ display: 'flex', padding: '7px 0', borderBottom: '1px solid #1A1A2A', gap: 16 }}>
                <span style={{ width: 80, fontWeight: 600, fontSize: 13, color: '#8888A8', flexShrink: 0 }}>{k}</span>
                <span style={{ fontSize: 13, color: '#C8C8E0' }}>{v}</span>
              </div>
            ))}
            <div style={{ display: 'flex', gap: 12, marginTop: 22, justifyContent: 'center' }}>
              <div style={{ background: '#16A34A', color: 'white', padding: '10px 32px', borderRadius: 8, fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>✓ Approve</div>
              <div style={{ background: '#DC2626', color: 'white', padding: '10px 32px', borderRadius: 8, fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>✗ Deny</div>
            </div>
            <p style={{ textAlign: 'center', fontSize: 11, color: '#333350', marginTop: 14 }}>One click · Mac responds within 30 seconds · Access auto-revokes after 30 min</p>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" style={{ padding: '80px 5vw', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <h2 style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 12 }}>Built for how IT actually works</h2>
          <p style={{ color: '#8888A8', fontSize: 17 }}>No new vendors. No MDM profiles. No Azure setup. Just email.</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20 }}>
          {features.map(({ icon: Icon, title, desc }) => (
            <div key={title} style={{ background: '#0F0F1A', border: '1px solid #1E1E32', borderRadius: 14, padding: 28 }}>
              <div style={{ width: 42, height: 42, borderRadius: 10, background: '#0F1E3A', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
                <Icon size={20} color="#3B82F6" />
              </div>
              <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 8 }}>{title}</div>
              <div style={{ color: '#8888A8', fontSize: 14, lineHeight: 1.6 }}>{desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING — FOR IT TEAMS */}
      <section id="pricing" style={{ padding: '80px 5vw', maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 16 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: '#0D1F0D', border: '1px solid #1A3A1A', borderRadius: 100, padding: '5px 14px', marginBottom: 20 }}>
            <Building2 size={13} color="#22C55E" />
            <span style={{ fontSize: 13, color: '#22C55E', fontWeight: 600 }}>For IT teams</span>
          </div>
          <h2 style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 10 }}>Managing your own Macs?</h2>
          <p style={{ color: '#8888A8', fontSize: 17, marginBottom: 8 }}>Start free. Upgrade only when you need more devices.</p>
          <p style={{ color: '#555570', fontSize: 14 }}>One company · one IT admin email · one .pkg</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 20, marginTop: 48 }}>
          {directPlans.map(plan => (
            <div key={plan.name} style={{
              background: plan.badge ? '#0F1E3A' : '#0F0F1A',
              border: `1px solid ${plan.badge ? '#2563EB' : '#1E1E32'}`,
              borderRadius: 16, padding: 28, position: 'relative',
              outline: plan.badge ? '1px solid #2563EB' : 'none',
            }}>
              {plan.badge && (
                <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: '#2563EB', color: 'white', fontSize: 11, fontWeight: 700, padding: '3px 12px', borderRadius: 100, whiteSpace: 'nowrap' }}>
                  {plan.badge.toUpperCase()}
                </div>
              )}
              <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 6 }}>{plan.name}</div>
              <div style={{ marginBottom: 6 }}>
                {plan.price === 0 ? (
                  <span style={{ fontSize: 40, fontWeight: 800, letterSpacing: '-0.03em', color: '#22C55E' }}>Free</span>
                ) : (
                  <><span style={{ fontSize: 40, fontWeight: 800, letterSpacing: '-0.03em' }}>${plan.price}</span><span style={{ color: '#8888A8', fontSize: 14 }}>/mo</span></>
                )}
              </div>
              <div style={{ fontSize: 13, color: '#6B8EAE', marginBottom: 20, fontWeight: 600 }}>
                {plan.devices} Mac devices
              </div>
              <div style={{ marginBottom: 24 }}>
                {plan.features.map(f => (
                  <div key={f} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 8 }}>
                    <CheckCircle size={14} color={plan.badge ? '#3B82F6' : '#22C55E'} style={{ flexShrink: 0, marginTop: 2 }} />
                    <span style={{ fontSize: 13, color: '#C0C0D8', lineHeight: 1.4 }}>{f}</span>
                  </div>
                ))}
              </div>
              <Link href="/auth/signup" style={{
                display: 'block', textAlign: 'center', padding: '11px',
                background: plan.badge ? '#2563EB' : 'transparent',
                border: `1px solid ${plan.badge ? '#2563EB' : '#2A2A3E'}`,
                color: 'white', borderRadius: 8, fontWeight: 700, fontSize: 13, textDecoration: 'none',
              }}>
                {plan.price === 0 ? 'Get started free' : 'Start free trial'}
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING — FOR MSPs */}
      <section id="msp" style={{ padding: '80px 5vw', maxWidth: 1100, margin: '0 auto' }}>

        {/* Divider */}
        <div style={{ border: 'none', borderTop: '1px solid #1E1E32', marginBottom: 80 }} />

        <div style={{ textAlign: 'center', marginBottom: 16 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: '#1A0F2E', border: '1px solid #3A1A6E', borderRadius: 100, padding: '5px 14px', marginBottom: 20 }}>
            <Users size={13} color="#8B5CF6" />
            <span style={{ fontSize: 13, color: '#8B5CF6', fontWeight: 600 }}>For MSPs</span>
          </div>
          <h2 style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 10 }}>Managing Macs for multiple clients?</h2>
          <p style={{ color: '#8888A8', fontSize: 17, marginBottom: 8 }}>One login. One dashboard. All your clients.</p>
          <p style={{ color: '#555570', fontSize: 14 }}>Each client gets their own .pkg, their own IT admin email, and their own completely isolated approval flow. Flat monthly pricing — no per-device billing, no surprises.</p>
        </div>

        {/* How MSP works */}
        <div style={{ background: '#0F0F1A', border: '1px solid #1E1E32', borderRadius: 14, padding: '28px 32px', maxWidth: 740, margin: '40px auto 56px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          <div>
            <div style={{ fontSize: 13, color: '#555570', fontWeight: 600, marginBottom: 12 }}>WITHOUT MSP PLAN</div>
            {['10 separate QuickElevate logins','Log in/out to manage each client','Rebuild .pkgs one account at a time','No overview across clients'].map(t => (
              <div key={t} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'flex-start' }}>
                <span style={{ color: '#DC2626', fontSize: 14, flexShrink: 0 }}>✗</span>
                <span style={{ fontSize: 13, color: '#888898', lineHeight: 1.4 }}>{t}</span>
              </div>
            ))}
          </div>
          <div>
            <div style={{ fontSize: 13, color: '#8B5CF6', fontWeight: 600, marginBottom: 12 }}>WITH MSP PLAN</div>
            {['One login for all clients','Add a new client in 30 seconds','Rebuild any client .pkg in one click','Live device counts across all clients'].map(t => (
              <div key={t} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'flex-start' }}>
                <span style={{ color: '#22C55E', fontSize: 14, flexShrink: 0 }}>✓</span>
                <span style={{ fontSize: 13, color: '#C0C0D8', lineHeight: 1.4 }}>{t}</span>
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {mspPlans.map(plan => (
            <div key={plan.name} style={{
              background: plan.badge ? '#1A0F2E' : '#0F0F1A',
              border: `1px solid ${plan.badge ? '#7C3AED' : '#1E1E32'}`,
              borderRadius: 16, padding: 28, position: 'relative',
            }}>
              {plan.badge && (
                <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: '#7C3AED', color: 'white', fontSize: 11, fontWeight: 700, padding: '3px 12px', borderRadius: 100, whiteSpace: 'nowrap' }}>
                  {plan.badge.toUpperCase()}
                </div>
              )}
              <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 6 }}>{plan.name}</div>
              <div style={{ marginBottom: 6 }}>
                <span style={{ fontSize: 40, fontWeight: 800, letterSpacing: '-0.03em' }}>${plan.price}</span>
                <span style={{ color: '#8888A8', fontSize: 14 }}>/mo</span>
              </div>
              <div style={{ fontSize: 13, color: '#9B7AE0', marginBottom: 20, fontWeight: 600 }}>
                {plan.devices ? `${plan.devices.toLocaleString()} devices across all clients` : 'Unlimited devices'}
              </div>
              <div style={{ marginBottom: 24 }}>
                {plan.features.map(f => (
                  <div key={f} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 8 }}>
                    <CheckCircle size={14} color={plan.badge ? '#8B5CF6' : '#22C55E'} style={{ flexShrink: 0, marginTop: 2 }} />
                    <span style={{ fontSize: 13, color: '#C0C0D8', lineHeight: 1.4 }}>{f}</span>
                  </div>
                ))}
              </div>
              <Link href="/auth/signup" style={{
                display: 'block', textAlign: 'center', padding: '11px',
                background: plan.badge ? '#7C3AED' : 'transparent',
                border: `1px solid ${plan.badge ? '#7C3AED' : '#2A2A3E'}`,
                color: 'white', borderRadius: 8, fontWeight: 700, fontSize: 13, textDecoration: 'none',
              }}>
                Start MSP trial
              </Link>
            </div>
          ))}
        </div>

        <p style={{ textAlign: 'center', fontSize: 13, color: '#555570', marginTop: 20 }}>
          Approval emails still go directly to each client's IT admin inbox — the MSP never sees them unless configured to.
        </p>
      </section>

      {/* FAQ */}
      <section id="faq" style={{ padding: '80px 5vw', maxWidth: 760, margin: '0 auto' }}>
        <h2 style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 48, textAlign: 'center' }}>Frequently asked questions</h2>
        {faqs.map(({ q, a }) => (
          <div key={q} style={{ borderBottom: '1px solid #1E1E32', padding: '22px 0' }}>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 8 }}>{q}</div>
            <div style={{ color: '#8888A8', fontSize: 14, lineHeight: 1.7 }}>{a}</div>
          </div>
        ))}
      </section>

      {/* CTA */}
      <section style={{ padding: '80px 5vw', textAlign: 'center' }}>
        <div style={{ background: '#0F1E3A', border: '1px solid #1E3A5F', borderRadius: 20, padding: '60px 40px', maxWidth: 800, margin: '0 auto' }}>
          <h2 style={{ fontSize: 38, fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 12 }}>Ready to get started?</h2>
          <p style={{ color: '#8888A8', fontSize: 17, marginBottom: 40 }}>Free forever for 25 devices. No credit card. Setup in under 5 minutes.</p>
          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/auth/signup" style={{ background: '#2563EB', color: 'white', padding: '14px 32px', borderRadius: 10, fontWeight: 700, fontSize: 16, textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              <Building2 size={18} /> Start free — for IT teams
            </Link>
            <Link href="/auth/signup?msp=1" style={{ background: '#7C3AED', color: 'white', padding: '14px 32px', borderRadius: 10, fontWeight: 700, fontSize: 16, textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              <Users size={18} /> Start MSP trial
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ borderTop: '1px solid #1E1E32', padding: '32px 5vw', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 24, height: 24, borderRadius: 6, background: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Lock size={12} color="white" />
          </div>
          <span style={{ fontSize: 14, fontWeight: 600 }}>QuickElevate for macOS</span>
        </div>
        <div style={{ fontSize: 13, color: '#555570' }}>
          © 2026 Cloud Vanguard IT ·{' '}
          <a href="/privacy" style={{ color: '#555570', textDecoration: 'none' }}>Privacy</a> ·{' '}
          <a href="/terms"   style={{ color: '#555570', textDecoration: 'none' }}>Terms</a>
        </div>
      </footer>

    </div>
  );
}
