'use client';
import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Users, Package, DollarSign, Activity, Search, ChevronDown } from 'lucide-react';

export default function AdminPage() {
  const [stats,     setStats]     = useState<any>(null);
  const [customers, setCustomers] = useState<any[]>([]);
  const [search,    setSearch]    = useState('');
  const [filter,    setFilter]    = useState('ALL');
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    Promise.all([
      fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/stats`,     { credentials: 'include' }).then(r => r.json()),
      fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/customers`, { credentials: 'include' }).then(r => r.json()),
    ]).then(([s, c]) => {
      setStats(s);
      setCustomers(c.customers || []);
      setLoading(false);
    }).catch(() => { toast.error('Failed to load admin data'); setLoading(false); });
  }, []);

  const filtered = customers.filter(c => {
    const matchSearch = !search || c.email.includes(search) || c.companyName.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'ALL' || c.plan === filter;
    return matchSearch && matchFilter;
  });

  const PLAN_COLORS: Record<string, string> = {
    TRIAL: '#EAB308', STARTER: '#3B82F6', BUSINESS: '#8B5CF6', ENTERPRISE: '#22C55E',
  };
  const STATUS_COLORS: Record<string, string> = {
    ACTIVE: '#22C55E', PAST_DUE: '#EF4444', CANCELLED: '#6B7280', EXPIRED: '#EF4444',
  };

  return (
    <div style={{ minHeight: '100vh', background: '#0A0A0F', color: '#E8E8F0', fontFamily: "'DM Sans', system-ui, sans-serif" }}>

      {/* Header */}
      <div style={{ borderBottom: '1px solid #1E1E2E', padding: '0 5vw', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 60 }}>
        <span style={{ fontWeight: 800, fontSize: 16 }}>QuickElevate — Admin Panel</span>
        <span style={{ fontSize: 12, background: '#1A0F2E', color: '#A78BFA', padding: '4px 12px', borderRadius: 100, border: '1px solid #4C1D95' }}>Internal Use Only</span>
      </div>

      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '40px 5vw' }}>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 36 }}>
          {[
            { label: 'Total Customers', value: stats?.totalCustomers || 0,  icon: Users,       color: '#3B82F6' },
            { label: 'Active Paid',      value: stats?.activePaid     || 0,  icon: DollarSign,  color: '#22C55E' },
            { label: 'Total Devices',    value: stats?.totalDevices   || 0,  icon: Package,     color: '#8B5CF6' },
            { label: 'Builds Today',     value: stats?.buildsToday    || 0,  icon: Activity,    color: '#EAB308' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} style={{ background: '#0F0F1A', border: '1px solid #1E1E32', borderRadius: 12, padding: '20px 24px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                <Icon size={16} color={color} />
                <span style={{ fontSize: 12, color: '#555570', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</span>
              </div>
              <div style={{ fontSize: 28, fontWeight: 800 }}>{value}</div>
            </div>
          ))}
        </div>

        {/* MRR estimate */}
        <div style={{ background: 'linear-gradient(135deg, #0F1E3A, #0A1528)', border: '1px solid #1E3A5F', borderRadius: 14, padding: '20px 28px', marginBottom: 32, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 13, color: '#8888A8', marginBottom: 4 }}>Estimated Monthly Recurring Revenue</div>
            <div style={{ fontSize: 36, fontWeight: 800, color: '#93C5FD' }}>
              ${((stats?.starterCount || 0) * 49 + (stats?.businessCount || 0) * 149).toLocaleString()}
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 13, color: '#8888A8', marginBottom: 4 }}>Breakdown</div>
            <div style={{ fontSize: 14, color: '#C0C0D8' }}>{stats?.starterCount || 0} × Starter + {stats?.businessCount || 0} × Business</div>
          </div>
        </div>

        {/* Customers table */}
        <div style={{ background: '#0F0F1A', border: '1px solid #1E1E32', borderRadius: 14, overflow: 'hidden' }}>
          <div style={{ padding: '20px 24px', borderBottom: '1px solid #1E1E32', display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
            <h3 style={{ fontWeight: 700, fontSize: 16, margin: 0 }}>Customers</h3>
            <div style={{ flex: 1, minWidth: 200, position: 'relative' }}>
              <Search size={14} color="#555570" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by email or company..."
                style={{ width: '100%', background: '#0A0A0F', border: '1px solid #2A2A3E', borderRadius: 8, padding: '8px 12px 8px 34px', color: '#E8E8F0', fontSize: 13, boxSizing: 'border-box' }} />
            </div>
            <select value={filter} onChange={e => setFilter(e.target.value)}
              style={{ background: '#0A0A0F', border: '1px solid #2A2A3E', borderRadius: 8, padding: '8px 32px 8px 12px', color: '#E8E8F0', fontSize: 13, cursor: 'pointer' }}>
              {['ALL','TRIAL','STARTER','BUSINESS','ENTERPRISE'].map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          {/* Table header */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1.5fr 1fr 1fr 1fr 1fr', padding: '10px 24px', background: '#13131F' }}>
            {['Company', 'Email', 'Plan', 'Status', 'Devices', 'Joined'].map(h => (
              <span key={h} style={{ fontSize: 11, fontWeight: 700, color: '#555570', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>

          {/* Table rows */}
          {loading ? (
            <div style={{ padding: '40px 24px', textAlign: 'center', color: '#555570' }}>Loading customers...</div>
          ) : filtered.length === 0 ? (
            <div style={{ padding: '40px 24px', textAlign: 'center', color: '#555570' }}>No customers found</div>
          ) : filtered.map((c, i) => (
            <div key={c.id} style={{ display: 'grid', gridTemplateColumns: '2fr 1.5fr 1fr 1fr 1fr 1fr', padding: '14px 24px', borderTop: '1px solid #13131F', background: i % 2 === 0 ? 'transparent' : '#0D0D18', alignItems: 'center' }}>
              <span style={{ fontWeight: 600, fontSize: 14 }}>{c.companyName}</span>
              <span style={{ fontSize: 13, color: '#8888A8', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.email}</span>
              <span style={{ fontSize: 12, fontWeight: 700, color: PLAN_COLORS[c.plan] || '#8888A8', background: `${PLAN_COLORS[c.plan]}15`, padding: '3px 10px', borderRadius: 100, display: 'inline-block' }}>{c.plan}</span>
              <span style={{ fontSize: 12, color: STATUS_COLORS[c.planStatus] || '#8888A8' }}>{c.planStatus}</span>
              <span style={{ fontSize: 14 }}>{c._count?.devices || 0} / {c.deviceLimit}</span>
              <span style={{ fontSize: 12, color: '#555570' }}>{new Date(c.createdAt).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
