import { SignUp } from '@clerk/nextjs';
import { Lock } from 'lucide-react';
import Link from 'next/link';

export default function SignUpPage() {
  return (
    <div style={{ minHeight: '100vh', background: '#0A0A0F', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontFamily: "'DM Sans', system-ui, sans-serif" }}>

      <div style={{ marginBottom: 32, textAlign: 'center' }}>
        <Link href="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
          <div style={{ width: 36, height: 36, borderRadius: 9, background: 'linear-gradient(135deg, #3B82F6, #1D4ED8)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Lock size={18} color="white" />
          </div>
          <span style={{ fontWeight: 800, fontSize: 20, color: '#E8E8F0', letterSpacing: '-0.02em' }}>QuickElevate for macOS</span>
        </Link>
        <p style={{ color: '#8888A8', fontSize: 14, marginTop: 10 }}>Start your 14-day free trial — no credit card required</p>
      </div>

      <SignUp
        appearance={{
          variables: {
            colorBackground: '#0F0F1A',
            colorText: '#E8E8F0',
            colorPrimary: '#2563EB',
            colorInputBackground: '#0A0A0F',
            colorInputText: '#E8E8F0',
            borderRadius: '10px',
            fontFamily: "'DM Sans', system-ui, sans-serif",
          },
          elements: {
            card: { border: '1px solid #1E1E32', boxShadow: 'none' },
            headerTitle: { color: '#E8E8F0' },
            headerSubtitle: { color: '#8888A8' },
            formButtonPrimary: { background: '#2563EB', fontWeight: 700 },
            footerActionLink: { color: '#3B82F6' },
            formFieldInput: { border: '1px solid #2A2A3E' },
          },
        }}
      />
    </div>
  );
}
