'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function OnboardingCompanyPage() {
  const router = useRouter();
  const [companyName, setCompanyName] = useState('');
  const [error,  setError]  = useState('');
  const [saving, setSaving] = useState(false);

  async function handleNext() {
    if (!companyName.trim()) { setError('Please enter your company name.'); return; }
    setSaving(true);
    try {
      const res = await fetch('/api/customer/me', {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ companyName: companyName.trim() }),
      });
      if (!res.ok) throw new Error((await res.json()).error || 'Save failed');
      router.push('/onboarding/email');
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="mb-8">
        <div className="text-5xl mb-4">👋</div>
        <h1 className="text-3xl font-bold text-white mb-2">Welcome to QuickElevate</h1>
        <p className="text-slate-400 text-base">
          Let's get you set up. This takes about 2 minutes — and the only thing you need is your IT admin's email address.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 mb-8">
        <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-4">What you'll need</p>
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <span className="text-green-400 font-bold text-lg">✓</span>
            <span className="text-slate-300 text-sm">Your IT admin's email address</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-600 text-lg">—</span>
            <span className="text-slate-500 text-sm line-through">Azure AD app registration</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-600 text-lg">—</span>
            <span className="text-slate-500 text-sm line-through">SharePoint configuration</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-600 text-lg">—</span>
            <span className="text-slate-500 text-sm line-through">Client secrets or API keys</span>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-semibold text-slate-300 mb-2">Company name</label>
        <input
          type="text"
          value={companyName}
          onChange={e => setCompanyName(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleNext()}
          placeholder="Acme Corp"
          className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-base"
        />
        <p className="text-slate-500 text-xs mt-2">This appears in approval emails sent to your IT admin.</p>
        {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
      </div>

      <button
        onClick={handleNext}
        disabled={saving || !companyName.trim()}
        className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold rounded-lg transition-all text-base">
        {saving ? 'Saving…' : 'Get Started →'}
      </button>
    </div>
  );
}
