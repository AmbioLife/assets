'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function OnboardingConfigurePage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error,  setError]  = useState('');

  const [form, setForm] = useState({
    sessionDurationMinutes:  60,
    cooldownMinutes:         60,
    approvalTimeoutMinutes:  30,
    requireApproval:         true,
    excludedAccounts:        'lapsadmin',
  });

  function set(key: string, value: any) {
    setForm(f => ({ ...f, [key]: value }));
  }

  async function handleNext() {
    setError('');
    setSaving(true);
    try {
      const res = await fetch('/api/config/step/2', {
        method:  'PUT',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(form),
      });
      if (!res.ok) throw new Error((await res.json()).error || 'Save failed');
      router.push('/onboarding/complete');
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="mb-8">
        <span className="inline-flex items-center gap-2 bg-indigo-950 border border-indigo-700 text-indigo-300 text-xs font-semibold px-3 py-1 rounded-full mb-4">
          Step 2 of 3
        </span>
        <h1 className="text-3xl font-bold text-white mb-2">Session settings</h1>
        <p className="text-slate-400">All fields have sensible defaults — you can change these any time from your dashboard.</p>
      </div>

      <div className="flex flex-col gap-5">

        {/* Require approval toggle */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-semibold text-sm">Require IT approval</p>
              <p className="text-slate-400 text-xs mt-0.5">If off, admin access is granted instantly without an email.</p>
            </div>
            <button
              onClick={() => set('requireApproval', !form.requireApproval)}
              className={`w-12 h-6 rounded-full transition-colors relative ${form.requireApproval ? 'bg-indigo-600' : 'bg-slate-600'}`}>
              <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.requireApproval ? 'translate-x-6' : 'translate-x-0.5'}`} />
            </button>
          </div>
        </div>

        {/* Duration */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
          <label className="block text-white font-semibold text-sm mb-1">Default session duration</label>
          <p className="text-slate-400 text-xs mb-3">How long admin rights last. Users can also choose 15 or 30 min.</p>
          <select
            value={form.sessionDurationMinutes}
            onChange={e => set('sessionDurationMinutes', Number(e.target.value))}
            className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
            <option value={15}>15 minutes</option>
            <option value={30}>30 minutes</option>
            <option value={60}>1 hour (recommended)</option>
            <option value={120}>2 hours</option>
            <option value={240}>4 hours</option>
          </select>
        </div>

        {/* Cooldown */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
          <label className="block text-white font-semibold text-sm mb-1">Cooldown period</label>
          <p className="text-slate-400 text-xs mb-3">How long a user must wait before requesting access again.</p>
          <select
            value={form.cooldownMinutes}
            onChange={e => set('cooldownMinutes', Number(e.target.value))}
            className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
            <option value={0}>No cooldown</option>
            <option value={30}>30 minutes</option>
            <option value={60}>1 hour (recommended)</option>
            <option value={120}>2 hours</option>
            <option value={480}>8 hours</option>
            <option value={1440}>24 hours</option>
          </select>
        </div>

        {/* Approval timeout */}
        {form.requireApproval && (
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <label className="block text-white font-semibold text-sm mb-1">Approval timeout</label>
            <p className="text-slate-400 text-xs mb-3">If IT doesn't respond within this time, the request expires.</p>
            <select
              value={form.approvalTimeoutMinutes}
              onChange={e => set('approvalTimeoutMinutes', Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option value={15}>15 minutes</option>
              <option value={30}>30 minutes (recommended)</option>
              <option value={60}>1 hour</option>
              <option value={120}>2 hours</option>
            </select>
          </div>
        )}

        {/* Excluded accounts */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
          <label className="block text-white font-semibold text-sm mb-1">Excluded accounts</label>
          <p className="text-slate-400 text-xs mb-3">Usernames that can never request admin access (e.g. your MDM service account). Comma-separated.</p>
          <input
            type="text"
            value={form.excludedAccounts}
            onChange={e => set('excludedAccounts', e.target.value)}
            placeholder="lapsadmin, mdmadmin"
            className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

      </div>

      {error && <p className="text-red-400 text-sm mt-4">{error}</p>}

      <div className="flex gap-3 mt-8">
        <button onClick={() => router.back()} className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-lg transition-all text-sm">
          ← Back
        </button>
        <button
          onClick={handleNext}
          disabled={saving}
          className="flex-[2] py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold rounded-lg transition-all text-base">
          {saving ? 'Saving…' : 'Continue →'}
        </button>
      </div>
    </div>
  );
}
