'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function OnboardingEmailPage() {
  const router = useRouter();
  const [email, setEmail]   = useState('');
  const [error, setError]   = useState('');
  const [saving, setSaving] = useState(false);

  async function handleNext() {
    setError('');
    if (!email || !email.includes('@')) { setError('Please enter a valid email address.'); return; }

    setSaving(true);
    try {
      const res = await fetch('/api/config/step/1', {
        method:  'PUT',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ itAdminEmail: email }),
      });
      if (!res.ok) throw new Error((await res.json()).error || 'Save failed');
      router.push('/onboarding/configure');
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="mb-8">
        <span className="inline-flex items-center gap-2 bg-indigo-950 border border-indigo-700 text-indigo-300 text-xs font-semibold px-3 py-1 rounded-full mb-4">
          Step 1 of 3
        </span>
        <h1 className="text-3xl font-bold text-white mb-2">Where should approval emails go?</h1>
        <p className="text-slate-400 text-base">
          When a user requests admin access, QuickElevate emails this address with one-click Approve / Deny buttons.
          That's the only setup required.
        </p>
      </div>

      {/* Visual explainer */}
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-5 mb-8">
        <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-4">How it works</p>
        <div className="flex flex-col gap-3">
          {[
            { icon: '🖥️', text: 'User opens "Request Admin Access" on their Mac' },
            { icon: '📧', text: 'IT admin receives an email with Approve / Deny buttons' },
            { icon: '✅', text: 'One click grants or denies access — Mac responds in 30 seconds' },
            { icon: '⏱️', text: 'Admin rights expire automatically at the end of the session' },
          ].map(({ icon, text }) => (
            <div key={text} className="flex items-center gap-3">
              <span className="text-xl w-7 shrink-0">{icon}</span>
              <span className="text-slate-300 text-sm">{text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Email input */}
      <div className="mb-6">
        <label className="block text-sm font-semibold text-slate-300 mb-2">
          IT Admin Email Address
        </label>
        <input
          type="email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleNext()}
          placeholder="it-admin@yourcompany.com"
          className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-base"
        />
        <p className="text-slate-500 text-xs mt-2">
          Can be a shared mailbox, distribution list, or a single person — whoever handles IT requests.
        </p>
        {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
      </div>

      <button
        onClick={handleNext}
        disabled={saving || !email}
        className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold rounded-lg transition-all text-base"
      >
        {saving ? 'Saving…' : 'Continue →'}
      </button>
    </div>
  );
}
