'use client';
import { usePathname } from 'next/navigation';
import Link from 'next/link';

const STEPS = [
  { num: 1, label: 'IT Admin Email', path: '/onboarding/email'     },
  { num: 2, label: 'Session Settings', path: '/onboarding/configure' },
  { num: 3, label: 'Build & Download', path: '/onboarding/complete'  },
];

export default function OnboardingLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const current  = STEPS.findIndex(s => pathname.includes(s.path.split('/')[2])) + 1 || 1;

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col p-8">
        <div className="mb-10">
          <span className="text-white font-bold text-lg">🔐 QuickElevate</span>
          <p className="text-slate-400 text-xs mt-1">Setup · {current} of {STEPS.length}</p>
        </div>
        <nav className="flex flex-col gap-3">
          {STEPS.map(step => {
            const done    = step.num < current;
            const active  = step.num === current;
            return (
              <div key={step.num} className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all
                ${active ? 'bg-indigo-600' : done ? 'opacity-70' : 'opacity-40'}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0
                  ${done ? 'bg-green-500 text-white' : active ? 'bg-white text-indigo-600' : 'bg-slate-700 text-slate-400'}`}>
                  {done ? '✓' : step.num}
                </div>
                <span className={`text-sm font-medium ${active ? 'text-white' : 'text-slate-400'}`}>{step.label}</span>
              </div>
            );
          })}
        </nav>
        <div className="mt-auto">
          <div className="bg-indigo-950 border border-indigo-800 rounded-lg p-4">
            <p className="text-indigo-300 text-xs font-semibold mb-1">⚡ 2-minute setup</p>
            <p className="text-indigo-400 text-xs">Just your IT admin email — no Azure, no SharePoint, no API keys.</p>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex items-center justify-center p-12">
        <div className="w-full max-w-xl">{children}</div>
      </main>
    </div>
  );
}
