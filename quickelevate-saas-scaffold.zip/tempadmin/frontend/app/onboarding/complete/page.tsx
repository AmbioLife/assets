'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

type BuildStatus = 'idle' | 'starting' | 'building' | 'success' | 'failed';

export default function OnboardingCompletePage() {
  const router = useRouter();
  const [status,    setStatus]    = useState<BuildStatus>('idle');
  const [buildId,   setBuildId]   = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [error,     setError]     = useState('');

  useEffect(() => { startBuild(); }, []);

  async function startBuild() {
    setStatus('starting');
    setError('');
    try {
      // Finalise onboarding
      await fetch('/api/config/complete', { method: 'POST' });

      // Trigger build
      const res = await fetch('/api/build/trigger', { method: 'POST' });
      if (!res.ok) throw new Error((await res.json()).error || 'Build trigger failed');
      const { buildId } = await res.json();
      setBuildId(buildId);
      setStatus('building');
      pollStatus(buildId);
    } catch (e: any) {
      setError(e.message);
      setStatus('failed');
    }
  }

  async function pollStatus(id: string) {
    const interval = setInterval(async () => {
      try {
        const res  = await fetch(`/api/build/${id}/status`);
        const data = await res.json();
        if (data.build.status === 'SUCCESS') {
          clearInterval(interval);
          setStatus('success');
          const dlRes  = await fetch(`/api/build/${id}/download`);
          const dlData = await dlRes.json();
          setDownloadUrl(dlData.downloadUrl);
        } else if (data.build.status === 'FAILED') {
          clearInterval(interval);
          setError(data.build.errorMessage || 'Build failed');
          setStatus('failed');
        }
      } catch {}
    }, 4000);
  }

  return (
    <div>
      <div className="mb-8">
        <span className="inline-flex items-center gap-2 bg-indigo-950 border border-indigo-700 text-indigo-300 text-xs font-semibold px-3 py-1 rounded-full mb-4">
          Step 3 of 3
        </span>
        <h1 className="text-3xl font-bold text-white mb-2">Building your .pkg installer</h1>
        <p className="text-slate-400">Your custom RequestAdminAccess.pkg is being built now. This takes about 2 minutes.</p>
      </div>

      {/* Status card */}
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-8 text-center mb-6">
        {(status === 'starting' || status === 'building') && (
          <>
            <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-5" />
            <p className="text-white font-semibold text-lg mb-1">
              {status === 'starting' ? 'Starting build…' : 'Building your .pkg…'}
            </p>
            <p className="text-slate-400 text-sm">macOS runner is packaging your installer with your settings baked in.</p>
            <div className="flex justify-center gap-6 mt-6">
              {['Queuing runner', 'Running build', 'Uploading .pkg'].map((step, i) => (
                <div key={step} className="flex flex-col items-center gap-1.5">
                  <div className={`w-3 h-3 rounded-full ${i === 0 ? 'bg-green-500' : i === 1 && status === 'building' ? 'bg-indigo-400 animate-pulse' : 'bg-slate-700'}`} />
                  <span className="text-slate-500 text-xs">{step}</span>
                </div>
              ))}
            </div>
          </>
        )}

        {status === 'success' && (
          <>
            <div className="text-6xl mb-4">🎉</div>
            <p className="text-white font-bold text-xl mb-2">Your .pkg is ready!</p>
            <p className="text-slate-400 text-sm mb-6">Deploy this to your Macs via Intune, Jamf, or any MDM.</p>
            <a
              href={downloadUrl}
              download="RequestAdminAccess.pkg"
              className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl transition-all text-lg"
            >
              ⬇️ Download RequestAdminAccess.pkg
            </a>
          </>
        )}

        {status === 'failed' && (
          <>
            <div className="text-5xl mb-4">❌</div>
            <p className="text-white font-semibold text-lg mb-2">Build failed</p>
            <p className="text-red-400 text-sm mb-4">{error}</p>
            <button onClick={startBuild} className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold text-sm">
              Retry Build
            </button>
          </>
        )}
      </div>

      {status === 'success' && (
        <div className="flex flex-col gap-3">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <p className="text-white font-semibold text-sm mb-3">📋 Next steps</p>
            <div className="flex flex-col gap-2">
              {[
                'Deploy RequestAdminAccess.pkg via your MDM (Intune, Jamf, etc.)',
                'Users will see "Request Admin Access" in /Applications',
                'When they open it, your IT admin email receives an approval request',
                'One click in the email grants or denies access',
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-xs flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                  <span className="text-slate-300 text-sm">{step}</span>
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={() => router.push('/dashboard')}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-lg transition-all text-sm mt-2">
            Go to Dashboard →
          </button>
        </div>
      )}
    </div>
  );
}
