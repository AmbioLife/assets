# GitHub Actions Build Setup

QuickElevate uses GitHub Actions (`macos-latest`) to build `.pkg` files because
`pkgbuild` and `productbuild` are Apple-only tools that can't run on Linux.

The backend triggers a build via `repository_dispatch`, GitHub runs the workflow
on a free macOS runner, and when it finishes it calls back to the backend API.

---

## Which build_pkg.sh to use

**Use the one already in the scaffold zip** at `infra/pkg-builder/build_pkg.sh`.

This is the correct, current build script. It uses your QuickElevate backend API
and customer API keys — no Azure AD, no SharePoint, no Microsoft Graph.

Do NOT use any old Phase 1 build_pkg.sh. The old script was hardcoded with
specific Azure credentials and is not compatible with this SaaS platform.

---

## Step 1 — Create the build repository

Create a **private** GitHub repo (e.g. `quickelevate-builds`).

Clone it and copy the three required files from the scaffold zip:

```bash
git clone https://github.com/YOUR-USERNAME/quickelevate-builds.git
cd quickelevate-builds

mkdir -p infra/pkg-builder
mkdir -p .github/workflows

# Copy all three files from the scaffold
cp ~/quickelevate/infra/pkg-builder/build_pkg.sh           infra/pkg-builder/
cp ~/quickelevate/infra/pkg-builder/build_customer_pkg.sh  infra/pkg-builder/
cp ~/quickelevate/.github/workflows/build-pkg.yml          .github/workflows/

chmod +x infra/pkg-builder/build_pkg.sh
chmod +x infra/pkg-builder/build_customer_pkg.sh

git add .
git commit -m "Add QuickElevate build pipeline"
git push
```

---

## Step 2 — Add GitHub repository secrets

Go to your repo → **Settings → Secrets and variables → Actions → New repository secret**

| Secret name | Value |
|---|---|
| `AZURE_STORAGE_CONNECTION_STRING` | From Azure Portal → Storage Account → Access keys → key1 → Connection string |
| `QE_CALLBACK_SECRET` | Generate with: `openssl rand -hex 32` — must match your backend env var |

Add this repository variable (not a secret):

| Variable name | Value |
|---|---|
| `AZURE_BLOB_CONTAINER` | `pkg-builds` |

---

## Step 3 — Create a GitHub Personal Access Token

Go to **github.com → Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**

- Repository access: Only `quickelevate-builds`
- Permissions: **Contents: Read** · **Actions: Read and write**

Copy the token (starts with `ghp_`). Save as `GITHUB_TOKEN` in your backend environment variables.

---

## Step 4 — Set backend environment variables

Add to Azure App Service → Configuration → Application settings:

```
GITHUB_TOKEN=ghp_xxxx
GITHUB_REPO_OWNER=your-github-username
GITHUB_REPO_NAME=quickelevate-builds
QE_CALLBACK_SECRET=same-secret-as-in-github
BACKEND_URL=https://api.quickelevate.com
```

---

## How the build flow works

```
Customer clicks "Build .pkg" in dashboard
        │
        ▼
Backend: POST /api/build/trigger
  → Creates PkgBuild record (status: PENDING)
  → Calls triggerGitHubBuild()
        │
        ▼
GitHub API: POST /repos/{owner}/{repo}/dispatches
  { event_type: "build-pkg", client_payload: { build_id, config, callback_url } }
        │
        ▼
GitHub Actions: macos-latest runner
  1. Writes customer.env from payload (API key, company name, session settings)
  2. Runs build_customer_pkg.sh → injects config → runs build_pkg.sh
  3. build_pkg.sh creates RequestAdminAccess.pkg with customer API key baked in
  4. Uploads .pkg to Azure Blob Storage
  5. POSTs callback_url { buildId, status, blobUrl }
        │
        ▼
Backend: POST /api/build/callback
  → Verifies X-Callback-Secret header
  → Updates PkgBuild status to SUCCESS + stores blobUrl
        │
        ▼
Frontend: polls /api/build/:id/status every 4 seconds
  → Detects SUCCESS → shows download button
```

---

## Build time

- Queue: 10–30 seconds
- Build: ~60 seconds
- Upload + callback: ~10 seconds
- **Total: ~2 minutes**

---

## Cost

GitHub Actions includes **2,000 free macOS minutes per month** on the free plan.
Each build uses ~2 minutes = ~1,000 free builds/month. Well within free tier for
a SaaS with hundreds of customers who each build once or twice.
