# pkg-builder

This folder contains the server-side build system for generating per-customer `.pkg` installers.

## Files

| File | Purpose |
|---|---|
| `build_customer_pkg.sh` | **Wrapper script** — takes a customer config env file, injects values into a temp copy of the base script, runs the build, outputs the `.pkg` |
| `build_pkg.sh` | **Base build script** — the full 900-line original build logic (NOT included in this repo — deploy separately, see below) |
| `customer.env.template` | Template showing all config variables the wrapper expects |

## Setup on the build server

The `build_pkg.sh` base script is **not included** in this scaffold because it contains your specific IT admin credentials baked in from Phase 1. You need to deploy it manually:

```bash
# Copy the original build_pkg.sh to the build server
scp ~/Downloads/build_pkg.sh user@buildserver:/app/infra/pkg-builder/build_pkg.sh

# Make both scripts executable
chmod +x /app/infra/pkg-builder/build_customer_pkg.sh
chmod +x /app/infra/pkg-builder/build_pkg.sh
```

## How it works

When a customer clicks "Build .pkg" in the dashboard:

1. The backend (`pkgBuilder.ts`) decrypts the customer's Azure credentials
2. Writes them to a temp `customer.env` file (mode 0600, deleted after build)
3. Calls `build_customer_pkg.sh --config customer.env --output output.pkg --base build_pkg.sh`
4. The wrapper patches all hardcoded values in a temp copy of `build_pkg.sh` using Python regex
5. Runs the patched script to produce a `.pkg`
6. The `.pkg` is uploaded to Azure Blob Storage and a signed download URL is returned to the customer

## Security notes

- The `customer.env` file is written to a temp directory and deleted after every build
- Client secrets are stored AES-256 encrypted in the database and only decrypted in memory during builds
- The `customer.env` file is written with mode `0600` (owner-read only)
- Build directories are unique per build ID and fully isolated

## Environment variables required

```bash
PKG_BUILDER_SCRIPT=/app/infra/pkg-builder/build_customer_pkg.sh
BASE_BUILD_SCRIPT=/app/infra/pkg-builder/build_pkg.sh
AZURE_FUNCTION_BASE_URL=https://your-multitenant-function.azurewebsites.net/api/approve
```

## Build server requirements

- macOS (required — `pkgbuild` and `productbuild` are macOS-only tools)
- Xcode Command Line Tools: `xcode-select --install`
- The backend API server must run on macOS, or the build can be offloaded to a macOS build agent

> **Note for Azure deployment:** Azure App Service runs Linux. You'll need either a macOS build agent (GitHub Actions with `macos-latest`) or a dedicated macOS VM to run builds. A common pattern is: backend on Azure App Service (Linux) → triggers a GitHub Actions macOS build job via repository dispatch → uploads the resulting `.pkg` to Blob Storage → backend polls for completion.
