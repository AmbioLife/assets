#!/bin/bash
# =============================================================================
# QuickElevate for macOS — Build Script
# Generates a customer-specific RequestAdminAccess.pkg
#
# Configuration is injected by build_customer_pkg.sh before this runs.
# All values below are replaced at build time — do not edit manually.
# =============================================================================
set -euo pipefail

# ── Configuration (injected at build time) ───────────────────────────────────
QE_API_URL="https://api.quickelevate.com"
QE_API_KEY="REPLACE_API_KEY"
SESSION_DURATION_MINUTES=60
COOLDOWN_MINUTES=60
APPROVAL_TIMEOUT_MINUTES=30
REQUIRE_APPROVAL=true
EXCLUDED_ACCOUNTS=("lapsadmin")

# ── Build metadata ────────────────────────────────────────────────────────────
PKG_NAME="RequestAdminAccess.pkg"
PKG_VERSION="1.0"
PKG_IDENTIFIER="io.quickelevate.requestadminaccess"
COMPANY_NAME="REPLACE_COMPANY"

# ── Paths ─────────────────────────────────────────────────────────────────────
BUILD_ROOT="$(pwd)/build"
PAYLOAD_DIR="${BUILD_ROOT}/payload"
SCRIPTS_DIR="${BUILD_ROOT}/scripts"
DIST_DIR="$(pwd)/dist"

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log_info()  { echo -e "${GREEN}[BUILD]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

# ── Preflight ─────────────────────────────────────────────────────────────────
log_info "QuickElevate Build Script — ${COMPANY_NAME}"
log_info "API URL:   ${QE_API_URL}"
log_info "Version:   ${PKG_VERSION}"

for cmd in pkgbuild productbuild; do
  command -v "$cmd" &>/dev/null || { log_error "$cmd not found. Run: xcode-select --install"; exit 1; }
done

# ── Directory setup ───────────────────────────────────────────────────────────
rm -rf "$BUILD_ROOT" "$DIST_DIR"
mkdir -p "${PAYLOAD_DIR}/usr/local/bin"
mkdir -p "${PAYLOAD_DIR}/Library/LaunchDaemons"
mkdir -p "${PAYLOAD_DIR}/Applications/Request Admin Access.app/Contents/MacOS"
mkdir -p "${PAYLOAD_DIR}/Applications/Request Admin Access.app/Contents/Resources"
mkdir -p "${SCRIPTS_DIR}"
mkdir -p "${DIST_DIR}"

log_info "Directories created."

# =============================================================================
# WRITE: request_admin.sh
# The core script — runs when user opens the app.
# Talks to the QuickElevate backend API (no Azure, no SharePoint).
# =============================================================================
log_info "Writing request_admin.sh..."

cat > "${PAYLOAD_DIR}/usr/local/bin/request_admin.sh" << 'REQEOF'
#!/bin/bash
# QuickElevate — request_admin.sh
# Injected config values are replaced at build time.
set -euo pipefail

# ── Injected config ───────────────────────────────────────────────────────────
QE_API_URL="__API_URL__"
QE_API_KEY="__API_KEY__"
SESSION_DURATION_MINUTES=__DURATION__
COOLDOWN_MINUTES=__COOLDOWN__
APPROVAL_TIMEOUT_MINUTES=__TIMEOUT__
REQUIRE_APPROVAL=__REQUIRE_APPROVAL__
EXCLUDED_ACCOUNTS=(__EXCLUDED__)

# ── Constants ─────────────────────────────────────────────────────────────────
LOG_DIR="/var/log/QuickElevateAccess"
STATE_DIR="/var/tmp/QuickElevateAccess"
REVOKE_SCRIPT="/usr/local/bin/revoke_admin.sh"

mkdir -p "$LOG_DIR" "$STATE_DIR"
LOG_FILE="${LOG_DIR}/request_admin.log"

log() {
  local level="$1"; shift
  echo "$(date '+%Y-%m-%d %H:%M:%S') [${level}] $*" >> "$LOG_FILE"
}
notify() {
  local title="$1" msg="$2"
  osascript -e "display notification \"${msg}\" with title \"${title}\"" 2>/dev/null || true
}
dialog() {
  osascript -e "display dialog \"$1\" buttons {\"$2\"} default button \"$2\" with title \"QuickElevate\"" 2>/dev/null || true
}
dialog_input() {
  osascript -e "display dialog \"$1\" default answer \"\" with title \"QuickElevate\" buttons {\"Cancel\",\"Continue\"} default button \"Continue\"" 2>/dev/null
}
dialog_list() {
  osascript -e "choose from list {\"15 minutes\",\"30 minutes\",\"1 hour\"} with title \"QuickElevate\" with prompt \"$1\" default items {\"1 hour\"}" 2>/dev/null
}

# ── Identify current user ─────────────────────────────────────────────────────
CURRENT_USER=$(stat -f '%Su' /dev/console 2>/dev/null || echo "$USER")
DEVICE_NAME=$(scutil --get ComputerName 2>/dev/null || hostname)
SERIAL=$(system_profiler SPHardwareDataType 2>/dev/null | awk '/Serial Number/ {print $4}')

log "INFO" "=== Request started for user: ${CURRENT_USER} on ${DEVICE_NAME} ==="

# ── Check excluded accounts ───────────────────────────────────────────────────
for excluded in "${EXCLUDED_ACCOUNTS[@]}"; do
  if [[ "${CURRENT_USER}" == "${excluded}" ]]; then
    log "WARN" "Excluded account ${CURRENT_USER} — ignoring request."
    exit 0
  fi
done

# ── Check if already admin ────────────────────────────────────────────────────
if dsmemberutil checkmembership -U "${CURRENT_USER}" -G admin 2>/dev/null | grep -q "is a member"; then
  dialog "You already have administrator access on this Mac." "OK"
  log "INFO" "User ${CURRENT_USER} is already an admin — exiting."
  exit 0
fi

# ── Check cooldown ────────────────────────────────────────────────────────────
COOLDOWN_FILE="${STATE_DIR}/cooldown_${CURRENT_USER}.conf"
if [[ -f "$COOLDOWN_FILE" ]]; then
  COOLDOWN_UNTIL=$(cat "$COOLDOWN_FILE" 2>/dev/null || echo 0)
  NOW=$(date +%s)
  if [[ $NOW -lt $COOLDOWN_UNTIL ]]; then
    MINS_LEFT=$(( (COOLDOWN_UNTIL - NOW) / 60 + 1 ))
    dialog "You are in a cooldown period. You can request access again in ${MINS_LEFT} minute(s)." "OK"
    log "INFO" "User ${CURRENT_USER} in cooldown — ${MINS_LEFT} min remaining."
    exit 0
  fi
fi

# ── Check for pending request ─────────────────────────────────────────────────
PENDING_FILE="${STATE_DIR}/pending_${CURRENT_USER}.conf"
if [[ -f "$PENDING_FILE" ]]; then
  dialog "You already have a pending approval request. Please wait for IT to respond." "OK"
  log "INFO" "User ${CURRENT_USER} already has a pending request."
  exit 0
fi

# ── Get reason from user ──────────────────────────────────────────────────────
REASON_RESPONSE=$(dialog_input "Please enter the reason you need administrator access:" || echo "button returned:Cancel")
if echo "$REASON_RESPONSE" | grep -q "Cancel"; then
  log "INFO" "User ${CURRENT_USER} cancelled the request."
  exit 0
fi
REASON=$(echo "$REASON_RESPONSE" | sed 's/.*text returned://' | xargs)
if [[ -z "$REASON" ]]; then
  dialog "Please enter a reason for your request." "OK"
  exit 0
fi

# ── Get duration ──────────────────────────────────────────────────────────────
DURATION_CHOICE=$(dialog_list "How long do you need administrator access?" || echo "false")
if [[ "$DURATION_CHOICE" == "false" ]]; then
  log "INFO" "User ${CURRENT_USER} cancelled duration selection."
  exit 0
fi

case "$DURATION_CHOICE" in
  "15 minutes") DURATION_MINUTES=15  ;;
  "30 minutes") DURATION_MINUTES=30  ;;
  "1 hour")     DURATION_MINUTES=60  ;;
  *)            DURATION_MINUTES=${SESSION_DURATION_MINUTES} ;;
esac

log "INFO" "Reason: ${REASON} | Duration: ${DURATION_MINUTES} min"

# ── Submit request to QuickElevate API ──────────────────────────────────────────
notify "QuickElevate" "Sending your request to IT..."
log "INFO" "Submitting approval request to ${QE_API_URL}..."

# Build JSON body — pass values as env vars (prevents injection)
REQUEST_JSON=$(QE_USER="$CURRENT_USER" \
               QE_DEVICE="$DEVICE_NAME" \
               QE_SERIAL="$SERIAL" \
               QE_REASON="$REASON" \
               QE_DURATION="$DURATION_MINUTES" \
  python3 -c "
import json, os
print(json.dumps({
    'userName':        os.environ['QE_USER'],
    'deviceName':      os.environ['QE_DEVICE'],
    'deviceSerial':    os.environ['QE_SERIAL'],
    'reason':          os.environ['QE_REASON'],
    'durationMinutes': int(os.environ['QE_DURATION']),
}))
")

# ── Protection 2: HMAC-SHA256 request signing ────────────────────────────────
# Sign: "METHOD:PATH:BODY_SHA256:TIMESTAMP"
# The backend verifies this and checks the timestamp is within 60 seconds.
# A stolen API key alone cannot produce a valid signature for a new request.
REQUEST_TIMESTAMP=$(date +%s)
REQUEST_BODY_SHA=$(echo -n "${REQUEST_JSON}" | openssl dgst -sha256 | awk '{print $2}')
SIGN_MSG="POST:/api/approval/request:${REQUEST_BODY_SHA}:${REQUEST_TIMESTAMP}"
REQUEST_SIG=$(echo -n "${SIGN_MSG}" | openssl dgst -sha256 -hmac "${QE_API_KEY}" | awk '{print $2}')
log "INFO" "Request signed | ts=${REQUEST_TIMESTAMP}"

RESPONSE=$(curl -s --max-time 15 \
  -X POST "${QE_API_URL}/api/approval/request" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${QE_API_KEY}" \
  -H "X-Timestamp: ${REQUEST_TIMESTAMP}" \
  -H "X-Signature: ${REQUEST_SIG}" \
  -d "${REQUEST_JSON}" \
  2>/dev/null || echo '{"error":"connection failed"}')

REQUEST_ID=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('requestId',''))" 2>/dev/null || echo "")
API_ERROR=$(echo "$RESPONSE"  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('error',''))"     2>/dev/null || echo "")

if [[ -z "$REQUEST_ID" ]]; then
  log "ERROR" "Failed to create request. Response: ${RESPONSE}"
  dialog "Could not reach the QuickElevate server. Please check your internet connection and try again.\n\nError: ${API_ERROR}" "OK"
  exit 1
fi

log "INFO" "Request created: ${REQUEST_ID}"

# Mark as pending to prevent duplicate requests
echo "$REQUEST_ID" > "$PENDING_FILE"

# ── Wait for approval ─────────────────────────────────────────────────────────
if [[ "$REQUIRE_APPROVAL" == "true" ]]; then
  dialog "Your request has been sent to IT.\n\nReason: ${REASON}\nDuration: ${DURATION_MINUTES} minutes\n\nPlease wait for your IT admin to approve it. You will be notified." "OK"

  log "INFO" "Polling for approval (timeout: ${APPROVAL_TIMEOUT_MINUTES} min)..."

  TIMEOUT_EPOCH=$(( $(date +%s) + APPROVAL_TIMEOUT_MINUTES * 60 ))
  APPROVAL_STATUS="pending"
  POLL_COUNT=0

  while [[ $(date +%s) -lt $TIMEOUT_EPOCH ]]; do
    sleep 30
    POLL_COUNT=$(( POLL_COUNT + 1 ))

    # Sign the status poll request
    POLL_TIMESTAMP=$(date +%s)
    POLL_PATH="/api/approval/status/${REQUEST_ID}"
    POLL_BODY_SHA256=$(echo -n "" | openssl dgst -sha256 | awk '{print $2}')
    POLL_MESSAGE="GET:${POLL_PATH}:${POLL_BODY_SHA256}:${POLL_TIMESTAMP}"
    POLL_SIGNATURE=$(echo -n "${POLL_MESSAGE}" | openssl dgst -sha256 -hmac "${QE_API_KEY}" | awk '{print $2}')

    STATUS_RESPONSE=$(curl -s --max-time 10 \
      "${QE_API_URL}${POLL_PATH}" \
      -H "X-API-Key: ${QE_API_KEY}" \
      -H "X-Timestamp: ${POLL_TIMESTAMP}" \
      -H "X-Signature: ${POLL_SIGNATURE}" \
      2>/dev/null || echo '{"status":"pending"}')

    APPROVAL_STATUS=$(echo "$STATUS_RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','pending'))" 2>/dev/null || echo "pending")
    log "INFO" "Poll #${POLL_COUNT}: ${APPROVAL_STATUS}"

    [[ "$APPROVAL_STATUS" == "approved" || "$APPROVAL_STATUS" == "denied" || "$APPROVAL_STATUS" == "expired" ]] && break
  done

  rm -f "$PENDING_FILE"

  if [[ "$APPROVAL_STATUS" == "denied" ]]; then
    notify "QuickElevate" "Your admin request was denied by IT."
    dialog "Your request for administrator access was denied by your IT admin." "OK"
    log "INFO" "Request ${REQUEST_ID} was denied."
    exit 0
  fi

  if [[ "$APPROVAL_STATUS" == "expired" || "$APPROVAL_STATUS" == "pending" ]]; then
    notify "QuickElevate" "Your admin request timed out."
    dialog "Your request timed out after ${APPROVAL_TIMEOUT_MINUTES} minutes with no response from IT." "OK"
    log "INFO" "Request ${REQUEST_ID} timed out."
    exit 0
  fi

  log "INFO" "Request ${REQUEST_ID} approved."
else
  # No approval required — grant immediately
  rm -f "$PENDING_FILE"
  APPROVAL_STATUS="approved"
  log "INFO" "Approval not required — granting immediately."
fi

# ── Grant admin access ────────────────────────────────────────────────────────
log "INFO" "Granting admin access to ${CURRENT_USER} for ${DURATION_MINUTES} minutes..."

if ! sudo dseditgroup -o edit -a "${CURRENT_USER}" -t user admin 2>/dev/null; then
  log "ERROR" "Failed to add ${CURRENT_USER} to admin group."
  dialog "Failed to grant administrator access. Please contact IT." "OK"
  exit 1
fi

# Record the session
SESSION_FILE="${STATE_DIR}/session_${CURRENT_USER}.conf"
EXPIRY_EPOCH=$(( $(date +%s) + DURATION_MINUTES * 60 ))
EXPIRY_TIME=$(date -r $EXPIRY_EPOCH '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -d "@${EXPIRY_EPOCH}" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "unknown")
echo "${EXPIRY_EPOCH}" > "$SESSION_FILE"

# Schedule auto-revocation via LaunchDaemon
REVOKE_LABEL="io.quickelevate.revoke.${CURRENT_USER}"
REVOKE_PLIST="/Library/LaunchDaemons/${REVOKE_LABEL}.plist"

REVOKE_HOUR=$(date -r $EXPIRY_EPOCH '+%-H'  2>/dev/null || date -d "@${EXPIRY_EPOCH}" '+%-H'  2>/dev/null || echo 0)
REVOKE_MIN=$(date  -r $EXPIRY_EPOCH '+%-M'  2>/dev/null || date -d "@${EXPIRY_EPOCH}" '+%-M'  2>/dev/null || echo 0)
REVOKE_DAY=$(date  -r $EXPIRY_EPOCH '+%-d'  2>/dev/null || date -d "@${EXPIRY_EPOCH}" '+%-d'  2>/dev/null || echo 1)
REVOKE_MON=$(date  -r $EXPIRY_EPOCH '+%-m'  2>/dev/null || date -d "@${EXPIRY_EPOCH}" '+%-m'  2>/dev/null || echo 1)

cat > "$REVOKE_PLIST" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${REVOKE_LABEL}</string>
  <key>ProgramArguments</key>
  <array><string>/usr/local/bin/revoke_admin.sh</string><string>${CURRENT_USER}</string></array>
  <key>StartCalendarInterval</key>
  <dict>
    <key>Hour</key><integer>${REVOKE_HOUR}</integer>
    <key>Minute</key><integer>${REVOKE_MIN}</integer>
    <key>Day</key><integer>${REVOKE_DAY}</integer>
    <key>Month</key><integer>${REVOKE_MON}</integer>
  </dict>
  <key>RunAtLoad</key><false/>
  <key>StandardOutPath</key><string>/var/log/QuickElevateAccess/revoke_${CURRENT_USER}.log</string>
  <key>StandardErrorPath</key><string>/var/log/QuickElevateAccess/revoke_${CURRENT_USER}_error.log</string>
</dict>
</plist>
PLISTEOF

launchctl load "$REVOKE_PLIST" 2>/dev/null || true

notify "QuickElevate ✓" "Admin access granted until ${EXPIRY_TIME}"
dialog "Administrator access has been granted.\n\nAccess expires: ${EXPIRY_TIME}\n\nYour rights will be automatically revoked at that time." "OK"
log "INFO" "Admin access granted to ${CURRENT_USER} until ${EXPIRY_TIME}"
REQEOF

chmod +x "${PAYLOAD_DIR}/usr/local/bin/request_admin.sh"

# ── Inject build-time config into request_admin.sh ────────────────────────────
# Convert EXCLUDED_ACCOUNTS array to bash array string
EXCLUDED_STR=""
for acct in "${EXCLUDED_ACCOUNTS[@]}"; do
  EXCLUDED_STR+="\"${acct}\" "
done
EXCLUDED_STR="${EXCLUDED_STR% }"

python3 << PYEOF
content = open('${PAYLOAD_DIR}/usr/local/bin/request_admin.sh').read()
content = content.replace('__API_URL__',        '${QE_API_URL}')
content = content.replace('__API_KEY__',        '${QE_API_KEY}')
content = content.replace('__DURATION__',       '${SESSION_DURATION_MINUTES}')
content = content.replace('__COOLDOWN__',       '${COOLDOWN_MINUTES}')
content = content.replace('__TIMEOUT__',        '${APPROVAL_TIMEOUT_MINUTES}')
content = content.replace('__REQUIRE_APPROVAL__','${REQUIRE_APPROVAL}')
content = content.replace('__EXCLUDED__',       '${EXCLUDED_STR}')
open('${PAYLOAD_DIR}/usr/local/bin/request_admin.sh', 'w').write(content)
print("Config injected into request_admin.sh")
PYEOF

log_info "request_admin.sh written and configured."

# =============================================================================
# WRITE: revoke_admin.sh (unchanged from Phase 1 — no API calls needed)
# =============================================================================
log_info "Writing revoke_admin.sh..."

cat > "${PAYLOAD_DIR}/usr/local/bin/revoke_admin.sh" << 'REVEOF'
#!/bin/bash
# QuickElevate — revoke_admin.sh
# Called by LaunchDaemon at session expiry, or by watchdog for orphaned sessions.
set -euo pipefail

TARGET_USER="${1:-}"
[[ -z "$TARGET_USER" ]] && { echo "Usage: revoke_admin.sh <username>"; exit 1; }

LOG_DIR="/var/log/QuickElevateAccess"
STATE_DIR="/var/tmp/QuickElevateAccess"
mkdir -p "$LOG_DIR"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') [REVOKE] $*" >> "${LOG_DIR}/revoke_${TARGET_USER}.log"; }

log "Revoking admin access for: ${TARGET_USER}"

# Remove from admin group
if dsmemberutil checkmembership -U "${TARGET_USER}" -G admin 2>/dev/null | grep -q "is a member"; then
  dseditgroup -o edit -d "${TARGET_USER}" -t user admin 2>/dev/null && log "Removed from admin group." || log "ERROR: Failed to remove from admin group."
else
  log "${TARGET_USER} is not in admin group — nothing to do."
fi

# Remove state files
rm -f "${STATE_DIR}/session_${TARGET_USER}.conf"
rm -f "${STATE_DIR}/pending_${TARGET_USER}.conf"

# Start cooldown
COOLDOWN_MINUTES=$(grep -r 'COOLDOWN_MINUTES' /usr/local/bin/request_admin.sh 2>/dev/null | grep -v '#' | head -1 | grep -oP '\d+' || echo 60)
COOLDOWN_UNTIL=$(( $(date +%s) + COOLDOWN_MINUTES * 60 ))
echo "$COOLDOWN_UNTIL" > "${STATE_DIR}/cooldown_${TARGET_USER}.conf"
log "Cooldown set for ${COOLDOWN_MINUTES} minutes."

# Unload and remove the revoke LaunchDaemon
REVOKE_LABEL="io.quickelevate.revoke.${TARGET_USER}"
REVOKE_PLIST="/Library/LaunchDaemons/${REVOKE_LABEL}.plist"
if [[ -f "$REVOKE_PLIST" ]]; then
  launchctl unload "$REVOKE_PLIST" 2>/dev/null || true
  rm -f "$REVOKE_PLIST"
  log "Revoke daemon unloaded and removed."
fi

# Notify the user if logged in
CONSOLE_USER=$(stat -f '%Su' /dev/console 2>/dev/null || echo "")
if [[ "$CONSOLE_USER" == "$TARGET_USER" ]]; then
  sudo -u "$TARGET_USER" osascript -e 'display notification "Your temporary admin access has expired." with title "QuickElevate"' 2>/dev/null || true
fi

log "Revocation complete for ${TARGET_USER}."
REVEOF

chmod +x "${PAYLOAD_DIR}/usr/local/bin/revoke_admin.sh"
log_info "revoke_admin.sh written."

# =============================================================================
# WRITE: watchdog_admin.sh
# =============================================================================
log_info "Writing watchdog_admin.sh..."

cat > "${PAYLOAD_DIR}/usr/local/bin/watchdog_admin.sh" << 'WATCHEOF'
#!/bin/bash
# QuickElevate — watchdog_admin.sh
# Runs every 5 minutes via LaunchDaemon. Revokes expired sessions.
LOG_DIR="/var/log/QuickElevateAccess"
STATE_DIR="/var/tmp/QuickElevateAccess"
mkdir -p "$LOG_DIR"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') [WATCHDOG] $*" >> "${LOG_DIR}/watchdog.log"; }

log "Watchdog scan started."
NOW=$(date +%s)

for session_file in "${STATE_DIR}"/session_*.conf; do
  [[ -f "$session_file" ]] || continue
  USERNAME=$(basename "$session_file" | sed 's/^session_//' | sed 's/\.conf$//')
  EXPIRY=$(cat "$session_file" 2>/dev/null || echo 0)

  if [[ $NOW -ge $EXPIRY ]]; then
    log "Session expired for ${USERNAME} — revoking."
    /usr/local/bin/revoke_admin.sh "$USERNAME" 2>/dev/null || log "Revoke failed for ${USERNAME}."
  fi
done

log "Watchdog scan complete."
WATCHEOF

chmod +x "${PAYLOAD_DIR}/usr/local/bin/watchdog_admin.sh"
log_info "watchdog_admin.sh written."

# =============================================================================
# WRITE: LaunchDaemons
# =============================================================================
log_info "Writing watchdog LaunchDaemon..."

cat > "${PAYLOAD_DIR}/Library/LaunchDaemons/io.quickelevate.watchdog.plist" << 'PEOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>io.quickelevate.watchdog</string>
  <key>ProgramArguments</key>
  <array><string>/usr/local/bin/watchdog_admin.sh</string></array>
  <key>StartInterval</key><integer>300</integer>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>/var/log/QuickElevateAccess/watchdog.log</string>
  <key>StandardErrorPath</key><string>/var/log/QuickElevateAccess/watchdog_error.log</string>
</dict>
</plist>
PEOF

log_info "LaunchDaemon written."

# =============================================================================
# WRITE: Request Admin Access.app (AppleScript wrapper)
# =============================================================================
log_info "Writing Request Admin Access.app..."

APP_DIR="${PAYLOAD_DIR}/Applications/Request Admin Access.app"

cat > "${APP_DIR}/Contents/Info.plist" << IPEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleIdentifier</key><string>${PKG_IDENTIFIER}.app</string>
  <key>CFBundleName</key><string>Request Admin Access</string>
  <key>CFBundleDisplayName</key><string>Request Admin Access</string>
  <key>CFBundleVersion</key><string>${PKG_VERSION}</string>
  <key>CFBundleShortVersionString</key><string>${PKG_VERSION}</string>
  <key>CFBundleExecutable</key><string>Request Admin Access</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>14.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>LSUIElement</key><false/>
</dict>
</plist>
IPEOF

cat > "${APP_DIR}/Contents/MacOS/Request Admin Access" << 'APPEOF'
#!/bin/bash
# Launch request_admin.sh with sudo in a Terminal-less context
exec sudo /usr/local/bin/request_admin.sh
APPEOF
chmod +x "${APP_DIR}/Contents/MacOS/Request Admin Access"

log_info "App written."

# =============================================================================
# WRITE: postinstall script
# =============================================================================
log_info "Writing postinstall script..."

cat > "${SCRIPTS_DIR}/postinstall" << 'POSTEOF'
#!/bin/bash
# Fix permissions and load LaunchDaemon after install
chmod 755 /usr/local/bin/request_admin.sh
chmod 755 /usr/local/bin/revoke_admin.sh
chmod 755 /usr/local/bin/watchdog_admin.sh
chmod 644 /Library/LaunchDaemons/io.quickelevate.watchdog.plist
chown root:wheel /Library/LaunchDaemons/io.quickelevate.watchdog.plist

# Unload old watchdog if running, then reload
launchctl unload /Library/LaunchDaemons/io.quickelevate.watchdog.plist 2>/dev/null || true
launchctl load  /Library/LaunchDaemons/io.quickelevate.watchdog.plist

mkdir -p /var/log/QuickElevateAccess
mkdir -p /var/tmp/QuickElevateAccess
chmod 777 /var/log/QuickElevateAccess
chmod 777 /var/tmp/QuickElevateAccess

echo "QuickElevate installed successfully."
exit 0
POSTEOF

chmod +x "${SCRIPTS_DIR}/postinstall"
log_info "postinstall written."

# =============================================================================
# BUILD the .pkg
# =============================================================================
log_info "Building component package..."

COMPONENT_PKG="${BUILD_ROOT}/QuickElevateComponent.pkg"
pkgbuild \
  --root       "${PAYLOAD_DIR}" \
  --scripts    "${SCRIPTS_DIR}" \
  --identifier "${PKG_IDENTIFIER}" \
  --version    "${PKG_VERSION}" \
  --install-location "/" \
  "${COMPONENT_PKG}"

log_info "Component package built."
log_info "Building product package..."

OUTPUT_PKG="${DIST_DIR}/${PKG_NAME}"
productbuild \
  --package "${COMPONENT_PKG}" \
  "${OUTPUT_PKG}"

if [[ -f "$OUTPUT_PKG" ]]; then
  SIZE=$(du -h "$OUTPUT_PKG" | cut -f1)
  log_info "=========================================="
  log_info "Build complete: ${OUTPUT_PKG} (${SIZE})"
  log_info "=========================================="
  echo "BUILD_SUCCESS:${OUTPUT_PKG}"
else
  log_error "Build failed — output package not found."
  exit 1
fi

exit 0
