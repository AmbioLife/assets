#!/bin/bash
# =============================================================================
# QuickElevate — build_customer_pkg.sh
# Server-side wrapper: injects customer config into build_pkg.sh and builds
# a customer-specific RequestAdminAccess.pkg
#
# Usage:
#   bash build_customer_pkg.sh \
#     --config   /path/to/customer.env \
#     --output   /path/to/output.pkg   \
#     --base     /path/to/build_pkg.sh
# =============================================================================
set -euo pipefail

# ── Args ──────────────────────────────────────────────────────────────────────
CONFIG_FILE="" ; OUTPUT_PKG="" ; BASE_SCRIPT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --config) CONFIG_FILE="$2"; shift 2 ;;
    --output) OUTPUT_PKG="$2";  shift 2 ;;
    --base)   BASE_SCRIPT="$2"; shift 2 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

[[ -z "$CONFIG_FILE" || -z "$OUTPUT_PKG" || -z "$BASE_SCRIPT" ]] && {
  echo "Usage: build_customer_pkg.sh --config FILE --output FILE --base FILE"; exit 1; }
[[ -f "$CONFIG_FILE"  ]] || { echo "Config not found: $CONFIG_FILE";  exit 1; }
[[ -f "$BASE_SCRIPT"  ]] || { echo "Base script not found: $BASE_SCRIPT"; exit 1; }

# ── Load customer config ──────────────────────────────────────────────────────
# shellcheck disable=SC1090
source "$CONFIG_FILE"

# Required fields
: "${QE_API_URL:?Missing QE_API_URL}"
: "${QE_API_KEY:?Missing QE_API_KEY}"
: "${COMPANY_NAME:?Missing COMPANY_NAME}"

# Defaults
SESSION_DURATION_MINUTES="${SESSION_DURATION_MINUTES:-60}"
COOLDOWN_MINUTES="${COOLDOWN_MINUTES:-60}"
APPROVAL_TIMEOUT_MINUTES="${APPROVAL_TIMEOUT_MINUTES:-30}"
REQUIRE_APPROVAL="${REQUIRE_APPROVAL:-true}"
EXCLUDED_ACCOUNTS="${EXCLUDED_ACCOUNTS:-lapsadmin}"

# ── Temp working directory (cleaned up on exit) ───────────────────────────────
WORK_DIR=$(mktemp -d)
trap 'rm -rf "$WORK_DIR"' EXIT

PATCHED_SCRIPT="${WORK_DIR}/build_pkg_patched.sh"
cp "$BASE_SCRIPT" "$PATCHED_SCRIPT"
chmod +x "$PATCHED_SCRIPT"

# ── Patch the 8 config values in build_pkg.sh ────────────────────────────────
python3 - << PYEOF
import re, sys

with open('${PATCHED_SCRIPT}') as f:
    content = f.read()

replacements = {
    r'^(QE_API_URL=).*$':      r'\g<1>"${QE_API_URL}"',
    r'^(QE_API_KEY=).*$':      r'\g<1>"${QE_API_KEY}"',
    r'^(COMPANY_NAME=).*$':           r'\g<1>"${COMPANY_NAME}"',
    r'^(SESSION_DURATION_MINUTES=).*$': r'\g<1>${SESSION_DURATION_MINUTES}',
    r'^(COOLDOWN_MINUTES=).*$':       r'\g<1>${COOLDOWN_MINUTES}',
    r'^(APPROVAL_TIMEOUT_MINUTES=).*$': r'\g<1>${APPROVAL_TIMEOUT_MINUTES}',
    r'^(REQUIRE_APPROVAL=).*$':       r'\g<1>${REQUIRE_APPROVAL}',
    r'^(EXCLUDED_ACCOUNTS=).*$':      r'\g<1>("${EXCLUDED_ACCOUNTS}")',
}

for pattern, replacement in replacements.items():
    new_content = re.sub(pattern, replacement, content, count=1, flags=re.MULTILINE)
    if new_content == content:
        print(f'WARN: pattern did not match — {pattern}', file=sys.stderr)
    content = new_content

with open('${PATCHED_SCRIPT}', 'w') as f:
    f.write(content)

print('Config patched successfully.')
PYEOF

# ── Run the build ─────────────────────────────────────────────────────────────
cd "$WORK_DIR"
BUILD_OUTPUT=$(bash "$PATCHED_SCRIPT" 2>&1)
echo "$BUILD_OUTPUT"

# ── Extract built .pkg path and move to output location ──────────────────────
BUILT_PKG=$(echo "$BUILD_OUTPUT" | grep '^BUILD_SUCCESS:' | cut -d: -f2-)

if [[ -z "$BUILT_PKG" || ! -f "$BUILT_PKG" ]]; then
  echo "ERROR: Build failed — BUILD_SUCCESS line not found in output." >&2
  exit 1
fi

mkdir -p "$(dirname "$OUTPUT_PKG")"
mv "$BUILT_PKG" "$OUTPUT_PKG"

echo "BUILD_SUCCESS:${OUTPUT_PKG}"
