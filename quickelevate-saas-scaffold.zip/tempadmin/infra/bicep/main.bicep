// TempAdmin SaaS — Azure Infrastructure
// Deploy: az deployment group create --resource-group TempAdmin --template-file main.bicep

@description('Environment name (dev, staging, prod)')
param environment string = 'prod'

@description('Azure region')
param location string = resourceGroup().location

@description('PostgreSQL admin username')
param dbAdminUser string = 'tempadmin'

@secure()
@description('PostgreSQL admin password')
param dbAdminPassword string

var prefix = 'tempadmin-${environment}'

// ── PostgreSQL Flexible Server ────────────────────────────────────────────────
resource postgres 'Microsoft.DBforPostgreSQL/flexibleServers@2023-03-01-preview' = {
  name: '${prefix}-db'
  location: location
  sku: { name: 'Standard_B1ms', tier: 'Burstable' }
  properties: {
    version: '15'
    administratorLogin: dbAdminUser
    administratorLoginPassword: dbAdminPassword
    storage: { storageSizeGB: 32 }
    backup: { backupRetentionDays: 7, geoRedundantBackup: 'Disabled' }
    highAvailability: { mode: 'Disabled' }
  }
}

resource postgresDatabase 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2023-03-01-preview' = {
  parent: postgres
  name: 'tempadmin'
  properties: { charset: 'UTF8', collation: 'en_US.utf8' }
}

// ── Storage Account (pkg builds) ──────────────────────────────────────────────
resource storage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: replace('${prefix}storage', '-', '')
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    accessTier: 'Hot'
    allowBlobPublicAccess: false
    minimumTlsVersion: 'TLS1_2'
  }
}

resource blobContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-01-01' = {
  name: '${storage.name}/default/pkg-builds'
  properties: { publicAccess: 'None' }
}

// ── App Service Plan (backend API) ────────────────────────────────────────────
resource appServicePlan 'Microsoft.Web/serverfarms@2023-01-01' = {
  name: '${prefix}-plan'
  location: location
  sku: { name: 'B2', tier: 'Basic', capacity: 1 }
  kind: 'linux'
  properties: { reserved: true }
}

// ── Backend API App Service ───────────────────────────────────────────────────
resource backendApp 'Microsoft.Web/sites@2023-01-01' = {
  name: '${prefix}-api'
  location: location
  properties: {
    serverFarmId: appServicePlan.id
    siteConfig: {
      linuxFxVersion: 'NODE|20-lts'
      appSettings: [
        { name: 'NODE_ENV',              value: environment }
        { name: 'PORT',                  value: '8080' }
        { name: 'WEBSITE_RUN_FROM_PACKAGE', value: '1' }
        // Note: sensitive values (DB connection string, secrets) are set
        // via Azure Key Vault references or manually in App Service settings
        // after deployment — never hardcoded here.
      ]
      alwaysOn: true
    }
    httpsOnly: true
  }
}

// ── Static Web App (Next.js frontend) ────────────────────────────────────────
resource frontendApp 'Microsoft.Web/staticSites@2023-01-01' = {
  name: '${prefix}-frontend'
  location: location
  sku: { name: 'Standard', tier: 'Standard' }
  properties: {
    buildProperties: {
      appLocation: 'frontend'
      outputLocation: '.next'
      apiLocation: ''
    }
  }
}

// ── Azure Function App (multi-tenant approval handler) ────────────────────────
resource functionStorage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: replace('${prefix}fnstore', '-', '')
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
}

resource functionPlan 'Microsoft.Web/serverfarms@2023-01-01' = {
  name: '${prefix}-fn-plan'
  location: location
  sku: { name: 'FC1', tier: 'FlexConsumption' }
  kind: 'functionapp'
  properties: { reserved: true }
}

resource functionApp 'Microsoft.Web/sites@2023-01-01' = {
  name: '${prefix}-approvals'
  location: location
  kind: 'functionapp,linux'
  properties: {
    serverFarmId: functionPlan.id
    siteConfig: {
      linuxFxVersion: 'Python|3.11'
      appSettings: [
        { name: 'AzureWebJobsStorage',           value: 'DefaultEndpointsProtocol=https;AccountName=${functionStorage.name};AccountKey=${functionStorage.listKeys().keys[0].value}' }
        { name: 'FUNCTIONS_EXTENSION_VERSION',   value: '~4' }
        { name: 'FUNCTIONS_WORKER_RUNTIME',      value: 'python' }
        { name: 'TEMPADMIN_API_URL',             value: 'https://${backendApp.properties.defaultHostName}' }
      ]
    }
    httpsOnly: true
  }
}

// ── Outputs ───────────────────────────────────────────────────────────────────
output backendUrl    string = 'https://${backendApp.properties.defaultHostName}'
output frontendUrl   string = 'https://${frontendApp.properties.defaultHostname}'
output functionUrl   string = 'https://${functionApp.properties.defaultHostName}'
output storageAccount string = storage.name
output dbServerName  string = postgres.name
